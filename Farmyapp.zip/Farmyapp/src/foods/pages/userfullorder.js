import React from 'react';

const FullUserOrder = (props) => {

    const User_id = props.

    return (
            <>



            </>
    );
}

export default FullUserOrder;