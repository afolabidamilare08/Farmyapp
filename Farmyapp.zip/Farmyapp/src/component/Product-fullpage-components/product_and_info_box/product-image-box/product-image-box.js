import React from 'react';

const ProductimageBox = (props) => {

    //   if( props.pro )

      return ( 

        <div className="ProductimageBox-div" >

            <div className="ProductimageBox-div-img" >
                <div className="ProductimageBox-div-img-box" >
                    <img alt="1" src={props.productimage1} onClick={props.openbigprev} className="ProductimageBox-div-img-box-img" />
                </div>
                <div className="ProductimageBox-div-img-ctr" >
                    <div className="ProductimageBox-div-img-ctr-btn" onClick={props.control1} >
                        <img alt="2" src={props.productimage0} className="ProductimageBox-div-img-ctr-btn-img" />
                    </div>
                    <div className="ProductimageBox-div-img-ctr-btn" onClick={props.control2} >
                      <img alt="3" src={props.productimage2} className="ProductimageBox-div-img-ctr-btn-img" />

                    </div>
                    <div className="ProductimageBox-div-img-ctr-btn" onClick={props.control3} >
                    <img alt="" src={props.productimage3} className="ProductimageBox-div-img-ctr-btn-img" />

                    </div>
                </div>
            </div>

        </div>

      );

}

export default ProductimageBox;