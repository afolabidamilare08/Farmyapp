import React from 'react';
import ProductDetails from './product-details-div/product-details-div';

const ProductDetailsBox = (props) => {

      return ( 

        <div className="productdetailsbox-div" >
            <ProductDetails
             key={props.productname}
             productname={props.productname}
             productdescription={props.productdescription}
             productprice={props.productprice}
             productscale={props.productscale}
             productavailable={props.productavailable}
             firstaddtocart={props.firstaddtocart}
             productimagediv={props.productimagediv}
             comment={props.comment}
             ratings={props.ratings}
             ratenarrate={ props.ratenarrate }
             harvestdate={props.harvestdate} />
        </div>

      );

}

export default ProductDetailsBox;