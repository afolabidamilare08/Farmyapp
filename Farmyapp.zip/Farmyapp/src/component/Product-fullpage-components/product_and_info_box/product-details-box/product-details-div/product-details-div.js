import React from 'react';
import Svg from '../../../../utilities/Svg';


const ProductDetailBox = (props) => {

      return ( 

        <div className="productDetailBox-div" >

            <div className="productDetailBox-div-namepicdiv" >
                {props.productimagediv}
                <div className="productDetailBox-div-namepicdiv-info" >
                    <div className="productDetailBox-div-product-name" >
                    {props.productname}
                    </div>
                    <div className="productDetailBox-div-product-rating" >
                        <div className="productDetailBox-div-seller-rating" >
                            { props.ratings }
                            { props.ratenarrate }
                        </div>
                    </div>
                    <div className="productDetailBox-div-productavailable" >
                        Quantity Remaining for sale - <span className="productDetailBox-div-productavailable-value" > { props.productavailable + " " + props.productscale } </span>
                    </div>
                    <div className="productDetailBox-div-productavailable" >
                        Available On - <span className="productDetailBox-div-productavailable-value" > {props.harvestdate}  </span>
                    </div>
                </div>
            </div>

            <div className="productDetailBox-div-productdesc" >
                <div className="productDetailBox-div-productdesc-top" >
                    Product Description
                </div>
                   {props.productdescription}
            </div>
            <div className="productDetailBox-div-product-price" >
                ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.productprice) } <span className="productDetailBox-div-product-price-per" >per {props.productscale}</span>
            </div>

            <div className="productDetailBox-div-addtocartbtn" >

                <button className="productDetailBox-div-addtocartbtn-btn" onClick={props.firstaddtocart} >
                    <Svg className="productDetailBox-div-addtocartbtn-btn-ic"
                     href="sprite3.svg#icon-add_shopping_cart" />
                    ADD TO CART
                </button>
            </div>

            <div className="productDetailBox-div-comments"  >
                {props.comment}
            </div>

        </div>

      );

}

export default ProductDetailBox;
