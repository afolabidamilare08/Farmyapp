import React from 'react';
import ProductImageBox from './product-image-box/product-image-box';
import ProductDetailsBox from './product-details-box/product-details-box';
import ProductDeliveryBox from './product-delivery-box/product-delivery-box';

const ProductAndinfoBox = (props) => {
  

  // LOGIC FOR ProductDeliveryBox 


  // ////////////////////////////////
  // ==================================================================

  var imgagedis = <ProductImageBox
  productimage1={props.previewimage}
  productimage0={props.ctrimg1}
  productimage2={props.ctrimg2}
  productimage3={props.ctrimg3}
  control1={props.chg1}
  control2={props.chg2}
  control3={props.chg3}
  openbigprev={props.openbigprev} />

      return ( 

        <div className="ProductAndinfoBox-div" style={{
          width:'100%'
        }} >

            <ProductDetailsBox
             productname={props.productname}
             productdescription={props.productdescription}
             productprice={props.productprice}
             productscale={props.productscale}
             productavailable={props.productavailable}
             firstaddtocart={props.firstaddtocart}
             productimagediv={imgagedis}
             comment={props.comment}
             ratings={props.ratings}
             harvestdate={props.harvestdate}
             ratenarrate={ props.ratenarrate }
              />

            <div className="product-delivery-box-div" >
              <ProductDeliveryBox
                state={props.state}
                lga={props.lga}
                address={props.address}
              // cartsurmaryitems={summary}
               />
            </div>

        </div>

      );

} 

export default ProductAndinfoBox;