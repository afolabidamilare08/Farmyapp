import React from 'react';
import Svg from '../../../utilities/Svg';

const ProductDeliveryBox = (props) => {

      return (

        <div className="product-delivery-single" >

            <div className="product-delivery-single-seller" >
                <div className="product-delivery-single-seller_top" >
                    Product Address
                </div>  
                {/* <div className="product-delivery-single-seller_det" >
                    <div className="product-delivery-single-seller_det_ic" >
                        <Svg
                            className="product-delivery-single-seller_det_ic_ic"
                            href="sprite3.svg#icon-store_mall_directorystore"
                        />
                    </div>
                    <div className="product-delivery-single-seller_det_txt" > Afaniyero Farms </div>
                </div> */}
                <div className="product-delivery-single-seller_loc" >
                    <div className="product-delivery-single-seller_loc_ic" >
                        <Svg
                            className="product-delivery-single-seller_loc_ic_ic"
                            href="sprite3.svg#icon-location_onplaceroom"
                        />
                    </div>
                    <div className="product-delivery-single-seller_loc_txt" > 
                        {props.address}
                        <br/>
                        <br/>
                        {props.lga} , {props.state}
                    </div>
                </div>
            </div>
            
        </div>

      );

}

export default ProductDeliveryBox;
