import React from 'react';
import {Link} from 'react-router-dom'
 
const Cartitem = (props) => {

      return ( 

        <div className='product-delivery-box-div-cart-body-list' >
                <div className='product-delivery-box-div-cart-body-list-0' >
                    <img alt="" className="product-delivery-box-div-cart-body-list-0-img" src={props.image} />
                </div>
                <div className='product-delivery-box-div-cart-body-list-1' >
                    <Link to={props.to} className="product-delivery-box-div-cart-body-list-1-productname" >
                        {props.name}
                    </Link>
                    <div className="product-delivery-box-div-cart-body-list-1-productqty" >
                        <span className="product-delivery-box-div-cart-body-list-1-productqty-label" >Quantity :</span>
                        <span className="product-delivery-box-div-cart-body-list-1-productqty-qty" >{props.quantity}</span>
                    </div>
                    <div className="product-delivery-box-div-cart-body-list-1-productqty" >
                        <span className="product-delivery-box-div-cart-body-list-1-productqty-label" >Price :</span>
                        <span className="product-delivery-box-div-cart-body-list-1-productqty-no" >₦{props.price}</span>
                    </div>
                    <div className="product-delivery-box-div-cart-body-list-1-productqty" >
                        <span className="product-delivery-box-div-cart-body-list-1-productqty-label" >Subtotal Price :</span>
                        <span className="product-delivery-box-div-cart-body-list-1-productqty-no" >₦{props.price * props.quantity }</span>
                    </div>
                </div>
        </div>

      );

}

export default Cartitem;