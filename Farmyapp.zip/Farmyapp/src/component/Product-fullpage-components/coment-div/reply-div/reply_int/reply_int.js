import React from 'react';

const ReplyInt = (props) => {

      return ( 

        <div className="replyint_div" >
            <div className="replyint_div_reply" >
                {props.reply}
            </div>
            <div className="replyint_div_user" >
                <div className="replyint_div_user_img" >
                    {props.img}
                </div>
                <div className="replyint_div_user_name" >
                    {props.name}
                </div>
                <div className="replyint_div_user_timesince" >
                    {props.time_since}
                </div>
            </div>
        </div>

      );

}

export default ReplyInt;