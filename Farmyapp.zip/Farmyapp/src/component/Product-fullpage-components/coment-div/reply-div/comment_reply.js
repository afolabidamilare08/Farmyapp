import React , { useState , useEffect } from 'react';
import Axios from 'axios';
import Svg from '../../../utilities/Svg';

const CommentReplyDiv = (props) => {


    const [ loadeded_comment_to_reply , setloadeded_comment_to_reply ] = useState(null)
    const [ replytobeposted , setreplytobeposted ] = useState('')
    const [ replying , setreplying ] = useState( { bgcolor: '' , text:'' , status:false } )

    useEffect( () => {

        Axios.get( '/comment/' + props.comment_to_reply.id + '/' ).then(
            response => {
                setloadeded_comment_to_reply(response.data)
            }
        );

    } , [props.comment_to_reply] )


    const PostreplyHandler = (e) => {

        setreplying( { bgcolor: 'orange' , text: 'Sending your reply' , status: 'true' } )

        e.preventDefault()

        var reply = {reply:replytobeposted}

        Axios.post( '/comment/' + loadeded_comment_to_reply.id + '/reply_comment/' , reply ).then(
            response => {

                Axios.get( '/comment/' + loadeded_comment_to_reply.id + '/' ).then(
                    response => {
                        setloadeded_comment_to_reply(response.data)
                        setreplying( { bgcolor: 'rgb(39, 180, 39)' , text: 'Reply successfully sent' , status: 'true' } )
                        setreplytobeposted('')
                        props.reload();
                    }
                );
            }
        )

    }

    const closeMsg = () => {
        setreplying({ ...replying , status:false })
    }

    const Changereplytobeposted = (event) => {
        setreplytobeposted(event.target.value)
    }


      return ( 

        <div className="commentreply-div" style={{display: props.show ? 'block' : 'none' }} >
            <div className="commentreply-div-top" >
                <span className="commentreply-div-top-span" >
                    Reply comment
                </span>
                <button onClick={props.closereplymodal} className="commentreply-div-top-btn" >close</button>
            </div>
            <div className="commentreply-div-top_msg" 
                onClick={closeMsg}
                style={{ display: replying.status ? 'flex' : 'none' , backgroundColor: replying.bgcolor }} >
               {replying.text}
            </div>

                {/* <div className="commentreply-div-mid" >

                    <div className="commentreply-div-mid-rep" >
                        { loadeded_comment_to_reply ? loadeded_comment_to_reply.replies.length + ' ' : '' } person(s) reacted to this comment
                    </div>

                    { loadeded_comment_to_reply ? 
                    loadeded_comment_to_reply.replies.map( rep => {
                        return <ReplyInt
                                    key={rep.id}
                                    reply={rep.reply}
                                    name={ rep.user.first_name + ' ' + rep.user.last_name }
                                    time_since={rep.time_since}
                                    img={ rep.user.profile_picture !== '' ? <img alt="" src={'http://127.0.0.1:8000/media/' + rep.user.profile_picture} className="replyint_div_user_img" /> : rep.user.first_name[0] }  />
                    } ) : '' }

                </div> */}

            <div className="commentreply-div-bttm" >
                
                <div className="commentreply-div-bttm_comment" >
                    <div className="commentreply-div-bttm_comment_str" >
                        { loadeded_comment_to_reply ? loadeded_comment_to_reply.comment : '' }
                    </div>
                    <div className="commentreply-div-bttm_comment_user" >
                        <div className="commentreply-div-bttm_comment_user_img" >
                            <Svg className="commentreply-div-bttm_comment_user_img-img" href="contact.svg#icon-person" />
                        </div>
                        <div className="commentreply-div-bttm_comment_user_name" >
                            { loadeded_comment_to_reply ? loadeded_comment_to_reply.user.first_name + ' ' + loadeded_comment_to_reply.user.last_name : '' }
                        </div>
                        <div className="commentreply-div-bttm_comment_user_timesince" >
                            { loadeded_comment_to_reply ? loadeded_comment_to_reply.time_since : '' }
                        </div>
                    </div>
                </div>

                <form className="commentreply-div-bttm-form" onSubmit={PostreplyHandler} >
                    <div className="commentreply-div-bttm-form-input" >
                        <textarea placeholder="Reply to the post" className="commentreply-div-bttm-form-input-input" value={replytobeposted} onChange={Changereplytobeposted} >
                        
                        </textarea>
                    </div>
                    <div className="commentreply-div-bttm-form-sbt" >
                        <button type="submit" onClick={PostreplyHandler} className="commentreply-div-bttm-form-sbt-btn" >
                            reply
                        </button>
                    </div>
                </form>
            </div>

        </div>

      );

}

export default CommentReplyDiv;