import React from 'react';
import Svg from '../../../utilities/Svg';

const Productcomposecomment = (props) => {

      return ( 

        <div className="Productcomposecomment-div" >
                <textarea className="Productcomposecomment-div-input" ref={props.inputRef} value={props.inputValue} onChange={props.inputOnchange} 
                            placeholder={props.placeholder} >

                </textarea>
                <div className="Productcomposecomment-div-sbt" >

                    <div className="Productcomposecomment-div-sbt-msg" style={{ color : props.comment_msg_color }} >
                        <div className="Productcomposecomment-div-sbt-msg-img" >
                            <Svg className="Productcomposecomment-div-sbt-msg-img" href="contact.svg#icon-person" />
                        </div>
                        <div className="Productcomposecomment-div-sbt-msg-name" >
                            { props.first_name + ' ' + props.last_name }
                        </div>
                    </div>

                    <button className="Productcomposecomment-div-sbt-btn" onClick={props.postit} >
                        Post Comment
                    </button>
                </div>
        </div>

      );

}

export default Productcomposecomment;