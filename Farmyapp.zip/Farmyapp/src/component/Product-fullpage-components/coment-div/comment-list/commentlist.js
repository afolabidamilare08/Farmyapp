import React from 'react';
import { Link } from 'react-router-dom';
import Svg from '../../../utilities/Svg';

const CommentList = (props) => {

      return ( 

        <div className="CommentList-div" style={{backgroundColor:'',border:props.reply ? '' : '1px solid lightgray'}} >

            <div className="CommentList-div-comment" >
                {props.commentBody}
            </div>

            <div className="CommentList-div-profile" >

                <Link to={props.To} className="CommentList-div-profile-1" > 

                    <div className="CommentList-div-profile-1-pic" >
                         <Svg className="CommentList-div-profile-1-pic" href="contact.svg#icon-person" />
                    </div>

                    <div className="CommentList-div-profile-1-name" >
                        <div className="CommentList-div-profile-1-name_name" >{ props.firstName + ' ' + props.lastName }</div>
                        <span style={{ color:'black' }} > {props.time_since} </span>
                    </div>

                </Link>

                { props.reply ?  
                        
                        <div className="CommentList-div-profile-2" >

                            <button className="CommentList-div-profile-2-btn" onClick={props.reply} >
                                Reply
                            </button>
    
                        </div>
                        : ''}

            </div>

            { props.replies_list ? 
                
                <div className="CommentList-div-replies" >

                {/* <div className="CommentList-div-replies_top" > replies </div> */}

                { props.replies_list }

            </div> : ''}

        </div>

      );

}

export default CommentList;