import React from 'react';

const FulldetailComp = (props) => {

      return ( 
          <div className="culldetailcomp-div" >

              <div className="culldetailcomp-div-top" >

                 <span className="culldetailcomp-div-top-1" >
                     item
                 </span>

                 <span className="culldetailcomp-div-top-2" >
                     {props.productname}
                 </span>

              </div>

              <div className="culldetailcomp-div-narate" >
                    Please type how many {props.productscale}s you want to add to cart
              </div>

              {props.message}

              <div className="culldetailcomp-div-log" >

                  <input value={props.inputvalue} onChange={props.onchangeinput} className="culldetailcomp-div-log-input" placeholder="0" type="text" />

                  <span className="culldetailcomp-div-log-scale" > {props.productscale} </span>

              </div>

              <div className="culldetailcomp-div-bottom" >

                    <div className="culldetailcomp-div-bottom-left" >

                        <div className="culldetailcomp-div-bottom-left-uprice" >
                            <span className="culldetailcomp-div-bottom-left-uprice-1" >Quantity Remaining:</span>
                            <span className="culldetailcomp-div-bottom-left-uprice-2" > {props.quantityAvailable} </span>
                        </div>

                        <div className="culldetailcomp-div-bottom-left-uprice" >
                            <span className="culldetailcomp-div-bottom-left-uprice-1" >unit price:</span>
                            <span className="culldetailcomp-div-bottom-left-uprice-2" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.productprice)}</span>
                        </div>

                        <div className="culldetailcomp-div-bottom-left-sprice" >
                            <span className="culldetailcomp-div-bottom-left-sprice-1" >subtotal:</span>
                            <span className="culldetailcomp-div-bottom-left-sprice-2" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.accumprice)} </span>
                        </div>

                    </div>

                    <div className="culldetailcomp-div-bottom-right" >

                        <button className="culldetailcomp-div-bottom-right-1" onClick={props.cancel} >Cancel</button>
                        <button className="culldetailcomp-div-bottom-right-2" onClick={props.addtocart} >Add to cart</button>

                    </div>

              </div>

          </div>
      );

}

export default FulldetailComp;