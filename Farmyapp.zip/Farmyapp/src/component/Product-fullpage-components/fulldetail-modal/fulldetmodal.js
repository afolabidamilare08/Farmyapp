import React , {useState ,useContext } from 'react';
import Backdrop from '../../utilities/Backdrop/backdrop';
import Aux from '../../utilities/Aaux';
import FulldetailComp from './fulldetail-comp/fulldetail-comp';
import Error from '../../error/error';
import Loading3 from '../../utilities/loading3/loading3';
import Store from '../../../store/managementstore/managementstore';
import Success from '../../success/success';
import Axios from 'axios';
import {useVerifynum} from '../../utilities/checkingforletter';

    /// this functiuon is the one in control of the modal and backdrop that shows up when you want to add to cart///



    const  Fulldetmodal = (props) => {

      const context = useContext(Store)

    const info = props.loaddetail
  

    const [ input , setinput ] = useState(1)


    const [ loading , setloading ] = useState(false)

    const [ error , seterrormessage ] = useState(false)

    const [ success , setsuccessmsg ] = useState(false)

    const onChangeinputhandler = (event) => {
        setinput(event.target.value)
    }



    //logic to make sure the user actually input a digit not a string
      const [ result ] = useVerifynum(input)
    ///////////////////

      const addtocartHandler = () => {

            setloading(true)
            seterrormessage(false)
            setsuccessmsg(false)

          if( input === '' || input[0] === '0' ){
              setloading(false)
              seterrormessage('Please type how many ' + info.measurement_scale + 's you want to buy' )
          }else{

            if( !result ){ 
                setloading(false)
                seterrormessage('Amount should be in numbers and not letters ')
            }else{
              
              // if( info.quantity_remaining !==  ){
              //   var numbertocheck = info.quantity_remaining
              // }else{
              //   numbertocheck = info.quantity_available
              // }
              if(info.quantity_remaining !== null ){
                var numbertocheck = info.quantity_remaining
              }else{
                numbertocheck = info.quantity_available
              }


                if( Number(input) > numbertocheck ){
                  setloading(false)
                  seterrormessage(" Only " + numbertocheck + " " + info.measurement_scale + " are left" )
                }else{
                  // var sendit = {...info,quantity: input }

                   
                  const item_to_be_added = { product_id:info.id,quantity:input}

                  Axios.post( '/carts/cart/' + context.User_cart_id + '/add_to_cart/' , item_to_be_added ).then(
                    response => {
                      setloading(false)
                      setsuccessmsg( " item has been added to cart " )
                      context.updatecartHandler()
                      setTimeout(() => {
                        context.close_add_product_slideHandler()
                        setsuccessmsg(false)
                      }, 2000);
                    }
                  )
    

                }
                }

          }

      }

    //end of logic  
    /////////////


    //logic wether to display errormessage , adding to cart message or nothing

    
    if( !error && !loading ){
        var message = null
    }

        if( error && !loading ){
            message = <div className="messagemodalDiv" ><Error error={error} /></div>
        }

        if( success && !error && !loading ){
          message = <div className="messagemodalDiv" ><Success success={success} /></div>
        }

        if( loading &&  !success  && !error ){
          message = <div className="messagemodalDiv" ><Loading3/></div>
        }




    //end of logic
    //////////




    // this logic is used to make sure that the information needed are loaded before loading to avoid any form of errors
    ////////////////////////////

    if(info){
        const accum = input * info.price

        var show =                     
        
        <FulldetailComp
          productname={info.product_name}
          productscale={info.measurement_scale}
          productprice={info.price}
          inputvalue={input}
          onchangeinput={onChangeinputhandler}
          accumprice={accum}
          cancel={context.close_add_product_slideHandler}
          addtocart={addtocartHandler}
          message={message}
          quantityAvailable={  info.quantity_remaining !== null ? info.quantity_remaining + ' ' + info.measurement_scale  : info.quantity_available + ' ' + info.measurement_scale }
           />


    }else{

        show = "loading"

    }

    ///////////////////
    //==============




      return ( 
          <Aux>
              <Backdrop show={context.add_product_slide} closebackdrop={context.close_add_product_slideHandler} />
                <div className="fulldetmodel-div" style={{
                    transform: context.add_product_slide ? 'translateY(0)' : 'translateY(-100vh)',
                    opacity: context.add_product_slide ? '1' : '0'
                }}  >

                    {show}                    

                </div>
          </Aux>
      );

}

export default Fulldetmodal;