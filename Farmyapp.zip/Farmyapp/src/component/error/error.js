import React from 'react';
import Svg from '../utilities/Svg';

const Error = (props) => {

      return ( 

        <div className="error-div" >
            <Svg
             className="error-div-ic"
             href="sprite2.svg#icon-report" />
            <div className="error-div-msg" >{props.error}</div> 
        </div>

      );

}

export default Error;