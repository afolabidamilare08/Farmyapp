import React, {useEffect} from 'react';
import { Link } from 'react-router-dom';
import Aos from 'aos';
import 'aos/dist/aos.css';

const Producttemp = (props) => {

    useEffect( () => {
        Aos.init({duration:2000})
    } , [] )

    if( props.product.length > 20 ){
        var pname = []
        for( var i = 0 ; i < 20 ; i++ ){
            pname.push(props.product[i])
        }
        pname.push('...')
    }else{
        pname = props.product
    }

    if( props.product_des.length > 100 ){
        var product_det = []
        for( var j = 0 ; j < 100 ; j++ ){
            product_det.push(props.product_des[j])
        }
        product_det.push('...')
    }else{
        product_det = props.product_des 
    }



    

      return (
        
        <div className="product-card" data-aos="fade-up" data-aos-once={true}  >

            <div className="product-card-img" >
                <img className="product-card-img-img" alt="" src={props.img} />
            </div>

            <div className="product-card-info" ref={props.refrence} > 

                <Link to={props.to} className="product-card-info-1" >{pname}</Link>

                <div className="product-card-info-det" >
                    {product_det}
                </div>
                
                <div className="product-card-info-loc" >
                    {props.lga} , {props.state}
                </div>

                <div className="price" >
                    <Link to={props.to} className="product-card-info-2">₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.price) }</Link>
                    <Link to={props.to} className="product-card-info-3">per {props.kg}</Link>
                </div>


                
            </div>
            <div className="product-card-info-add" >
                     <Link 
                        to={props.to}
                        className="product-card-info-add-li"
                        style={{ backgroundColor: props.add_to_cart ? '' : 'orange' }} >
                            { props.action }
                     </Link>
            </div>

            { props.add_to_cart ? null : 
            
            <div className="product-card-info-del" >
                <button to={props.delete_product} onClick={ props.deleteIt } className="product-card-info-del-li"> Delete {props.type} </button>
            </div>

            }

         </div>
    

      );

}

export default Producttemp;