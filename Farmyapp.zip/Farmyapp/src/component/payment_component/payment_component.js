// import React, { useState } from 'react';
// import PaystackButton from 'react-paystack';
// import Svg from '../utilities/Svg';

// const PaymentsComponents = (props) => {

//       const [ paymentdetails
//         //  , setpaymentdetails
//          ] = useState({
//         key: "pk_live_712332318f9883cc97fda53fda3b545fddd78bfa", //PAYSTACK PUBLIC KEY
//         email: "dikins1111@yahoo.com",  // customer email
//         amount: 10000 //equals NGN100,
//       })

//       // const callback = (response) => {
        
//       // }

//       const getReference = () => {

//       }

//       // const close = () => {
//     	// 	console.log("Payment closed");
//     	// }

//       return ( 

//         <>

//         <div className="PaymentDetails-div" id="paystackEmbedContainer" style={{ 
//          }} >
//            <div className="PaymentDetails-div-top" >
//               <Svg className="PaymentDetails-div-top-ic" href="sprite2.svg#icon-add" onClick={ props.cancelpayment } />
//            </div>
//         <div>
//           <PaystackButton
//             text="Make Payment"
//             class="payButton"
//             callback={props.callback}
//             close={props.cancelpayment}
//             disabled={true} 
//             embed={true} 
//             reference={getReference()}
//             email={props.email}
//             amount={props.amount}
//             paystackkey={paymentdetails.key}
//             tag="button"
//           />
//         </div>
//       </div> 

      

//         </>

//       );

// }



// const PaymentsComponents = () => {
//   return(
//     <div>
//       me
//     </div>
//   )
// }



import React from 'react';
import {PaystackButton } from 'react-paystack';     
    
    const PaymentsComponents = (props) => {

      const config = {
        reference: (new Date()).getTime(),
        email: props.email,
        amount: props.amount,
        publicKey: 'pk_live_712332318f9883cc97fda53fda3b545fddd78bfa',
    };

        const componentProps = {
            ...config,
            text: 'pay' ,
            onSuccess: props.callback,
            onClose:props.cancelpayment,
            className:'PayStackBigButton'
        };
    
      return (
            <PaystackButton {...componentProps} />
      );
    }


export default PaymentsComponents;