import React , { useContext } from 'react';
import { Link , NavLink} from 'react-router-dom';
import Svg from '../../utilities/Svg';
import Store from '../../../store/managementstore/managementstore';
import header_store from '../../../store/managementstore/header_store';


export const useLinkLogic = (props) => {

    const context = useContext(Store)
    const context2 = useContext(header_store)

    const logitout = () => {
        localStorage.removeItem('farmyapp-tok')
        localStorage.removeItem('farmyapp-userid')
        localStorage.removeItem('farmyapp-usercartid')
        context2.clearNotification()
        context.Logouthandler()
        context.close_profile_page_slideHandler()
    }

    const Links = [
        {to:'/',href:'contact.svg#icon-home',name:'Home'},
        {to:'/services',href:'sprite4.svg#icon-work',name:'Services'},
        {to:'/sell',href:'sprite3.svg#icon-store_mall_directorystore',name:'Sell'},
        {to:'/profile',href:'contact.svg#icon-person',name:'My Profile'},
        {to:'/my_referrals',href:'sprite4.svg#icon-gift',name:'Referrals'},
        // {to:'/paymentsdet',href:'contact.svg#icon-chat',name:'Messages'}
         ]
         
        
    const Links2 = [
        {to:'/myorders',href:'sprite3.svg#icon-truck',name:'My Orders'},
        {to:'/services_hired',href:'sprite3.svg#icon-handshake-o',name:'Services Hired'},
        // {to:'/stats',href:'opps.svg#icon-stats',name:'Statistics'},
        // {to:'/paymentsdetails',href:'opps.svg#icon-credit-card-alt',name:'Payments details'},
        ]

    const ProductLinks = [
        { to: '/myproducts' ,href:'sprite3.svg#icon-store_mall_directorystore' , name: 'My Products'  },
        { to: '/mypendingproducts' ,href: 'sprite3.svg#icon-av_timer' , name:'My Products Ordered' },
    
        ]    

    const ServicesLinks = [
        { to: '/myservices' ,href:'sprite4.svg#icon-work' , name: 'My Services'  },
        { to: '/mypendingservices' ,href: 'sprite3.svg#icon-av_timer' , name:'My Services Ordered' },
        
        ]    
    

        var display = Links.map( list => { 

            if(list.name === 'Home' ){

               return <NavLink to={list.to} key={list.name} onClick={ () => context.close_profile_page_slideHandler() } className="user_profile_left-div-li" >
                            <Svg
                            className="user_profile_left-div-li-ic"
                            href={list.href} />
                            {list.name} 
                </NavLink>

            }else{
                return   <NavLink to={list.to} key={list.name}  activeStyle={{ backgroundColor: 'rgba(13, 194, 94, 0.986)' }} onClick={ () => context.close_profile_page_slideHandler() } className="user_profile_left-div-li" >
                            <Svg
                            className="user_profile_left-div-li-ic"
                            href={list.href} />
                            {list.name} 
                        </NavLink>
            }

        } )

        var display2 = Links2.map( list => { 
            return      <NavLink to={list.to} key={list.name}  activeStyle={{backgroundColor:'rgba(13, 194, 94, 0.986)'}} onClick={ () => context.close_profile_page_slideHandler() } className="user_profile_left-div-li" >
                            <Svg
                            className="user_profile_left-div-li-ic"
                            href={list.href} />
                            {list.name}
                        </NavLink>
        } )

        var productsMatter = ProductLinks.map( list => { 
            return      <NavLink to={list.to} key={list.name}  activeStyle={{backgroundColor:'rgba(13, 194, 94, 0.986)'}} onClick={ () => context.close_profile_page_slideHandler() } className="user_profile_left-div-li" >
                            <Svg
                            className="user_profile_left-div-li-ic"
                            href={list.href} />
                            {list.name}
                        </NavLink>
        } )


        var servicesMatter = ServicesLinks.map( list => { 
            return      <NavLink to={list.to} key={list.name}  activeStyle={{backgroundColor:'rgba(13, 194, 94, 0.986)'}} onClick={ () => context.close_profile_page_slideHandler() } className="user_profile_left-div-li" >
                            <Svg
                            className="user_profile_left-div-li-ic"
                            href={list.href} />
                            {list.name}
                        </NavLink>
        } )

        var logout = <Link to="#" onClick={ logitout } className="user_profile_left-div-li" >
                        <Svg
                        className="user_profile_left-div-li-ic"
                        href='contact.svg#icon-exit' />
                        Log out
                    </Link>

        return [ display , display2 , logout , productsMatter , servicesMatter ]
}