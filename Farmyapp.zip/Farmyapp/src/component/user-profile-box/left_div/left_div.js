import React , {useContext , useEffect, useState } from 'react';
import {useLinkLogic} from './listlogic';
import Svg from '../../utilities/Svg';
import Store from '../../../store/managementstore/managementstore';

const Profileleftdiv = (props) => {

     const context = useContext(Store)
     const [ mynames , setmynames ] = useState(null)
     const [ picture , setpicture ] = useState(null)

     const [ display , display2 , logout , productsMatter , servicesMatter ] = useLinkLogic()

     useEffect( () => {

          setmynames(context.User_details.detail)
          setpicture(context.User_details.detail2)

     } , [context.User_details] )

      return ( 
          < >

                <div className="user_profile_left-div-img" >
                     <div className="user_profile_left-div-img-letter" >
                         
                         { picture ? picture.profile_picture ? <img alt="" className="user_profile_left-div-img-letter-img" src={picture.profile_picture} /> :
                         <Svg
                         className="user_profile_left-div-img-letter-ic"
                         href="contact.svg#icon-person" />
                          : 
                         <Svg
                          className="user_profile_left-div-img-letter-ic"
                          href="contact.svg#icon-person" /> }

                     </div>
                     <div className="user_profile_left-div-img-name" > { mynames ? mynames.first_name + ' ' + mynames.last_name : '' } </div>
                </div>

                {/* <div className="user_profile_left-div-demacation" ></div> */}

                
                {display}

                
                {display2}

                <div className="user_profile_left-div-demacation" ></div>

                {productsMatter}

                <div className="user_profile_left-div-demacation" ></div>

                {servicesMatter}

                { context.User_id ? logout : null}

               <div style={{
                    marginBottom:'10rem'
               }} > 

               </div>

          </>
      );

}

export default Profileleftdiv;