import React from 'react';
import WholesaleFooterdiv from '../../layout/footer/wholesaleFooter';
// import Leftdiv from './left_div/new_leftDiv';
import Middlediv from './middle-div/middle_div';

const Userprofilebox = (props) => {

      return (

          <>
            {/* <Leftdiv/> */}
            <Middlediv/>
            <WholesaleFooterdiv showbtmlinks />
          </>

      );

}

export default Userprofilebox;