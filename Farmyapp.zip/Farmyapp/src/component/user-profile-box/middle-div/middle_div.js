import React , { useContext } from 'react';
import {Route,Switch} from 'react-router-dom';
import ProfileDeatails from './profile-details/profile_details';
import Store from '../../../store/managementstore/managementstore';
import Backdrop from '../../utilities/Backdrop/backdrop';
import Paymentdetails from '../../user-profile-box/middle-div/paymentsdetails/paymentdetail';
import Myorder from './my_order/my_orders';
import UserproductPage from '../../../pages/userprofileproducts/user_products';
import PendingProductPage from '../../../pages/pending_products_page/pending_products';
import ProductsDelivered from '../../../pages/products_Delivered/products_Delivered';
import UserservicesPage from '../../../pages/userprofileservices/user_services';
import PendingServicesPage from '../../../pages/pending_services_page/pending_services';
import ServiceHiredpage from '../../../pages/serviceHiredpage/serviceHiredpage';
import Referal_page from '../../../pages/refarals_page/referal_page';


const UserprofileMiddlediv = (props) => { 

      const context = useContext(Store)
      
      return ( 

          <div className="user_profile_middle-div" >
            <Switch>
              <Route path="/profile" exact component={ProfileDeatails} />
              <Route path="/paymentsdetails" exact component={Paymentdetails} />
              <Route path="/myorders" exact component={Myorder} />
              <Route path="/myproducts" exact component={UserproductPage} />
              <Route path="/mypendingproducts" exact component={PendingProductPage} />
              <Route path="/myservices" exact component={UserservicesPage} />
              <Route path="/mydeliveredproducts" exact component={ProductsDelivered} />
              <Route path="/mypendingservices" exact component={PendingServicesPage} />
              <Route path="/services_hired" exact component={ServiceHiredpage} />
              <Route path="/my_referrals" exact component={Referal_page} />
            </Switch>
            <Backdrop show={context.profile_page_slide} closebackdrop={context.close_profile_page_slideHandler} />
          </div>

      );

}

export default UserprofileMiddlediv;
