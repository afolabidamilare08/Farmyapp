import React from 'react';

const Notificationfull = (props) => {

      return ( 

        <div className="notificationfull-box" >
            <div className="notificationfull-box-top" >
                notifications
            </div>
            <div className="notificationfull-box-topic" >
                Welcome !!!! to farm app
            </div>
            <div className="notificationfull-box-body" >
            We’ve often had to maintain components that started out simple but grew into an unmanageable mess of stateful logic and side effects. Each lifecycle method often contains a mix of unrelated logic. For example, components might perform some data fetching in componentDidMount and componentDidUpdate. However, the same componentDidMount method might also contain some unrelated logic that sets up event listeners, with cleanup performed in componentWillUnmount. Mutually related code that changes together gets split apart, but completely unrelated code ends up combined in a single method. This makes it too easy to introduce bugs and inconsistencies.
In many cases it’s not possible to break these components into smaller ones because the stateful logic is all over the place. It’s also difficult to test them. This is one of the reasons many people prefer to combine React with a separate state management library. However, that often introduces too much abstraction, requires you to jump between different files, and makes reusing components more difficult.

            </div>
        </div>

      );

}

export default Notificationfull;