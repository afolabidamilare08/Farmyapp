import React ,  {useEffect,useState,useContext} from 'react';
import Axios from 'axios';
import Store from '../../../../store/managementstore/managementstore';
import Product from '../../../product_template/product_template';

export const useProductlogic = () => {

    const context = useContext(Store)
    const userid = context.User_id

    const [ yourproduct , setyourproduct ] = useState(null)


    useEffect( () => {
        Axios.get('/account/users/' + userid + '/' ).then(
            response => {
                setyourproduct(response.data.products)
            }
        );
    } , [userid] )

    if(yourproduct){
        var display =   yourproduct.map( product => {
            return <Product
                   img={ "http://127.0.0.1:8000" + product.product_img1}
                   product={product.product_name}
                   product_des={product.description}
                   price={product.price}
                   kg={product.measurement_scale}
                   action="Edit Product"
                   to={'/editproduct' + product.slug + ':' + product.id} />
        } )
    }


    return [display]

}





// export const useDetails = () => {

//     const context = useContext(Store)
//     const userid = context.User_id

//     const [ firstdet , setfirstdet ] = useState([])

//     const [ seconddet , setseconddet ] = useState([] )

//     useEffect( () => {
//         Axios.get('/account/users/' + userid + '/' ).then(
//             response => {
//                 const detail = response.data
//                 setfirstdet(
//                     { first_name:detail.first_name,
//                      last_name: detail.last_name ,
//                      username: detail.username,
//                      email: detail.email ,
//                       })
//                      context.add_to_userdetails(detail)
//                 Axios.get('/account/profile/' + userid + '/' ).then(
//                     response => {
//                         const detail2 = response.data
//                          setseconddet(
//                              { phone_number: detail2.phone_number,
//                               gender:detail2.gender,
//                               bio: detail.bio,
//                               languages_known:detail2.languages_known,
//                               interests:detail2.interests  })
//                     }
//                 )
//             }
//         )
//         // eslint-disable-next-line
//     } , [userid] )

//         return [ firstdet , seconddet ]
// }


