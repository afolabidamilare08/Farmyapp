import React ,  {useEffect,useState,useContext} from 'react';
import Axios from 'axios';
import Store from '../../../../store/managementstore/managementstore';
// import {useProductlogic} from './profile_detailslogic';
// import Backdrop from '../../../utilities/Backdrop/backdrop';
import Topbanner from '../../../utilities/top-banner-msg/topbannermsg';
import Fullprofedit from './fullprofilemodel/fullprofilemodel';
import {useVerifynum,useVerifyimg} from '../../../utilities/checkingforletter';
import Svg from '../../../utilities/Svg';
import BtnSpin from '../../../utilities/btnSpin/btnSpin';
import ProfileHeader from '../../../../foods/layout_components/profile_header/profile_header';
import { FaUser } from 'react-icons/fa';
import LoadingPage from '../../../../foods/components/loading/loading';
import OppsPage from '../../../../foods/components/oppspage/oppspage';

const Userprofiledetails = (props) => {


    const [ Loadingpage , setLoadingpage ] = useState(false)
    const [ Errorpage , setErrorpage ] = useState(false)
    
    const context = useContext(Store)

    const [ msg , setmsg ] = useState( { status: false , msg : '' , bcolor: '' } )

    const [ firstdet , setfirstdet ] = useState(null)

    const [ UpdatingProfile , setUpdatingProfile ] = useState(false)

    const [ seconddet , setseconddet ] = useState(null)

    const [ untouch , setuntouch ] = useState(null)

    const [ uploadingpicture , setuploadingpicture ] = useState(false)

    useEffect( () => {

      setLoadingpage(true)
      setErrorpage(false)


      if ( context.User_id !== null && context.User_details !== null ) {
        getdataHandler()
      }

        // eslint-disable-next-line
    } , [context.User_id,context.User_details] )



    const getdataHandler = () => {
      Axios.get('/account/users/' + context.User_id + '/').then(
        response => {

            var userdata = response.data

            Axios.get('/account/profile/' + context.User_details.detail2.id + '/').then(
              response => {
                setseconddet(response.data)
                setfirstdet(userdata)
                setuntouch(userdata)
                setErrorpage(false)
                setLoadingpage(false)
              }
            ).catch(
              e => {
                setErrorpage(true)
                setLoadingpage(false)
              }
            )

        }
      ).catch(
        e => {
          setErrorpage(true)
          setLoadingpage(false)
        }
      )
    }

    /////////////////////////////////////////////////////////
    ///////////////////////////////////////////////
    //////////////////////All Logic To Edit Profile Information



    const changefirstname = (event) => {
      setfirstdet({ ...firstdet , first_name: event.target.value })
     }

    const changelastname = (event) => {
    setfirstdet({ ...firstdet , last_name: event.target.value })
    } 

    const changebio = (event) => {
      setseconddet({ ...seconddet , bio: event.target.value })
    } 

    const changeusername = (event) => {
      setfirstdet({ ...firstdet , username: event.target.value })
    }
    
    const changeemail = (event) => {
      setfirstdet({ ...firstdet , email: event.target.value })
    } 

    const changeinterests = (event) => {
      setseconddet({ ...seconddet , interests: event.target.value })
    } 

    const changelanguagesknown = (event) => {
      setseconddet({ ...seconddet , languages_known: event.target.value })
    } 

    const changephonenumber = (event) => {
      setseconddet({ ...seconddet , phone_number: event.target.value })
    } 

    const changegender = (event) => {
      setseconddet({ ...seconddet , gender: event.target.value })
    } 

    const UploadprofileImage = (event) => {

      setuploadingpicture(true)

      setmsg( {...msg, status:false} )

      const [result] = useVerifyimg(event.target.files)
  


      if( result ){
        
                // putting the image file in a special data form 
                const fd = new FormData();
                fd.append('profile_picture',event.target.files[0],event.target.files[0].name)

                // sending http request to post the image selected

                  Axios.patch('/account/profile/' + context.User_details.detail2.id + '/',fd,{

                    // // logic to show the progress of the request 
                    // onUploadProgress: ProgressEvent => {
                    // }
                })

                .then(response => {

                    var old = { ...context.User_details.detail2 , profile_picture: response.data.profile_picture }
                    context.add_to_userdetails( context.User_details.detail , old )
                    setuploadingpicture(false)
                    setmsg( { ...msg , status: true , msg: ' Your profile picture was successfully updated  ' , bcolor: 'rgb(39, 180, 39)' } )
            
                } ).catch(
                  error => {
                    setmsg({...msg, status:true, msg:'Taking too long to update make sure your internet connection is OK or Refresh' , bcolor:'red'})
                    setuploadingpicture(false)
                  }
                );

      }else{
        setmsg( {...msg, status:true ,msg:' only jpg , jpeg , png and gif files are allowed  ....', bcolor: 'red' ,} )
        setuploadingpicture(false)
      }

    }


    const UpdateprofileHandler = () => {

      setmsg( {...msg, status:false} )
      setUpdatingProfile(true)

      const [ result ] = useVerifynum( seconddet.phone_number )

      if(result === false ){
           setmsg({...msg, status:true, msg:'Phone Number should not contain Alphabets' , bcolor:'red'})
           setUpdatingProfile(false)
      }else{

        if( 

          firstdet.first_name === '' ||
          firstdet.last_name === '' ||
          firstdet.email === '' ||
          seconddet.phone_number === '' 
  
         ){
          setmsg( {...msg, status:true ,msg:'All Fields must Be Filled', bcolor: 'red' ,} )
          setUpdatingProfile(false)
         }
  
         if (
          firstdet.first_name !== '' &&
          firstdet.last_name !== '' &&
          firstdet.email !== '' &&
          seconddet.phone_number !== '' 
         ) {
    
            Axios.patch( '/account/users/' +  context.User_id + '/', firstdet ).then( 
              response => {
                const old = {
                  interests:seconddet.interests,
                  languages_known:seconddet.languages_known,
                  phone_number:seconddet.phone_number,
                  gender:seconddet.gender,
                  bio:seconddet.bio
                }
    
    
                Axios.patch( '/account/profile/' + context.User_details.detail2.id + '/' , old ).then( 
                  response => {
                    // console.log(response)
                    context.add_to_userdetails(firstdet,seconddet)
                    setmsg( { ...msg , status: true , msg: ' Your profile was successfully updated  ' , bcolor: 'rgb(39, 180, 39)' } )
                    setUpdatingProfile(false)
                  }
                 ).catch( 
                      error => {
                        setUpdatingProfile(false)
                        setmsg({...msg, status:true, msg:'Taking too long to update make sure your internet connection is OK or Refresh' , bcolor:'red'})
                      }
                    )
              }
              ).catch( 
                error => {
                  setUpdatingProfile(false)
                  setmsg({...msg, status:true, msg:'Taking too long to update make sure your internet connection is OK or Refresh' , bcolor:'red'})
                }
              )
    
    
    
              }
  
            } 

    }


    ///////////////////////////
    /////////////////////////////
    ////////////////////
    /////////////////

    if( context.User_details ){
      if( !uploadingpicture && context.User_details.detail2.profile_picture ){
        var itis = <img alt="" className="Userprofiledetails-div-box-cover-1-img" src={ context.User_details.detail2.profile_picture } />
      }if( !uploadingpicture && !context.User_details.detail2.profile_picture ){
        itis = <FaUser
                className="Userprofiledetails-div-box-cover-1-icon" />
                
      }
    }











////All thing partaining to change passwors


      const [ allpasswordinput , setallpasswordinput ] = useState({
        firstinput:{ value:'' , status:false },
        secondinput:{ value:'' , status:false },
        thirdinput:{ value:'' , status:false }
      })

      const [ UpadatePassword , setUpadatePassword ] = useState(false)


      const ChangePassword = () => {

        setmsg({
          ...msg,
          status:false
        })

        setUpadatePassword(true)

        if( allpasswordinput.firstinput.value === '' ||
            allpasswordinput.secondinput.value === '' ||
            allpasswordinput.thirdinput.value === ''   ){
              setmsg({
                msg:'Current password , New password and Repeat New password should all be filled ',
                status:true,
                bcolor:'red'
              })
              setUpadatePassword(false)
      }else{
          if(
            allpasswordinput.secondinput.value !== allpasswordinput.thirdinput.value
          ){
            setmsg({
              msg:'New Password and Repeat new password must be the same',
              status: true,
              bcolor: 'red'
            })
            setUpadatePassword(false)
            
          }else{
              
            if (
              allpasswordinput.secondinput.value === context.User_details.detail.username ||
              allpasswordinput.secondinput.value === context.User_details.detail.email
            ) {
              setmsg({
                msg:"New Password can't be your username or email",
                status:true,
                bcolor:'red'
              })
              setUpadatePassword(false)
            }else{

              if (
                allpasswordinput.secondinput.value.length < 8
              ) {
                setmsg({
                  msg:"This password is too short. It must contain at least 8 characters.",
                  status:true,
                  bcolor:'red'
                })
                setUpadatePassword(false)
              }else{
                var AllpasswordDetails = {
                  old_password:allpasswordinput.firstinput.value,
                  new_password1:allpasswordinput.secondinput.value,
                  new_password2:allpasswordinput.thirdinput.value
                }
        
                      Axios.post('/account/rest-auth/password/change/',AllpasswordDetails,   {
        
                        auth:{
                          username: context.User_details.detail.username, 
                          password: AllpasswordDetails.old_password
                        }
        
                      }).then(
                        response=>{
                          setmsg({
                            msg: 'You have successfully updated your password!!',
                            status: true,
                            bcolor: 'rgb(39, 180, 39)'
        
                          })
                          setallpasswordinput({
                            firstinput: {
                              ...allpasswordinput.firstinput, value:""
                            },
        
                            secondinput: {
                              ...allpasswordinput.firstinput, value:""
                            },
        
                            thirdinput: {
                              ...allpasswordinput.firstinput, value:""
                            }
                          })
                          setUpadatePassword(false)
                        }
                      ).catch( (error) => {
                        setUpadatePassword(false)
                        if(error.response){
            
                
                            if(error.response.data.new_password2){
                              setmsg({
                                status:true,
                                msg:error.response.data.new_password2[0],
                                bcolor:'red'
                              })
                            }
                
                        }
                    } )
              }

            }

          }
        // var AllpasswordDetais = {
        //   old_password:allpasswordinput.firstinput.value,
        //   new_password1:allpasswordinput.secondinput.value,
        //   new_password2:allpasswordinput.thirdinput.value
        

      


      }

    }


    const gogo = () => {
      props.history.go()
    } 
  
    const goBack = () => {
      props.history.goBack()
    }
  
  
    if( Loadingpage && !firstdet && !untouch && !seconddet && !Errorpage ){
      var what_to_return = <LoadingPage/>
    }else{
      if ( !Loadingpage && Errorpage && !firstdet && !untouch && !seconddet ) {
        what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
      }else{
        if ( !Loadingpage && !Errorpage && firstdet && untouch && seconddet ) {
          what_to_return = 
          <>

          <div className="Userprofiledetails-div-box" >
      
              <Topbanner 
                  show={msg.status} 
                  backgroundcolor={msg.bcolor}
                  message={msg.msg}
                  closeshow={ () => setmsg( { ...msg , status:false } ) } />

              <Fullprofedit
                top_firstname={ untouch.first_name }
                top_lastname={untouch.last_name}
                top_username={untouch.username}
                profile_picture={ itis }
                loadingPicture={uploadingpicture}
                firstName_value={firstdet.first_name}
                firstName_onChange={changefirstname}
                lastName_value={firstdet.last_name}
                lastName_onChange={changelastname}
                bio_value={seconddet.bio}
                bio_onChange={changebio}
                userName_value={firstdet.username}
                userName_onChange={changeusername}
                email_value={firstdet.email}
                email_onChange={changeemail}
                interests_value={seconddet.interests}
                interests_onChange={changeinterests}
                languagesKnown_value={seconddet.languages_known}
                languagesKnown_onChange={changelanguagesknown}
                mobile_value={seconddet.phone_number}
                mobile_onChange={changephonenumber}
                gender_value={seconddet.gender}
                gender_onChange={changegender}
                profile_picture_onChange={UploadprofileImage}
                editbtn={UpdateprofileHandler}
                loadingDetails={UpdatingProfile}
                 />
               
               </div> 

               <div className="password_change-div"  >

                    <div className="password_change-div_top" >
                        Change Password
                    </div>

                    <div className="password_change-div_form" >


                        <div className="password_change-div_form-in" >

                            <label className="password_change-div_form-in-label" >
                                Current Password
                            </label>

                            <div className="password_change-div_form-in-2" >

                              <input className="password_change-div_form-in-2-input"
                                 type={ allpasswordinput.firstinput.status ? 'text' : 'password' }
                                 value={ allpasswordinput.firstinput.value } 
                                 onChange={ (event) => setallpasswordinput({
                                    ...allpasswordinput,
                                    firstinput:{  ...allpasswordinput.firstinput, value:event.target.value }
                                  }) } 
                                  />

                              <Svg onClick={ () => setallpasswordinput({
                                ...allpasswordinput,
                                firstinput:{ ...allpasswordinput.firstinput , status:!allpasswordinput.firstinput.status }
                              }) }
                                href="contact.svg#icon-eye"
                                className="password_change-div_form-in-2-icon" />

                            </div>

                        </div>


                        <div className="password_change-div_form-in" >

                            <label className="password_change-div_form-in-label" >
                                New Password
                            </label>

                            <div className="password_change-div_form-in-2" >

                              <input className="password_change-div_form-in-2-input" 
                                type={ allpasswordinput.secondinput.status ? 'text' : 'password' }
                                value={ allpasswordinput.secondinput.value } 
                                onChange={ (event) => setallpasswordinput({
                                  ...allpasswordinput,
                                  secondinput:{  ...allpasswordinput.secondinput , value:event.target.value}
                                }) }
                                />

                              <Svg onClick={() => setallpasswordinput({
                                              ...allpasswordinput,
                                              secondinput:{ ...allpasswordinput.secondinput , status:!allpasswordinput.secondinput.status }
                                            })}
                                href="contact.svg#icon-eye"
                                className="password_change-div_form-in-2-icon" />

                            </div>

                        </div>


                        <div className="password_change-div_form-in" >

                          <label className="password_change-div_form-in-label" >
                             Repeat New Password
                          </label>

                          <div className="password_change-div_form-in-2" >

                            <input className="password_change-div_form-in-2-input" 
                              type={ allpasswordinput.thirdinput.status ? 'text' : 'password' }
                              value={ allpasswordinput.thirdinput.value } 
                              onChange={ (event) => setallpasswordinput({
                                ...allpasswordinput,
                                thirdinput:{  ...allpasswordinput.thirdinput , value:event.target.value}
                              }) }
                              />

                            <Svg onClick={() => setallpasswordinput({
                                            ...allpasswordinput,
                                            thirdinput:{ ...allpasswordinput.thirdinput , status:!allpasswordinput.thirdinput.status }
                                          })}
                              href="contact.svg#icon-eye"
                              className="password_change-div_form-in-2-icon" />

                          </div>

                          </div>


                    </div>

                    <button disabled={UpadatePassword} onClick={ChangePassword} className="password_change-div_sbt" >
                        {

                            UpadatePassword ? 

                            <BtnSpin bgColor="white" />

                            : 'Change Password'

                        }
                    </button>

               </div>  

          </>       

        }
      }
    }







      return (

        <>

        <ProfileHeader
          title='Edit Profile'
          goback={ () => props.history.goBack() }
        />

        {what_to_return}

    </>

      );

  }


export default Userprofiledetails;