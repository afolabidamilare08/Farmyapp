import React from 'react';
import Initdet from '../intdet/initdet';
import BtnSpin from '../../../../utilities/btnSpin/btnSpin';
import { FaCamera } from 'react-icons/fa';

const Fullprofilemodel = (props) => {

      var picture = props.profile_picture



      return ( 

    <>    


             <div className="Userprofiledetails-div-box-top" > My Profile </div>

              <div className="Userprofiledetails-div-box-cover" > 
                  <div className="Userprofiledetails-div-box-cover-1" >
                        { picture ? picture : null  }
                  </div>
                  <div className="Userprofiledetails-div-box-cover-2" >
                      <div className="Userprofiledetails-div-box-cover-2-info" >
                        <div className="Userprofiledetails-div-box-cover-2-info-name" >
                            {props.top_firstname + ' ' + props.top_lastname } 
                        </div>
                        <div className="Userprofiledetails-div-box-cover-2-info-username" >
                            @{props.top_username}
                        </div>
                      </div>
                      <div className="Userprofiledetails-div-box-cover-2-change" >
                         { props.loadingPicture ? 
                         
                         <div disabled={false} for="piv" className="Userprofiledetails-div-box-cover-2-change-btn" style={{fontSize:'1.3rem'}} >
                              <BtnSpin bgColor="white" />
                          </div> 

                          :

                          <label disabled={false} htmlFor="piv" className="Userprofiledetails-div-box-cover-2-change-btn" style={{fontSize:'1.3rem'}} >
                                <FaCamera
                                className="Userprofiledetails-div-box-cover-2-change-btn-ic" />
                                Change Photo
                          </label> 

                         }
                          <input type="file" onChange={props.profile_picture_onChange}  id="piv" style={{display:'none'}} />
                      </div>
                  </div>
              </div>



    <div className="Userprofiledetails-div-box-middle" >

        <div className="Userprofiledetails-div-box-middle-form" >

            <div className="Userprofiledetails-div-box-middle-form-name" >

                <div className="Userprofiledetails-div-box-middle-form-name-1" >
                    <Initdet
                     type="text"
                     onChange={ props.firstName_onChange }
                     value={ props.firstName_value }
                     label="First Name"
                    //  disable 
                     />
                </div>

                <div className="Userprofiledetails-div-box-middle-form-name-1" >
                    <Initdet
                     type="text"
                     label="Last Name"
                     onChange={ props.lastName_onChange }
                     value={ props.lastName_value }
                    //  disable 
                     />
                </div>

            </div>           

            <div className="Userprofiledetails-div-box-middle-form-bio" >
                <Initdet 
                    label="About Me" 
                    value={ props.bio_value }
                    onChange={ props.bio_onChange }
                    type="bio"  />
            </div>

            <div className="Userprofiledetails-div-box-middle-form-oth" >
                <Initdet 
                    label="Username" 
                    value={ props.userName_value } 
                    onChange={ props.userName_onChange }
                    type="text"
                    // disable 
                     />
            </div>

            <div className="Userprofiledetails-div-box-middle-form-oth" >
                <Initdet 
                    label="Email" 
                    value={ props.email_value } 
                    type="text"
                    onChange={ props.email_onChange }
                    // disable
                      />
            </div>

            <div className="Userprofiledetails-div-box-middle-form-name" >

                <div className="Userprofiledetails-div-box-middle-form-name-1" >
                    <Initdet 
                        type="text" 
                        onChange={ props.interests_onChange}
                        value={ props.interests_value } 
                        label="Interests" />
                </div>

                <div className="Userprofiledetails-div-box-middle-form-name-1" >
                    <Initdet type="text" 
                        value= { props.languagesKnown_value } 
                        onChange={ props.languagesKnown_onChange }
                        label="Languages Known" />
                </div>

            </div>     
            
            <div className="Userprofiledetails-div-box-middle-form-oth" >
                <Initdet 
                    label="Phone Number" 
                    value= { props.mobile_value } 
                    type="text"
                    onChange={ props.mobile_onChange }  />
            </div>                                 

            <div className="Userprofiledetails-div-box-middle-form-oth" >
                <div className="Initdet-div" >
                    <label className="Initdet-div-1" >Gender</label>
                    <select 
                        onChange={ props.gender_onChange } 
                        className="Initdet-div-2" 
                        value={ props.gender_value } >

                        <option value='male' >Male</option>
                        <option value='female' >Female</option>
                        <option value="not-specified" >Not Specified</option>

                    </select>
                </div>
            </div> 

            <div className="Userprofiledetails-div-box-middle-form-submit" >
                <button className="Userprofiledetails-div-box-middle-form-submit-btn" disabled={props.loadingDetails} onClick={ props.editbtn } >
                    { props.loadingDetails ? 
                        <BtnSpin bgColor="white" />
                        
                        :

                        'Save My Profile'
                    }
                </button>
            </div>

        </div>
    </div>
 

    </>

      );

}

export default Fullprofilemodel;