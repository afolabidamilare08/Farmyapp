import React from 'react';

const Initdet = (props) => {

    if( props.type === 'text' ){
        var send  = <div className="Initdet-div" >
                        <label className="Initdet-div-1" htmlFor={props.label} > {props.label} </label>
                        <input className="Initdet-div-2" value={ props.value ? props.value : '' } id={props.label} onChange={props.onChange} /> 
                    </div>
    }if( props.type === 'bio' ){
        send = <div className="Initdet-div-bio" >
                    <label htmlFor={props.label} className="Initdet-div-bio-1" > {props.label} </label>
                    <textarea className="Initdet-div-bio-2" id={props.label} value={ props.value ? props.value : '' } onChange={props.onChange} >  </textarea>
               </div>
    }

      return (
        
        <>
            {send}
        </>

        
      );

}

export default Initdet;