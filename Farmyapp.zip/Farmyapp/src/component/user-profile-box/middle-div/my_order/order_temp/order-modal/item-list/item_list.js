import React from 'react';

const OrdermodalListitem = (props) => {

      return ( 
          <div className="OrdermodalListitem-div" >

              <div className="OrdermodalListitem-div_top" >
                    <div className="OrdermodalListitem-div_top_1" >
                        Product Status
                    </div>
                    <div className="OrdermodalListitem-div_top_2" style={{ backgroundColor: props.bgColor }} >
                        {props.productStatus}
                    </div>
              </div>

              <div className="OrdermodalListitem-div_mid" >

              <div className="OrdermodalListitem-div-box1" >
                    <div className="OrdermodalListitem-div-box1-1" >
                        Product Name :
                    </div>
                    <div className="OrdermodalListitem-div-box1-2" >
                         { props.productName }
                    </div>
              </div>
              {/* <div className="OrdermodalListitem-div-box1" >
                    <div className="OrdermodalListitem-div-box1-1" >
                        Measurement Scale
                    </div>
                    <div className="OrdermodalListitem-div-box1-2" >
                         50 bags
                    </div>
              </div> */}
              <div className="OrdermodalListitem-div-box1" >
                    <div className="OrdermodalListitem-div-box1-1" >
                        Quantity Ordered :
                    </div>
                    <div className="OrdermodalListitem-div-box1-2" >
                         { props.quantityOrdered + ' ' + props.measurement_scale }
                    </div>
              </div>
              <div className="OrdermodalListitem-div-box1" >
                    <div className="OrdermodalListitem-div-box1-1" >
                       Subtotal Price :
                    </div>
                    <div className="OrdermodalListitem-div-box1-2" >
                        ₦ { props.sub_total_price } 
                    </div>
              </div>
              <div className="OrdermodalListitem-div-box1" >
                    <div className="OrdermodalListitem-div-box1-1" >
                       Product Status :
                    </div>
                    <div className="OrdermodalListitem-div-box1-2" >
                        {props.productStatus}
                    </div>
              </div>
              <div className="OrdermodalListitem-div-box1" style={{
                  flexWrap:'wrap'
              }} >
                    <div className="OrdermodalListitem-div-box1-1" >
                       Product Address :
                    </div>
                    <div className="OrdermodalListitem-div-box1-2" >
                    Rice, a monocot, is normally grown as an annual plant, 
                    although in tropical areas it can survive as a perennial 
                    and can produce a ratoon crop for up to 30 years.[3] Rice 
                    cultivation is well-suited to countries and regions with low labor costs 

                    </div>
              </div>
              </div>
              
              { props.productStatus === 'In Transit' ?
              
                    <button onClick={ props.change } >
                        Change order status to Delivered
                    </button>

               : null  }

          </div>
      );

}

export default OrdermodalListitem;