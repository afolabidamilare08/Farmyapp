import React, { useState } from 'react';
import OrdermodalListitem from './item-list/item_list';
import Backdrop from '../../../../../utilities/Backdrop/backdrop';

const OrderModalDiv = (props) => {

    const [ selectedOrder , setselectedOrder ] = useState(null)
    const [ ispendding , setispendding ] = useState(null)
    const [ Openrating , setOpenrating ] = useState(false)

    const SetItOrder = ( order ) => {

        setselectedOrder( order )

        // console.log(order)

    }

    if( props.ordertobeChosen && selectedOrder === null ){
        SetItOrder(props.ordertobeChosen)
    }

    if( props.ordertobeChosen && !ispendding ){
        for (let y = 0; y < props.ordertobeChosen.items.length; y++) {
            if(props.ordertobeChosen.items[y].status === 'in_transit' || 'created' ){
                setispendding(true)
            }
        }
    }
    

    if( selectedOrder ){
        var mappingitem = selectedOrder.items.map( ( item , indx ) => {

            if( item.status === 'created' ){
                var status = 'Pending'
                var bgcolor = 'orange'
            }

            if( item.status === 'in_transit' ){
                status = 'In Transit'
                bgcolor = 'rgb(37, 88, 165)'
            }

            return <OrdermodalListitem
                      productName = { item.product.product_name }
                      productStatus = {status}
                      bgColor = {bgcolor}
                      quantityOrdered = { item.quantity }
                      measurement_scale = { item.product.measurement_scale }
                      sub_total_price = { item.get_cost }
                      change={ () => ChangetodeliveredHandler(item.id)  }
                       /> 
            
        } )
    }


     const ChangetodeliveredHandler = (itemId) => {
        setOpenrating(true)
     }

      return ( 

        <div className="myorder-div-backdrop" >

            <Backdrop show={Openrating} >
                <div style={{
                    border:'1px solid red',
                    backgroundColor:'white',
                    height:'50%',
                    width:'40%',
                    
                }} >

                </div>
            </Backdrop>    

            <div className="myorder-div-backdrop_top" >
                <div className="myorder-div-backdrop_top-form" >
                    <span className="myorder-div-backdrop_top-form-1" >
                        Order Id :
                    </span>
                    <span className="myorder-div-backdrop_top-form-2" >
                        { selectedOrder ? selectedOrder.id : null }
                    </span>
                </div>
                <div className="myorder-div-backdrop_top-form" >
                    <span className="myorder-div-backdrop_top-form-1" >
                        Date Ordered :
                    </span>
                    <span className="myorder-div-backdrop_top-form-2" >
                        { selectedOrder ? selectedOrder.created_at : null }
                    </span>
                </div>
                <div className="myorder-div-backdrop_top-form" >
                    <span className="myorder-div-backdrop_top-form-1" >
                        No of items Ordered :
                    </span>
                    <span className="myorder-div-backdrop_top-form-2" >
                        { selectedOrder ? selectedOrder.items.length : null }
                    </span>
                </div>
                <div className="myorder-div-backdrop_top-form" >
                    <span className="myorder-div-backdrop_top-form-1" >
                        Total Cost Of Products Ordered :
                    </span>
                    <span className="myorder-div-backdrop_top-form-2" >
                        ₦ { selectedOrder ? selectedOrder.get_total_cost : null }
                    </span>
                </div>
                <div className="myorder-div-backdrop_top-form" >
                    <span className="myorder-div-backdrop_top-form-1" >
                        Order Status :
                    </span>
                    <span className="myorder-div-backdrop_top-form-2" >
                        { ispendding ? 'Pending' : 'Delivered' }
                    </span>
                </div>
            </div>
            <div className="myorder-div-backdrop_mid" >
                {mappingitem}
            </div>
            <div className="myorder-div-backdrop_btm" >
                <button onClick={ props.closeModal } className="myorder-div-backdrop_btm_btn" >
                    close
                </button>
            </div>
        </div>

      );

}

export default OrderModalDiv;