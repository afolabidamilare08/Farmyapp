import React from 'react';
import { Link } from 'react-router-dom';

const Ordertemp = (props) => {

    var newDateOrdered = []

    if( props.dateOrdered ){
        for (let k = 0; k < props.dateOrdered.length; k++) {
            if( props.dateOrdered[k] !== 'T' ){
                newDateOrdered.push(props.dateOrdered[k])
            }else{
                break
            }    
        }
    }

      return ( 

        <div className="ordertemp-div" >
            <div className="ordertemp-div-top" >
                <div className="ordertemp-div-top-1" > Order Status </div>
                <div className="ordertemp-div-top-2" style={{ backgroundColor: props.backgroundcolor }} > { props.order_status } </div>
            </div>
            <div className="ordertemp-div-info" >

                {/* <div className="ordertemp-div-info-form" style={{
                    marginBottom:'2rem'
                }} > 
                    <div className="ordertemp-div-info-form-1" > Order Status : </div> 
                    <div className="ordertemp-div-info-form-2" style={{
                        // border:'1px solid red',
                        padding:'.5rem 1rem',
                        color:'white',
                        fontSize:'1.1rem',
                        borderRadius:'5px',
                        backgroundColor:props.backgroundcolor,
                        textTransform:'uppercase'
                    }} > { props.order_status } </div>
                </div> */}
                {/* <div className="ordertemp-div-info-form" > 
                    <div className="ordertemp-div-info-form-1" > Order Id : </div> 
                    <div className="ordertemp-div-info-form-2" > { props.orderId } </div>
                </div> */}
                <div className="ordertemp-div-info-form" > 
                    <div className="ordertemp-div-info-form-1" > No of Items Ordered : </div> 
                    <div className="ordertemp-div-info-form-2" > { props.no_of_OrderedItem } item </div>
                </div>
                <div className="ordertemp-div-info-form" > 
                    <div className="ordertemp-div-info-form-1" > Total Cost Of Product : </div> 
                    <div className="ordertemp-div-info-form-2" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.total_price)} </div>
                </div>
                <div className="ordertemp-div-info-form" > 
                    <div className="ordertemp-div-info-form-1" > Date Ordered : </div> 
                    <div className="ordertemp-div-info-form-2" > { newDateOrdered } </div>
                </div>
                {/* <div className="ordertemp-div-info-form" > 
                    <div className="ordertemp-div-info-form-1" > Transport Fee : </div> 
                    <div className="ordertemp-div-info-form-2" > ₦ 8900 </div>
                </div> */}
            </div>

            <div className="ordertemp_btm" >
                <Link to={props.to} className="ordertemp_btm-btn" onClick={ props.openOrderModal } >
                    View Order
                </Link>
            </div>

        </div>

      );

}

export default Ordertemp;