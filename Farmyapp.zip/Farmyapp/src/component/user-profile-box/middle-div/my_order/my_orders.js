import React, { useState , useContext , useEffect } from 'react';
import Ordertemp from './order_temp/order_temp';
import Backdrop from '../../../utilities/Backdrop/backdrop';
import OrderModalDiv from './order_temp/order-modal/order_modal';
import Store from '../../../../store/managementstore/managementstore';
import Axios from 'axios';
import { Link } from 'react-router-dom';
import Ordertruck from './ordertruck.png';
import BtnSpin from '../../../utilities/btnSpin/btnSpin';

const Myorderdiv = (props) => {

  const context = useContext(Store)

  const [ openModal , setopenModal ] = useState(false)
  const [ order , setorder ] = useState(null)
  const [ orders , setorders ] = useState(null)

  useEffect( () => {

      Axios.get( '/account/users/' + context.User_id + '/' ).then(
        response => {
          // console.log(response.data)
          setorders(response.data.orders)
        }
      )

  } , [ context.User_id ] )


  const closeModal = ( ) => {
    setopenModal(false)
    setorder(null)
  }

  if( orders && orders.length > 0 ){

    var mappingOrders = orders.map( ( order , index ) => {

      var checkStatus = {
        status:'',
        bgcolor:''
      }

      var checkpaid = []
      var checkdelivery = []
      var checkintransit = []
      var checkpending = []

      for (let l = 0; l < order.items.length; l++) {
        
        // if( order.items[l].status === 'created' || order.items[l].status === 'in_transit' ){
        //   checkStatus = {
        //     status:'pending',
        //     bgcolor:'orange'
        //   }
        // }

        if( order.items[l].status === 'paid' ){
            checkpaid.push(order.items[l])
        }

        if( order.items[l].status === 'created' ){
          checkpending.push(order.items[l])
        }

        if( order.items[l].status === 'in_transit' ){
          checkintransit.push(order.items[l])
        }

        if( order.items[l].status === 'delivered' ){
          checkdelivery.push(order.items[l])
        }
        
      }
      

      if( checkpaid.length > 0 || checkintransit.length > 0 ){
        checkStatus = {
          status:'pending',
          bgcolor:'#ffbb00a4'
        }
      }

      if( checkintransit.length < 1 && checkpaid.length < 1 && checkdelivery.length > 0 ){
        checkStatus = {
          status:'Delivered',
          bgcolor:'rgba(13, 194, 94, 0.986)'
        }
      }

      if ( checkpending.length > 0 ){
          return  <Ordertemp
                dateOrdered={ order.created_at }
                total_price={ order.get_total_cost }
                no_of_OrderedItem = { order.items.length }
                orderId={ order.id }
                key={ order.id }
                // openOrderModal={ () => openBackDrop(order) }
                to={ '/finalcheckout' + order.id }
                backgroundcolor={'red'}
                // "rgb(17, 137, 235)"
                order_status={'Pay Now'} /> 
      }else{
        return(  
          <Ordertemp
            dateOrdered={ order.created_at }
            total_price={ order.get_total_cost }
            no_of_OrderedItem = { order.items.length }
            orderId={ order.id }
            key={ order.id }
            // openOrderModal={ () => openBackDrop(order) }
            to={ '/profile/wholesale_order/' + order.id }
            backgroundcolor={checkStatus.bgcolor}
            // "rgb(17, 137, 235)"
            order_status={checkStatus.status} /> 
          )
      }

} )

  }

  else {

        if( orders && orders.length < 1 ){
          mappingOrders = <div className="myorder-div_empty" >
                                  <img src={Ordertruck} alt="" className="myorder-div_empty_img" />
                                  <div className="myorder-div_empty_text" > You haven't ordered for any product yet. </div>
                                  <Link to="/" className="myorder-div_empty_btn">
                                      Order a product
                                  </Link>
                          </div>
        }else{
          mappingOrders = <BtnSpin bgColor="rgba(13, 194, 94, 0.986)" />
        }

  }


      return ( 

        <>

        <Backdrop
          show={ openModal }
        >

          <OrderModalDiv
            ordertobeChosen={ order }
            closeModal={ closeModal }
            />

        </Backdrop>

          <div className="myorder-div" >

            <div className="myorder-div_top" >
                My Orders
            </div>

            <div className="myorder-div_mid" >
                { mappingOrders }
            </div>

          </div>

        </>  
      );

}

export default Myorderdiv;