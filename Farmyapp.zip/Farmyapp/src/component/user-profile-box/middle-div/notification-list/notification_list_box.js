import React from 'react';
import Notificateli from './list-ind/list_ind';

const NotificationListbox = (props) => {

      return ( 

        <div className="notification-list-box" >
            <div className="notification-list-box-top" >
                notifications
            </div>
            <div className="notification-list-box-middle" >
                <div className="notification-list-box-middle-box" >
                    <Notificateli  title="You have not completed your registation" />
                    <Notificateli title="Welcome !!!!" />
                    <Notificateli type="read" title="Adebisi rated one of your product" />
                    <Notificateli type="read" title="Abass commented on your product" />
                    <Notificateli/>
                </div>
            </div>
        </div>

      );

}

export default NotificationListbox;