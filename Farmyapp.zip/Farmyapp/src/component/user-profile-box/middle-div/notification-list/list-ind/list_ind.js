import React from 'react';
import {Link} from 'react-router-dom';

const NotList = (props) => {

    if( props.type === 'read' ){
       var display =    
       <Link className="notlist-div-1" >
            <div className="notlist-div-1-top" > {props.title} </div>
            <div className="notlist-div-1-btm" >Hello mr ola we at farmyApp want to infporm you that you....</div>
       </Link> 
    }else{
         display =    
        <Link to="/notifications/2" className="notlist-div-1" >
             <div className="notlist-div-1-top notlist-div-1-toop" > {props.title} </div>
             <div className="notlist-div-1-btm" >Hello mr ola we at farmyApp want to infporm you that you....</div>
        </Link> 
    }

      return (
        
        <div className="notlist-div" >
            {display}
        </div>
        
      );

}

export default NotList;