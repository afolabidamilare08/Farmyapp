import React from 'react';
import Svg from '../../../../utilities/Svg';

const EmptydetComponent = (props) => {

      return ( 

        <div className="paymentdetbox-box-empty" >

            <div className="paymentdetbox-box-empty-first" >
                <span> You Haven't Registered Any Credit Card  </span>
                    <button className="paymentdetbox-box-empty-btn" onClick={ props.Add_card } >
                        Add a card
                        <Svg
                        className="paymentdetbox-box-empty-btn-ic"
                        href="opps.svg#icon-credit-card-alt" />
                    </button>
            </div>


            <div className="paymentdetbox-box-empty-add" style={{ transform: props.readytoadd ? 'translate(0)' : 'translateY(-60rem)',  alignSelf: 'center' , justifySelf: 'center' }} >
                    {/* <div className="paymentdetbox-box-empty-add-top" > 
                        <button className="paymentdetbox-box-empty-add-top-cancel" onClick={ props.Add_card } >cancel</button> 
                    </div> */}

                <div className="paymentdetbox-box-empty-add-form" >
                    
                    <div className="paymentdetbox-box-empty-add-form-div" >
                        <label className="paymentdetbox-box-empty-add-form-div-label" for="number" >Card number</label>
                        <input
                        value={ props.cardnumberValue }
                        onChange={ props.cardnumberOnchange }
                        id="number"
                         placeholder="000 000 000 000"
                         className="paymentdetbox-box-empty-add-form-div-input" />
                        <Svg
                         className="paymentdetbox-box-empty-add-form-div-ic"
                         href="opps.svg#icon-credit-card-alt" />
                    </div>

                    <div className="paymentdetbox-box-empty-add-form-divs" >

                        <div className="paymentdetbox-box-empty-add-form-divs-1" >

                            <label className="paymentdetbox-box-empty-add-form-divs-1-label" >Expiry date</label>
                            <input 
                             className="paymentdetbox-box-empty-add-form-divs-1-input"
                             placeholder="12 / 19"
                             value={props.cardexpValue}
                             onChange={props.cardexpOnchange}
                             />
                             <Svg
                              className="paymentdetbox-box-empty-add-form-divs-1-ic"
                              href="sprite.svg#icon-calendar" />

                        </div>

                        <div className="paymentdetbox-box-empty-add-form-divs-1" >

                                <label className="paymentdetbox-box-empty-add-form-divs-1-label" >cvc</label>
                                <input 
                                className="paymentdetbox-box-empty-add-form-divs-1-input"
                                placeholder="000"
                                value={props.cardcvcValue}
                                onChange={props.cardcvcOnchange}
                                />
                                <Svg
                                className="paymentdetbox-box-empty-add-form-divs-1-ic"
                                href="contact.svg#icon-lock1" />

                        </div>

                    </div>

                    <div className="paymentdetbox-box-empty-add-form-sbt" >
                        <button className="paymentdetbox-box-empty-add-form-sbt-btn" onClick={ props.add_card_to } >
                            Add Card
                        </button>
                    </div>

                </div>

            </div>


        </div>

      );

}

export default EmptydetComponent;