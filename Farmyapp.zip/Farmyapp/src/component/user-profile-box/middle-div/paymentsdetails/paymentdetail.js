import React , { useState } from 'react';
import Emptydetdiv from './emptypaymentsdetails/emptypaydet';
import Availablediv from './availablepayments/availablepaymentdet-div';
import { useVerifynum } from '../../../utilities/checkingforletter';
import Topbanner from '../../../utilities/top-banner-msg/topbannermsg';

const Paymentdetbox = (props) => {

    const [ creditcard , setcreditcard ] = useState( [  ] )
    const [ readytoadd , setreadytoadd  ] = useState( false )
    const [ msg , setmsg ] = useState( { status: false , msg : '' , bcolor: '' } )

    const [ card_det , setcard_det ] = useState( { cardnumber: '' , exp_date: '' , cvc: '' } )

    const cardnumberHandler = (event) => {
        setcard_det( { ...card_det , cardnumber:event.target.value } )
    }

    const cardexpHandler = (event) => {
        setcard_det( { ...card_det , exp_date:event.target.value } )
    }

    const cardcvcHandler = (event) => {
        setcard_det( { ...card_det , cvc: event.target.value } )
    }

    const closetopbannerHandler = () => {
        setmsg( { status: false , msg : '' , bcolor: ''  } )
    }

    const Add_CardHandler = () => {

        setmsg( { ...msg , status: true , msg: 'Please Wait Your Card is being processed......' , bcolor: 'orange' } )

        const [ get1 ] = useVerifynum(card_det.cvc)
        const [ get2 ] = useVerifynum(card_det.cardnumber)

        if ( card_det.cardnumber === '' || card_det.cvc === '' || card_det.exp_date === '' ){
            setmsg( { ...msg , status: true , msg: 'All Fileds must be Filled ' , bcolor: 'rgb(255, 62, 62)' } )
        }

        // && ( card_det.cardnumber !== '' || card_det.cvc !== '' || card_det.exp_date !== '' )

        else{

            if( !get1 || !get2 ){
                setmsg( { ...msg , status: true , msg: 'Card number , Expiry date and cvc should only contain Numbers ' , bcolor: 'rgb(255, 62, 62)' } )
            }

            else{
                const oldarray = [ ...creditcard ]
                const gathdata = { cardNumber: card_det.cardnumber , cardExp: card_det.exp_date , cardCvc: card_det.cvc }
                oldarray.push(gathdata)
                setcreditcard( oldarray )
                setmsg( { ...msg , status: true , msg: ' Credit card was successfully registered  ' , bcolor: 'rgb(39, 180, 39)' } )
            }

        }


    }

      return ( 
            <div className="paymentdetbox-box">
                {/* "rgb(255, 62, 62)" */}
                <Topbanner
                 backgroundcolor={msg.bcolor}
                 show={msg.status}
                 closeshow={ closetopbannerHandler }
                 message={msg.msg} />
                
                { creditcard.length === 0 ? 

                  <Emptydetdiv
                    readytoadd={readytoadd}
                    Add_card={ () => setreadytoadd(!readytoadd) }
                    cardnumberValue={card_det.cardnumber}
                    cardnumberOnchange={cardnumberHandler}
                    cardexpValue={card_det.exp_date}
                    cardexpOnchange={cardexpHandler}
                    cardcvcValue={card_det.cvc}
                    cardcvcOnchange={cardcvcHandler}
                    add_card_to={Add_CardHandler}
                     /> 
                    
                    
                    : <Availablediv/>    }

            </div>
      );

}

export default Paymentdetbox;