import React from 'react';
import Svg from '../../../../utilities/Svg';

const AvailablepaymentDiv = (props) => {

      return ( 

        <div className="available-paymentdiv" >
            <div className="paymentdetbox-box-empty-first" >
                <span> You have 1 credit card registered  </span>
                    <button className="paymentdetbox-box-empty-btn" onClick={ props.Add_card } >
                        Add a card
                        <Svg
                        className="paymentdetbox-box-empty-btn-ic"
                        href="opps.svg#icon-credit-card-alt" />
                    </button>
            </div>
        </div>

      );

}

export default AvailablepaymentDiv;