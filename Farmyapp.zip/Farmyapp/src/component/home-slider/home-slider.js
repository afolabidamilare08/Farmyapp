import React, {useState} from 'react';
import Shop from '../utilities/shop(1).png';
import Serve from '../utilities/customer-service.png';
import Svg from '../utilities/Svg';
import Logo from '../utilities/logo.png';
import Buyit from '../utilities/online.png';
import {Sliserdetails,Sliserdetails2} from './slider-details/sliderdetails';
import Referal from '../../pages/about_referal/5867.jpg'


const SliderIndex = (props) => {

    const [ datatoshow , setdatatoshow ] = useState({
        number:1
    })

    // const [ speed , setspeed ] = useState(15000)

    // setTimeout(() => {
    //     if( datatoshow.number === 4 ){
    //         setdatatoshow({
    //             number: 1
    //         })
    //     }else{
    //         setdatatoshow({
    //             number: datatoshow.number + 1
    //         })
    //     }
    // }, speed);

    const MoveSliderRightHandler = () => {
        if( datatoshow.number === 4 ){
            setdatatoshow({
                number:1
            })
        }else{
            setdatatoshow({
                number:datatoshow.number + 1
            })
        }
    }


    const MoveSliderleftHandler = () => {
        if( datatoshow.number === 1 ){
            setdatatoshow({
                number:4
            })
        }else{
            setdatatoshow({
                number:datatoshow.number - 1
            })
        }
    }

    var slideIndex = [ 1 , 2 , 3 , 4 , 5 ]


    if( datatoshow.number === 1 ){
        var Showdem =  <Sliserdetails2
                        maintitle="FarmyApp"
                        subdetails="Refer the farmers around you to FarmyApp and get 16.67% of our profit from the farmer's first 30 transactions."
                        to="/my_referrals"
                        src={Referal}
                        action="start reffering"
                        icon="contact.svg#icon-person" />
    }else{
        if( datatoshow.number === 2 ){
            Showdem = <Sliserdetails2
                            maintitle="Sell Product"
                            subdetails="FarmyApp is an E-commerce site that allows traders in the agricultural sector sell invaluable products to buyers"
                            to="/sell"
                            src={Shop}
                            action="Start Trading"
                            icon="sprite3.svg#icon-store_mall_directorystore" />
        }else{
            if( datatoshow.number === 3 ){
                Showdem = <Sliserdetails
                                maintitle="Hire Services"
                                subdetails=" On FarmyApp you can hire professionals , machineries or tools in different agricultural sectors from different part of the country  "
                                to="/services"
                                src={Serve}
                                action="Hire Service"
                                icon="sprite4.svg#icon-handshake-o" />
            }else{
                if( datatoshow.number === 4 ){
                    Showdem = <Sliserdetails2
                                    maintitle="Buy Products"
                                    subdetails=" FarmyApp allows you to buy valuable products from different parts of the country at cheap prices  "
                                    to="/"
                                    src={Buyit}
                                    action="Buy Product"
                                    icon="sprite3.svg#icon-store_mall_directorystore" />
                }else{
                    if ( datatoshow.number === 5 ) {
                        Showdem =  <Sliserdetails
                                        maintitle="FarmyApp"
                                        subdetails="A platform built basically for the buying and selling of farm product at low prices"
                                        to="/signup"
                                        src={Logo}
                                        action="Sign Up"
                                        icon="contact.svg#icon-person_add" />
                    }
                }
            }
        }
    }



      return ( 

        <div className="coverimg"  >
            <Svg className="coverimg-left" href="contact.svg#icon-chevron-thin-left" onClick={ MoveSliderleftHandler } />
            { Showdem }
            <Svg className="coverimg-right" href="contact.svg#icon-chevron-thin-right" onClick={ MoveSliderRightHandler } />
            <div className="coverimg-btm" >
                { slideIndex.map( ring => {
                    return <div className="coverimg-btm-rng" key={ring} onClick={  () => setdatatoshow({
                        number:ring
                    }) } style={{
                        backgroundColor: datatoshow.number === ring ? 'lightgray' : ''
                    }} ></div>
                } ) }
            </div>
        </div>

      );

}

export default SliderIndex;