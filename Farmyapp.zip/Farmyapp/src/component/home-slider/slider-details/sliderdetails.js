import React from 'react';
import {Link} from 'react-router-dom';
import Svg from '../../utilities/Svg';

export const Sliserdetails = (props) => {

      return ( 

        <>
        
        <img className="coverdiv-img" alt="" src={props.src} />

        <div className="coverdiv" >
                <div className="coverimg-txt" >
                      {props.maintitle}
                </div>
                <div className="coverimg-txt-sub" >
                    {props.subdetails}
                </div>
                <Link to={props.to} className="coverimg-btn" >
                    {props.action}
                    <Svg className="coverimg-ic"
                    href={props.icon} />                     
                </Link>
        </div>

        </>

      );

    //   A platform built basically for the buying and selling
                    // of farm product at low prices 

}



export const Sliserdetails2 = (props) => {

  return ( 

    <>
        
      <img className="coverdiv-img" alt="" src={props.src} />

      <div className="coverdiv-1" >
              <div className="coverimg-txt" >
                    {props.maintitle}
              </div>
              <div className="coverimg-txt-sub" >
                  {props.subdetails}
              </div>
              <Link to={props.to} className="coverimg-btn" >
                  {props.action}
                  <Svg className="coverimg-ic"
                  href={props.icon} />                     
              </Link>
      </div>

    </>

  );

//   A platform built basically for the buying and selling
                // of farm product at low prices 

}


export const Sliserdetails3 = (props) => {

  return ( 

    <>
        
      <img className="coverdiv-img" alt="" src={props.src} />

      <div className="coverdiv-1" >
              <div className="coverimg-txt" >
                    {props.maintitle}
              </div>
              <div className="coverimg-txt-sub" >
                  {props.subdetails}
              </div>
              <a href={props.to} download className="coverimg-btn" >
                  {props.action}
                  <Svg className="coverimg-ic"
                  href={props.icon} />                     
              </a>
      </div>

    </>

  );

//   A platform built basically for the buying and selling
                // of farm product at low prices 

}