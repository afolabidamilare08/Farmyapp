import React from 'react';
import BlogHomeList from '../../blog_utilities/blog_list/blog_list';

const BlogHome = (props) => {

      return ( 
          <div className="blogHome-div" >
              
              {/* <div className="blogHome-div-top" >
                    BLOGS
              </div> */}

              <BlogHomeList/>
              <BlogHomeList/>
              <BlogHomeList/>
              <BlogHomeList/>
              <BlogHomeList/>


          </div>
      );

}

export default BlogHome;