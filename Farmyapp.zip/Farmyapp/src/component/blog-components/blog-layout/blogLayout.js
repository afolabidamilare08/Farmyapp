import React from 'react';
// import Footerdiv from '../../../layout/footer/footer';
import BlogHeader from './blog-header/blogHeader';
import { Switch , Route } from 'react-router-dom';
import BlogHome from '../blog_pages/home/blog_home';

const BlogLayout = (props) => {

    // console.log(props)

      return ( 

          <>

          <div className="blog-layout-div" >

            <BlogHeader/>

            <div className="blog-layout-div_split">

                <div className="blog-layout-div_split_left" >
                    <Switch>
                    <Route component={BlogHome} path="/blogs" />
                    </Switch>
                    {/* <Footerdiv/> */}
                </div>

                <div className="blog-layout-div_split_right" >

                    <div className="blog-layout-div_split_right_top" >

                        <input className="blog-layout-div_split_right_top_input" type="search" placeholder="Search Blogs...." />
                        <button className="blog-layout-div_split_right_top_button" >
                            Search
                        </button>

                    </div>

                </div>

            </div>

          </div>

          {/* <Footerdiv/> */}

          </>
      );

} 

export default BlogLayout;