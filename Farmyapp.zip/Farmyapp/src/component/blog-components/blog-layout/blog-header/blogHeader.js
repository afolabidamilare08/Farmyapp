import React from 'react';
import {Link} from 'react-router-dom'
import Logopng from '../../../../layout/header/logo/headerleftslide/olaiya1.png';
import Svg from '../../../utilities/Svg';

const BlogHeader = (props) => {

      return ( 

          <div className="blog-header-div" >

              <div className="blog-header-div_logo" >
                  <Link to='/' className="blog-header-div_logo_link" >
                      <img className="blog-header-div_logo_link_img" alt="" src={Logopng} />
                  </Link>
              </div>

              <form className="blog-header-div_search" >
                <input placeholder="Loooking for a blog ... ?" type="search" className="blog-header-div_search_input" />
                <button className="blog-header-div_search_btn" >
                    <Svg 
                      href="contact.svg#icon-search"
                      className="blog-header-div_search_btn_ic"   />
                </button>
              </form>

              <ul className="blog-header-div_left" >

                 <li className="blog-header-div_left_li" >
                    <Link to="#" className="blog-header-div_left_li_a" > About Us </Link>
                 </li>

                 <li className="blog-header-div_left_li" >
                    <Link to="#" className="blog-header-div_left_li_a" > Blogs </Link>
                 </li>

                 <li className="blog-header-div_left_li" >
                    <Link to="#" className="blog-header-div_left_li_a" > Referrals </Link>
                 </li>

                 <li className="blog-header-div_left_li" >
                    <Link to="#" className="blog-header-div_left_li_a" > Sign Up </Link>
                 </li>

              </ul>

          </div>

      );

}

export default BlogHeader;