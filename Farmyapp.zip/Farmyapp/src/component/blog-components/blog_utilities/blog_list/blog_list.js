import React from 'react';

const BlogHomeList = (props) => {

      return ( 
          <div className="blogHomelist" >

                <div className="blogHomelist_top" >
                    How To Write A Very Good Product Description
                </div>

                <div className="blogHomelist_time" >
                    August 25, 2019 by 
                        <span className="blogHomelist_time_writer" > Afolabi Damilare</span>
                        <div className="blogHomelist_time_dash" ></div>
                        <span className="blogHomelist_time_leave" > Leave a Comment </span>
                </div>

                <div className="blogHomelist_narrate" >
                    Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                    sed do eiusmod tempor incididunt ut labore et dolore magna
                    aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
                    ullamco laboris nisi ut aliquip ex ea commodo consequat. 
                    Duis aute irure dolor in reprehenderit in voluptate velit 
                    esse cillum dolore eu fugiat nulla pariatur. Excepteur sint 
                    occaecat cupidatat non proident, sunt in culpa qui officia 
                    deserunt mollit anim id est laborum.
                </div>

          </div>
      );

}

export default BlogHomeList;