import React from 'react';
// import Svg from '../utilities/Svg';

const Successmessage = (props) => {

      return ( 

        <div className="success_div" >
            {/* <Svg
             className="success_div-ic"
             href="contact.svg#icon-verified_user" /> */}
             {props.success}
        </div>

      );

}

export default Successmessage;