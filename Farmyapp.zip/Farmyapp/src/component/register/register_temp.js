import React from 'react';
import {Link} from 'react-router-dom';
import Leftlogoslide from '../../layout/header/logo/headerleftslide/leftlogoslide';



const Register_temp = (props) => {

      return ( 

        <form className="regiister_temp_div" onSubmit={props.register} >
           
           <Leftlogoslide/>

           <div className="regiister_temp_div-title" >
                Sign Up!
           </div>

            <div className="register_message" >
                {props.message}
            </div>

           <div className="regiister_temp_div-form" >
 
                <div className="regiister_temp_div-form-div1" >

                    <div className="regiister_temp_div-form-div1-1" >
                        <input type="text" placeholder="First name" className="regiister_temp_div-form-div1-1-input" value={props.firstnamevalue} onChange={props.firstnameonchange} />
                        <label className="regiister_temp_div-form-div1-1-label" >First name</label>
                    </div>

                    <div className="regiister_temp_div-form-div1-2" >
                        <input type="text" placeholder="Last name" className="regiister_temp_div-form-div1-2-input" value={props.lastnamevalue} onChange={props.lastnameonchange} />
                        <label className="regiister_temp_div-form-div1-2-label" >Last name</label>
                    </div>

                </div>

                <div className="regiister_temp_div-form-div2" >

                    <input type="text" placeholder="Username" className="regiister_temp_div-form-div2-input" value={props.usernamevalue} onChange={props.usernameonchange} />
                    <label className="regiister_temp_div-form-div2-label" >Username</label>

                </div> 

                <div className="regiister_temp_div-form-div2" >

                    <input type="email" placeholder="Email Address" className="regiister_temp_div-form-div2-input" value={props.emailvalue} onChange={props.emailonchange} />
                    <label className="regiister_temp_div-form-div2-label" >Email Address</label>

                </div>

                <div className="regiister_temp_div-form-div1 password_confirm_box" >

                    <div className="regiister_temp_div-form-div1-1 " >
                        <input type="password" placeholder="password" className="regiister_temp_div-form-div1-1-input" value={props.passwordvalue} onChange={props.passwordonchange} />
                        <label className="regiister_temp_div-form-div1-1-label" >password</label>
                    </div>

                    <div className="regiister_temp_div-form-div1-2" >
                        <input type="password" placeholder="Confirm password" className="regiister_temp_div-form-div1-2-input" value={props.confirmpasswordvalue} onChange={props.confirmpasswordonchange} />
                        <label className="regiister_temp_div-form-div1-2-label" >Confirm password</label>
                    </div>

                </div>

                <div className="regiister_temp_div-form-sub" >
                    <button className="regiister_temp_div-form-sub-btn" onClick={props.register} disabled={props.disabled} >
                        {props.action}
                    </button>
                </div>
{/* 
                <div className="regiister_temp_div-form-already" >
                    <Link to="/signin" className="regiister_temp_div-form-already-link" >I aleady have an account</Link>
                </div> */}

                <div className="regiister_temp_div-form-already" > 
                        <sapn className="regiister_temp_div-form-already-txt" >  I already have an account  </sapn>
                        <Link to={ props.refer ? props.refer : "/signin" } className="regiister_temp_div-form-already-link" >sign in</Link>
                </div> 

           </div>

        </form>

      );

}

export default Register_temp;