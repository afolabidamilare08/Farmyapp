import React from 'react';
import Svg from '../utilities/Svg';

export const OurTeamComp = (props) => {

      return ( 
          <div className="aboutuspage_ourteam_mid_div" >

            <div className="aboutuspage_ourteam_mid_div_pic" >
                <img src={props.img} alt="" className="aboutuspage_ourteam_mid_div_pic_img" />
            </div>

            <div className="aboutuspage_ourteam_mid_div_name" >
                {props.name}
            </div>

            <div className="aboutuspage_ourteam_mid_div_title" >
                {props.title}
            </div>

            <div className="aboutuspage_ourteam_mid_div_social" >

                    <a href="faccebook.com" className="aboutuspage_ourteam_mid_div_social_link" >
                        <Svg
                         className="aboutuspage_ourteam_mid_div_social_link_ic"
                         href="sprite4.svg#icon-social-twitter" />
                    </a>

                    <a href="faceebook.com" className="aboutuspage_ourteam_mid_div_social_link" >
                        <Svg
                         className="aboutuspage_ourteam_mid_div_social_link_ic"
                         href="contact.svg#icon-facebook-official" />
                    </a>

                    <a href="facebook.com" className="aboutuspage_ourteam_mid_div_social_link" >
                        <Svg
                         className="aboutuspage_ourteam_mid_div_social_link_ic"
                         href="sprite4.svg#icon-linkedin" />
                    </a>

            </div>
            

          </div>
      );

}

export const OurServicesComp = (props) => {

    return(

        <div className="aboutuspage_ourservices_div" >

            <div className="aboutuspage_ourservices_div_left" >
                <img src={props.img} alt="" className="aboutuspage_ourservices_div_left_img" />
            </div>

            <div className="aboutuspage_ourservices_div_right" >

                <div className="aboutuspage_ourservices_div_right_top" >
                    {props.text}
                </div>

                <div className="aboutuspage_ourservices_div_right_narrate" >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore magna 
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
                        ullamrit in voluptate velit esse cillum 
                        dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore magna 
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
                        ullamrit in voluptate velit esse cillum 
                        dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                </div>

                <button className="aboutuspage_ourservices_div_right_button" >
                    Get Started
                </button>
                
            </div>

        </div>

    );

}

export const OurServicesComp2 = (props) => {

    return(

        <div className="aboutuspage_ourservices_div" >

            <div className="aboutuspage_ourservices_div_right" >

                <div className="aboutuspage_ourservices_div_right_top" >
                    {props.text}
                </div>

                <div className="aboutuspage_ourservices_div_right_narrate" >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore magna 
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
                        ullamrit in voluptate velit esse cillum 
                        dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore magna 
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
                        ullamrit in voluptate velit esse cillum 
                        dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                </div>

                <button className="aboutuspage_ourservices_div_right_button" >
                    Get Started
                </button>
                
            </div>

            <div className="aboutuspage_ourservices_div_left" >
                <img src={props.img} alt="" className="aboutuspage_ourservices_div_left_img" />
            </div>

        </div>

    );

}

export const HowitWorks = (props) => {
    
    return(
        <div className="aboutuspage_howitworks_mid_div" >

                    <div className="aboutuspage_howitworks_mid_div_top" >
                        <div className="aboutuspage_howitworks_mid_div_top_left" >
                            {props.number}.
                        </div>
                        <div className="aboutuspage_howitworks_mid_div_top_right" >
                            <Svg 
                                className="aboutuspage_howitworks_mid_div_top_right_svg"
                                href={props.ic}
                            />
                        </div>
                    </div>

                    <div className="aboutuspage_howitworks_mid_div_head" >
                        {props.title}
                    </div>

                    <div className="aboutuspage_howitworks_mid_div_narrate" >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore magna 
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
                        ullamrit in voluptate velit esse cillum 
                        dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                    </div>

                </div>
    );

}