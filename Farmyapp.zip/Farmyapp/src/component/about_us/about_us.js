import React from 'react';
import Apppic from './app.png';
import Ola from './ola.jpg';
import Covenant from './cov.jpg';
import Dami from './dami.jpg';
import BuySell from './business.png';
import Services from './service.png';
import BlogHeader from '../blog-components/blog-layout/blog-header/blogHeader';
import { OurTeamComp, OurServicesComp, OurServicesComp2, HowitWorks } from './about_us_comp';
// import Svg from '../utilities/Svg';
// import { Link } from 'react-router-dom';


const AboutUsPage = (props) => {
 


      return ( 

            <div className="aboutuspage" >

            <BlogHeader/>   

                <div className="aboutuspage_top" >
                    {/* <img src={About} alt="" className="aboutuspage_top-img" /> */}
                </div>

                <div className="aboutuspage_about" >
                    <div className="aboutuspage_about_big" >
                        About Us
                    </div>
                    <div className="aboutuspage_about_narrate" >
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                        sed do eiusmod tempor incididunt ut labore et dolore magna 
                        aliqua. Ut enim ad minim veniam, quis nostrud exercitation 
                        ullamrit in voluptate velit esse cillum 
                        dolore eu fugiat nulla pariatur. Excepteur sint occaecat 
                        Ut enim ad minim veniam, quis nostrud exercitationco laboris nisi ut aliquip ex ea commodo consequat. Duis 
                        aute irure dolor in reprehenderit in voluptate velit esse cillum 
                        dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                        Ut enim ad minim veniam, quis nostrud exercitation 
                        ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis 
                        aute irure dolor in reprehende 
                        ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis 
                        aute irure dolor in reprehenderit in voluptate velit esse cillum 
                        dolore eu fugiat nulla pariatur. Excepteur sint occaecat
                        Ut enim ad minim veniam, quis nostrud exercitation 
                        ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis 
                        aute irure dolor in reprehenderit in voluptate velit esse cillum 
                        dolore eu fugiat nulla pariatur. Excepteur sint occaecat 
                        cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
                    </div>
                </div>

                <div className="aboutuspage_howitworks" >

                    <div className="aboutuspage_howitworks_top" >
                        How Farmyapp Works
                    </div>

                    <div className="aboutuspage_howitworks_mid" >

                        <HowitWorks
                         ic="contact.svg#icon-person_add"
                         number="1"
                         title="Create An Account On FarmyApp" />

                        <HowitWorks
                         ic="sprite4.svg#icon-store_mall_directorystore"
                         number="2"
                         title="Sell Agricultural Products Before Harvest" />

                         
                        <HowitWorks
                         ic="sprite4.svg#icon-work"
                         number="3"
                         title="Render Agricultural Services" />

                        <HowitWorks
                         ic="sprite4.svg#icon-local_grocery_storeshopping_cart"
                         number="4"
                         title="Buy/Hire Agricultural Products/Services" />

                    </div>

                    <button className="aboutuspage_howitworks_btn" >
                        Get Started
                    </button>

                    <div className="aboutuspage_howitworks_ourapp" >
                        <div className="aboutuspage_howitworks_ourapp_head" >
                            Download <span className="aboutuspage_howitworks_ourapp_head_span" >FarmyApp</span>. 
                        </div>
                        <div className="aboutuspage_howitworks_ourapp_small" >
                            Buy and sell agricultural products and services before,during and after harvest.
                        </div>
                        <a href="googleplay.com" className="aboutuspage_howitworks_ourapp_a" >
                            <img src={Apppic} className="aboutuspage_howitworks_ourapp_a_img" alt="" />
                        </a>
                    </div>

                </div>

                <div className="aboutuspage_ourservices" >

                    <OurServicesComp
                     img={BuySell}
                     text="Buy And Sell Agricultural Products" />

                    <OurServicesComp2
                     img={Services}
                     text="Hire And Render Agricultural Services" />

                </div>

                <div className="aboutuspage_ourteam" >

                    <div className="aboutuspage_ourteam_top" >
                        Meet Our Team
                    </div>

                    <div className="aboutuspage_ourteam_mid" >

                        <OurTeamComp 
                            img={Ola}
                            name="Abass Olaiya"
                            title="ChIef Executive Officer (Ceo)" />

                        <OurTeamComp 
                            img={Covenant}
                            name="Covenant Ifeoluwa"
                            title="ChIef Marketing Officer (Cmo)" />

                        <OurTeamComp 
                            img={Dami}
                            name="Afolabi Damilare"
                            title="ChIef Technology Officer (Cto)" />

                    </div>

                </div>

            </div>

      )

}

export default AboutUsPage;