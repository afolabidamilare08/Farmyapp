import React from 'react';

 export const OrderWithDelivery = (props) => {

    return (
        <div className="OrderList-div" >
            <div className="OrderList-div-first" >

                <div className="OrderList-div-first-det" >
                    { props.Orderimg ?   
                    <div className="OrderList-div-first-det-img" >
                        <img alt="" src={props.Orderimg} className="OrderList-div-first-det-img-img" />
                    </div> : '' }
                    <div className="OrderList-div-first-det-name" >
                        {props.productName}
                    </div>
                </div>

                { props.status ?
            
                    <div className="OrderList-div-first-status" style={{ backgroundColor:props.bgColor }} >
                        {props.status}
                    </div>

                : null
            
                 }

            </div>

            <div className="OrderList-div-to-second" > 
            
                <div className="OrderList-div-to-second-1" >
                    Buyer's Details
                </div>

                <div className="OrderList-div-to-second-2" style={{ display: props.showAddress ? 'block' : 'none' }} >
                    {props.address}
                        <br/> 
                    {props.lga + ' , ' + props.state} 
                        <br/>
                        <br/>
                    { props.theFirst_name } { props.theLast_name }    
                        <br/>
                    { props.theNumber }     
                </div>

                <div className="OrderList-div-to-second-2" style={{ display: !props.showAddress ? 'block' : 'none' }} >
                    { props.theFirst_name } { props.theLast_name }    
                        <br/>
                    { props.theNumber }     
                </div>
                
            </div>


            <div className="OrderList-div-second" >


            <div className="OrderList-div-second-seg" >
                    <div className="OrderList-div-second-seg-1" > Quantity </div>
                    <div className="OrderList-div-second-seg-2" > {props.quantity} { props.measurement_scale } </div>
            </div>

            <div className="OrderList-div-second-seg" >
                <div className="OrderList-div-second-seg-1"  > Product Cost </div>
                <div className="OrderList-div-second-seg-2" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.product_cost)} </div>
            </div>

            <div className="OrderList-div-second-seg" >
                <div className="OrderList-div-second-seg-1"  > Transport Cost </div>
                <div className="OrderList-div-second-seg-2" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.tfare)} </div>
            </div>

            <div className="OrderList-div-second-seg" >
                <div className="OrderList-div-second-seg-1"  > Total Cost </div>
                <div className="OrderList-div-second-seg-2" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.totalcost)} </div>
            </div>

            </div>
                { props.pending ?
                
                <div className="meorder-div-third" >
                    <button className="meorder-div-third-btn" onClick={props.ChangeToDelivered} > Change product status to delivered </button>
                </div>
                
                : null }

                { props.switchtointransit ?
                
                <div className="meorder-div-third" >
                    <button className="meorder-div-third-btn-2" onClick={props.ChangeTointransit} > Change order status to in transit </button>
                </div>
                
                : null }
        </div>
    );

}



export const OrderProductWithDelivery = (props) => {

    return (
        <div className="OrderList-div" style={{
            width:props.width
        }} >
            <div className="OrderList-div-first" >

                <div className="OrderList-div-first-det" >
                    { props.Orderimg ?   
                    <div className="OrderList-div-first-det-img" >
                        <img alt="" src={props.Orderimg} className="OrderList-div-first-det-img-img" />
                    </div> : '' }
                    <div className="OrderList-div-first-det-name" >
                        {props.productName}
                    </div>
                </div>

                { props.status ?
            
                    <div className="OrderList-div-first-status" style={{ backgroundColor:props.bgColor }} >
                        {props.status}
                    </div>

                : null
            
                 }

            </div>

                <div className="OrderList-div-to-second" > 
                    <div className="OrderList-div-to-second-1" >
                        Product's Details
                    </div>

                    <div className="OrderList-div-to-second-2" style={{display: props.showAddress ? 'block' : 'none' }} >
                        {props.address}
                            <br/> 
                        {props.lga + ' , ' + props.state} 
                            <br/>
                            <br/>
                        { props.theFirst_name } { props.theLast_name }    
                            <br/>
                        { props.theNumber }     
                    </div>

                    {/* <div className="OrderList-div-to-second-2" style={{display: !props.showAddress ? 'block' : 'none' }} >
                        {props.address}
                            <br/> 
                        {props.lga + ' , ' + props.state} 
                    </div> */}
                    
                </div>


            <div className="OrderList-div-second" >


            <div className="OrderList-div-second-seg" >
                    <div className="OrderList-div-second-seg-1" > Quantity </div>
                    <div className="OrderList-div-second-seg-2" > {props.quantity} { props.measurement_scale } </div>
            </div>

            <div className="OrderList-div-second-seg" >
                <div className="OrderList-div-second-seg-1"  > Product Cost </div>
                <div className="OrderList-div-second-seg-2" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.product_cost)} </div>
            </div>

            <div className="OrderList-div-second-seg" >
                <div className="OrderList-div-second-seg-1"  > Transport Cost </div>
                <div className="OrderList-div-second-seg-2" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.tfare)} </div>
            </div>

            <div className="OrderList-div-second-seg" >
                <div className="OrderList-div-second-seg-1"  > Total Cost </div>
                <div className="OrderList-div-second-seg-2" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.totalcost)} </div>
            </div>

            </div>
                { props.pending ?
                
                <div className="meorder-div-third" style={{
                    padding:'1.5rem'
                }} >
                    <button className="meorder-div-third-btn" onClick={props.ChangeToDelivered} > Change product status to delivered </button>
                </div>
                
                : null }

                { props.switchtointransit ?
                
                <div className="meorder-div-third" style={{
                    padding:'1.5rem'
                }} >
                    <button className="meorder-div-third-btn-2" onClick={props.ChangeTointransit} > Change order status to in transit </button>
                </div>
                
                : null }
        </div>
    );

}

