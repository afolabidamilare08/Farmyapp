import React from 'react';
import {Link} from 'react-router-dom';
import Leftlogoslide from '../../layout/header/logo/headerleftslide/leftlogoslide';

const Login = (props) => {

    if(props.message){
        var show =  <div className="loginerror" > {props.message} </div>
    }

      return ( 

        <form className="login-box" onSubmit={props.login} >

            <Leftlogoslide/>

            <div className="login-box-sign-in" >
                Sign In!
            </div>

            {show}

            <div className="login-box-form-div" >

                <div className="login-box-form-div-form" >
                    <input type="text" placeholder="Username" className="login-box-form-div-form-input" value={props.usernamevalue} onChange={props.usernameonchange} />
                    <label className="login-box-form-div-form-label" >username</label> 
                </div> 

                <div className="login-box-form-div-form login-password" >
                    <input type={props.type} placeholder="Password" className="login-box-form-div-form-input" value={props.passwordvalue} onChange={props.passwordonchange} />
                    <label className="login-box-form-div-form-label" >password</label>
                </div>
                
                <div className="showpassword-div" >

                    <input type="checkbox" value={props.showpassword} onChange={props.onchange_showpassword} id="showpassword" className="showpassword-div-input" />

                    <label for="showpassword" className="showpassword-div-label" > show password </label>

                </div>

                <div className="login-btn-div" >
                    <button className="login-btn-div-btn" onClick={props.login} disabled={props.disabled} >
                            {props.action}
                    </button>
                </div>

                <div className="dont-have-account" >
                    <div className="dont-have-account-div" > 
                        <span className="dont-have-account-div-txt" >  I don't have an account  </span>
                        <Link to="/signup" className="dont-have-account-lin" >sign up</Link>
                    </div> 
                    <Link to='/resetPassword' className="forgot-password-lin" > Forgot password </Link>
                </div>

                <div className="forgot-password" >
                   
                </div>

            </div>
        </form>

      );

}

export default Login;