import React from 'react';
import Svg from '../../utilities/Svg';


const TransportForm = (props) => {

      return ( 

        < div className="sell-template-div-middle-transport-body-select" >

        <div className="sell-template-div-middle-transport-body-select_1" onClick={ props.trans_select } >
            <div className="sell-template-div-middle-transport-body-select_1-top" style={ { display: props.selected_mean ? '' : 'none' } } >
                <div className="sell-template-div-middle-transport-body-select_1-top-mid" >
                    <Svg
                    href="contact.svg#icon-done_outline"
                    className="sell-template-div-middle-transport-body-select_1-top-mid-ic"
                    />
                </div>
            </div>
            <img className="sell-template-div-middle-transport-body-select_1-img" alt="" src={props.img} />
        </div>

        <div className="sell-template-div-middle-transport-body-select_2" > {props.means} </div>

        </div >

      );

}

export default TransportForm;