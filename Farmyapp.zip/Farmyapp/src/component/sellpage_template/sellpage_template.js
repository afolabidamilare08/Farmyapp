import React , {useState} from 'react';
import Pickimage from './pickimage/pickimage';
import Img from './1.jpg';
import Img2 from './2.jpg';
import Img3 from './3.jpg';
import TransportForm from './transport_form/transport_form';
import { OrdinaryTextInput, OrdinaryTextArea , OrdinaryPriceandSale , OrdinaryHarvestDate, Toggletitle } from './sell_temp/sell_.temp';


const Selltemplate = (props) => {
    
    const [ showProdinfo , setshowProdinfo ] = useState(true)
    const [ showAddressinfo , setshowAddressinfo ] = useState(false)
    const [ showDeliveryinfo , setshowDeliveryinfo ] = useState(false)
    const [ showAccountinfo , setshowAccountinfo ] = useState(false)

      return ( 

          <div className="sell-template-div" >

                <div className="sell-template-div_top" >
                    { props.whataction }
                </div>

                <div className="sell-template-div-middle" >
                    
                    <Toggletitle
                     title="Product Information"
                     position={showProdinfo}
                     toggleposition={ () => setshowProdinfo(!showProdinfo) } />

                    <div className="sell-template-div-middle-product" style={{
                        display: showProdinfo ? 'block' : 'none'
                    }} >

                        <OrdinaryTextInput
                         error={props.productnameerror}
                         label="Product Name"
                         value={props.productnamevalue}
                         onChange={props.productnameonChange} 
                        />

                         <OrdinaryTextArea
                          error={props.productdescerror}
                          label="Product Description"
                          value={props.productdescriptionvalue}
                          onChange={props.productdescriptiononChange}
                         />

                        <OrdinaryPriceandSale 
                            pricevalue={props.productpricevalue}
                            priceonChange={props.productpriceonChange}
                            scalevalue={props.productscalevalue}
                            scaleonChange={props.productscaleonChange}
                        />

                        <OrdinaryTextInput
                         error={props.qtyavilerror}                         
                         label="Quantity available for sale e.g 45"
                         value={props.productavailablevalue}
                         onChange={props.productavailableonChange} 
                         />

                         <OrdinaryHarvestDate
                          harvestvalue={props.productharvestdatevalue}
                          harvestonChange={props.productharvestdateonChange}
                          />

                        <div className="sell-template-div-middle-product-gallery" >
                            
                            <div className="sell-template-div-middle-product-gallery-top" >
                                Add Photo 
                                <div className="sell-template-div-middle-product-gallery-top_info" >
                                    You are Expected to add pictures showing the current state of the product ,
                                    <br/>
                                    Supported image formats are *jpg* , *jpeg* , and *png*
                                </div>
                            </div>

                            <Pickimage
                             story={props.story1}
                             error={props.error1}
                             choseimage={props.choosefirstimage}
                             preview={props.previewfirstimage} />
                            <Pickimage
                             story={props.story2}
                             error={props.error2}
                             choseimage={props.choosesecondimage}
                             preview={props.previewsecondimage} />
                            <Pickimage
                             story={props.story3}
                             error={props.error3}
                             choseimage={props.choosethirdimage}
                             preview={props.previewthirdimage} />
                        </div>

                    </div>

                    <Toggletitle
                        title="Delivery Information"
                        position={showDeliveryinfo}
                        toggleposition={ () => setshowDeliveryinfo(!showDeliveryinfo) } />

                        <div className="sell-template-div-middle-transport" 
                        
                            style={{
                                display: showDeliveryinfo ? 'block' : 'none' 
                            }}

                        >

                            <div className="sell-template-div-middle-transport-top" >
                                Please select the vehicle suitable to carry your product  
                            </div>

                            <div className="sell-template-div-middle-transport-body" >
 
                                <TransportForm
                                 img={Img}
                                 trans_select={ props.select_trans_1 }
                                 selected_mean={ props.selected_mean_1 }
                                 means='napep'  />

                                <TransportForm
                                 img={Img2}
                                 trans_select={ props.select_trans_2 }
                                 selected_mean={ props.selected_mean_2 }
                                 means='cabster'  />

                                <TransportForm
                                  img={Img3}
                                 trans_select={ props.select_trans_3 }
                                 selected_mean={ props.selected_mean_3 }
                                 means='Trailer'  /> 

                            </div>

                            <OrdinaryTextInput
                             error={props.vchcancarryerror}                            
                             label={"Amount of " + props.productscalevalue + " the selected vehicle can carry "}
                             value={props.amoutcancarry}
                             onChange={props.onChangeamoutcancarry}
                             />

                        </div>

                    <Toggletitle
                     title="Address Information"
                     position={showAddressinfo}
                     toggleposition={ () => setshowAddressinfo(!showAddressinfo) } />


                    <div className="sell-template-div-middle-seller"
                      
                      style={{
                          display: showAddressinfo ? 'block' : 'none'
                      }}

                     >

                        <OrdinaryTextInput
                         error={props.countryerror}                        
                         label="Country"
                         disable
                         value={props.countryvalue}
                         onChange={props.countryonChange} />

                        <OrdinaryTextInput
                         error={props.stateerror}
                         label="State"
                         value={props.statevalue}
                         onChange={props.stateonChange} />

                        <OrdinaryTextInput
                         error={props.lgaerror}
                         label="Local Government Area"
                         value={props.lgavalue}
                         onChange={props.lgaonChange} />

                        <OrdinaryTextArea
                         error={props.addresserror}
                         label="Farm Address"
                         value={props.farmaddressvalue}
                         onChange={props.farmaddressonChange} />

                        <div className="SellMap-div" >
                            <div className="SellMap-div_nar" >
                                Please Select the location of your farm or a location close to your farm on the map 
                            </div>
                        </div>

                        <OrdinaryTextInput
                         error={props.maperror}
                         label="Map Location"
                         disable
                         value={props.mapareaValue}
                         onChange={props.mapareaonChange} />

                            <div className="SellMap-div_sbt" >
                                <button className="SellMap-div_sbt-btn" onClick={ props.Openmap } >
                                    Open Map
                                </button>
                            </div>

                    </div>

                    <Toggletitle
                        title="Account Information"
                        position={showAccountinfo}
                        toggleposition={ () => setshowAccountinfo(!showAccountinfo) } />

                        <div className="sell-template-div-middle-seller" style={{
                            display: showAccountinfo ? 'block' : 'none'
                        }} >

                            <OrdinaryTextInput
                            label="Account Name"
                            // disable
                            value={props.accountname}
                            onChange={props.accountnameonChange} />

                            <OrdinaryTextInput
                            label="Account Number"
                            value={props.accountnumber}
                            onChange={props.accountnumberonChange} />

                          <OrdinaryTextInput
                            label="Bank Name"
                            value={props.bankname}
                            onChange={props.banknameonChange} /> 

                        </div>

                </div>

                <div className="sell-template-div-bottom" >

                    <button className="sell-template-div-bottom-btn" disabled={props.disablebtn} onClick={props.sellproduct} >
                        { props.buttonoption }
                    </button>
                </div>

          </div>

      );

}

export default Selltemplate;