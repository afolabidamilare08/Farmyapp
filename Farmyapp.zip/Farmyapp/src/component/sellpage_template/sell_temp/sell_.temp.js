import React from 'react';


export const OrdinaryTextInput = (props) => {

    return (
        <div className="Sellproduct_bigform_firstForm_div" >
            <input type="text" value={props.value ? props.value : ''} disabled={props.disable} onChange={props.onChange} className="Sellproduct_bigform_firstForm_div_input" style={{ border: props.error ? '2px solid red ' : '' }} placeholder={props.label} />
            <label className="Sellproduct_bigform_firstForm_div_label" >
                {props.label}
            </label>
        </div>
    )

}

export const OrdinaryTextArea = (props) => {

    return (
        <div className="Sellproduct_bigform_firstForm_div" >
            <textarea className="Sellproduct_bigform_firstForm_div_textArea" style={{ border: props.error }} value={props.value} onChange={props.onChange} placeholder={props.label} >
            </textarea>    
            <label className="Sellproduct_bigform_firstForm_div_label" >
                {props.label}
            </label>
        </div>
    )

}

export const OrdinaryPriceandSale = (props) => {

    return (
        <div className="Sellproduct_bigform_firstForm_price_div" >

            <div className="Sellproduct_bigform_firstForm_price_div_sign" >₦</div>

            <div className="Sellproduct_bigform_firstForm_price_div_price" >
                    <input type="text" value={props.pricevalue} onChange={props.priceonChange} className="Sellproduct_bigform_firstForm_div_input" placeholder="Price" />
                    <label className="Sellproduct_bigform_firstForm_div_label" >
                        Price
                    </label>
            </div>

            <div className="Sellproduct_bigform_firstForm_price_div_sign" >
                Per
            </div>

            <div className="Sellproduct_bigform_firstForm_price_div_price" >
                <input type="text" value={props.scalevalue} disabled={props.disable} onChange={props.scaleonChange} className="Sellproduct_bigform_firstForm_div_input" placeholder="Scale e.g kg , basket e.t.c" />
                <label style={{ display: props.disable ? 'none' : 'block' }} className="Sellproduct_bigform_firstForm_div_label" >
                    Scale e.g kg , bag
                </label>
                <label style={{ display: props.disable ? 'block' : 'none' }} className="Sellproduct_bigform_firstForm_div_label" >
                   Hour
                </label>
            </div>

        </div>
    )

}

export const OrdinaryHarvestDate = (props) => {

    return (

        <div className="Sellproduct_bigform_firstForm_div" >
            <input style={{textTransform:'uppercase'}} type="date" value={props.harvestvalue} onChange={props.harvestonChange} className="Sellproduct_bigform_firstForm_div_input" placeholder="Harvest Date" />
            <label className="Sellproduct_bigform_firstForm_div_label" >
                Available On
            </label>
        </div>

    );

}

export const Toggletitle = (props) => {

    return(

        <div className="Sellproduct_bigform_product" style={props.style} >
            <div className="Sellproduct_bigform_product_rot" >
                <div className="Sellproduct_bigform_product_rot_div" 
                    onClick={props.toggleposition}
                 style={{
                    transform: props.position ? 'rotate(180deg)' : 'rotate(90deg)'
                }}  ></div>
            </div>
            <div className="Sellproduct_bigform_product_title" onClick={props.toggleposition}
                 >
                {props.title}
            </div>
        </div>

    );

}