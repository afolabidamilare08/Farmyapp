import React from 'react';

const Sellformtemp = (props) => {

    if( props.type === 'textarea' ){
        var input = <textarea className="sellform-form-input sellform-form-textarea" value={props.value} onChange={props.onChange} type="text" ></textarea>
    }else{
        if( props.type === 'date' ){
            input = <input  className="sellform-form-input sellform-form-date" value={props.value} onChange={props.onChange}  type="date" />
        }else{
            input = <input className="sellform-form-input" value={props.value} onChange={props.onChange}  type="text" />
        }
    }

    if(props.price){

        var display = (
            
                    <div className="sellform-form-price-div" >
                            <div className="sellform-form-price-div-currency" >
                                ₦
                            </div>
                            <div className="sellform-form-price-div-1div" >
                                <input type="text" className="sellform-form-price-div-1div-input" value={props.productpricevalue} onChange={props.productpriceonChange} />
                                <label className="sellform-form-price-div-1div-label" >Price<span className="mustbefilledas" >*</span></label>
                            </div>
                            <div className="sellform-form-price-div-per" >
                                per
                            </div>
                            <div className="sellform-form-price-div-2div" >
                                <input type="text" className="sellform-form-price-div-2div-input" value={props.productscalevalue} onChange={props.productscaleonChange} />
                                <label className="sellform-form-price-div-2div-label" > {props.label1} <span className="mustbefilledas" > {props.label2} </span></label>
                            </div>
                    </div>

                     );

    }else{

            if(props.available){
                display = (
                    <div className="sellform-form-available" >
                        <div className="sellform-form-available-form" >
                            <input className="sellform-form-available-form-input" value={props.value} onChange={props.onChange} />
                            <label className="sellform-form-available-form-label" >Quantity available for sale<span className="mustbefilledas" > e.g 45{props.measure}</span></label>
                            <div className="sellform-form-available-measure" >
                                Pls note that the Quantity available 
                                for sale should just be digit e.g(94) and
                                measurement scale should not be added
                                to it the measurement scale you used
                                in the price will automatically be added to the number  
                            </div>
                        </div>

                    </div>
                );
        }
            else{
                display = ( 

                            <div>  
                                {input}
                                <label className="sellform-form-label" >{props.label1}<span className="mustbefilledas" >{props.label2}</span></label>
                            </div>  

                    );
                }
        }

      return ( 

        <div className="sellform-form" >
            {display}
        </div>

      );

}

export default Sellformtemp;