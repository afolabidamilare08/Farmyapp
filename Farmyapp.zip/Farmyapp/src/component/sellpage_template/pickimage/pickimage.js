import React,{Component} from 'react';
import Svg from '../../utilities/Svg';

class Pickimage extends Component {

    render (){

        if(this.props.preview){
            var preview = <img className="sell-imagepick-list-1-img" alt="" onClick={ ()=>this.fileInput.click() } src={this.props.preview} />
        }else{
            preview = 
                 <Svg
                 onClick={ ()=>this.fileInput.click() }
                className="sell-imagepick-list-1-ic"
                href="sprite2.svg#icon-add" /> 
        }



      return ( 

        <div className="sell-imagepick-list" >
                <div className="sell-imagepick-list-1" >
                    {preview}
                </div>
                <div className="sell-imagepick-list-3" >
                    <button className="sell-imagepick-list-3-btn" onClick={()=>this.fileInput.click()} >Pick Image</button>
                    <input type="file" id="input" onChange={this.props.choseimage} style={{display:'none'}} ref={fileInput => this.fileInput = fileInput} />
                </div>
        </div>

      );
    }

}

export default Pickimage;