import React from 'react';

const Chkuserdiv = (props) => {

      return ( 

        <div className="chkuserdiv-div" >

            <div className="chkuserdiv-div-top" >
                <div className="chkuserdiv-div-top_title" > Checking Out Order </div>
                <div className="chkuserdiv-div-top-second" >
                    <div className="chkuserdiv-div-top-second-top" onClick={props.go_to_step_one} style={props.first_color} > Profile Confirmation </div>
                    <div className="chkuserdiv-div-top-second-top" onClick={props.go_to_step_two} style={props.second_color} > Delivery Method </div>
                    {/* <div className="chkuserdiv-div-top-second-top" style={props.third_color} onClick={props.go_to_step_three} > Make Payment </div> */}
                </div>
                </div> 

            {props.children}

        </div>

      );

}

export default Chkuserdiv;