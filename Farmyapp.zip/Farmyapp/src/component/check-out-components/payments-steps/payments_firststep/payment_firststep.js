import React from 'react';
import {Link} from 'react-router-dom'; 
import AdInput from '../../../../services/components/booking_service_component/ad_input/ad_input';

const Paymentfirststep = (props) => {

      return ( 

        <div className="paymentfirststep-div" >

            <div className="paymentfirststep-div-form" >

                <AdInput
                 value={props.first_name}
                 text={true}
                 disabled={true}
                labelName="First Name" />

                <AdInput
                 value={props.last_name}
                 text={true}
                 disabled={true}
                 labelName="Last Name" />

                <AdInput
                 value={props.email}
                 text={true}
                 disabled={true}
                 labelName="Email Address" />

                <AdInput
                 value={props.phone_number}
                 text={true}
                 disabled={true}
                 labelName="Phone Number" />

            </div>
            <div className="paymentfirststep-div-bottom" >
                  <div className="paymentfirststep-div-bottom-left" >
                    Note : if your details are not correct <Link className="paymentfirststep-div-bottom-left-click" to="#" onClick={ props.openeditprofile } >click here</Link> to change it in your profile
                  </div>
            </div> 
        </div>

      );

}

export default Paymentfirststep;