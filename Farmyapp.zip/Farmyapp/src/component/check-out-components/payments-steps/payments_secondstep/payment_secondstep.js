import React from 'react';

const Paymentssecondstep = (props) => {

      return ( 
          <div className="paymentssecondstep-div" >  

                <div className="chkuserdiv-div-top_step" >
                     {props.step_det} 
                </div>      

                <div className="paymentssecondstep-div-first-form" >
                    <div className="paymentssecondstep-div-first-form_group" >
                        <input type="radio" className="paymentssecondstep-div-first-form_group-input" name="deliveryoption" id="small" />
                        <label onClick={props.pick_it_yourself} for="small" className="paymentssecondstep-div-first-form_group-label"  >
                          <span className="paymentssecondstep-div-first-form_group-label-btn"  > </span>
                          <span className="paymentssecondstep-div-first-form_group-label-top" >Pick it Myself</span>
                          <span className="paymentssecondstep-div-first-form_group-label-str" >
                              By selecting this option , it means that you will pick the products you have 
                              purchased from their respective locations and no transport fee would be added to your invoice
                          </span>
                        </label>
                    </div>
                    <div className="paymentssecondstep-div-first-form_group" >
                        <input type="radio" className="paymentssecondstep-div-first-form_group-input" name="deliveryoption" id="large" />
                        <label onClick={props.farmy_express_delivery} for="large" className="paymentssecondstep-div-first-form_group-label"  >
                          <span className="paymentssecondstep-div-first-form_group-label-btn"  > </span>
                          <span className="paymentssecondstep-div-first-form_group-label-top" >Farmyapp Express Delivery</span>
                          <span className="paymentssecondstep-div-first-form_group-label-str" >
                              By chosing "Farmyapp express delivery" you will be prompted to select where you
                              want your ordered product to be delivered to on the Map . Transport fee would be added to your 
                              invoice   
                          </span>
                        </label>
                    </div>
                </div>

                <div className="paymentssecondstep-div-2nd-form" >
                    {props.mapinfo}
                </div>

            <div className="paymentfirststep-div-bottom" >
                  <div className="paymentfirststep-div-bottom-left" >
                    Note : Make sure that the location you selected would be convinient for you to recieve your order
                  </div>
            </div>                  
          </div>
      );

}

export default Paymentssecondstep;