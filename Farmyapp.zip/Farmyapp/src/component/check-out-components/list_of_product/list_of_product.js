import React from 'react';

const ListOfproduct = (props) => {

      return ( 

        <div className="listOfproduct-div" >
            <div className="listOfproduct-div-top" >
                <div className="listOfproduct-div-top-name" > {props.product_name} </div>
                <div className="listOfproduct-div-top-qty" > ({props.product_qty + ' ' + props.product_measurement + 's ' }) </div>
            </div>
                <div className="listOfproduct-div-amount" > ₦ {props.product_price} </div>
        </div>

      );

}

export default ListOfproduct;