import React from 'react';
import { OrdinaryTextInput, OrdinaryTextArea } from '../../sellpage_template/sell_temp/sell_.temp';

const Mapform = (props) => {

      return (
        
        <div className="mapform-div" >
            
            <div className="mapform-div-top" >
                <div className="mapform-div-top-1" >
                    delivery address information
                </div>
            </div>

            {/* <div className="mapform-div-form" >
                <label htmlFor="country" className="mapform-div-form-label" >
                    Country
                </label>
                <input type='text' className="mapform-div-form-input" id="country" value={props.country} />
            </div> */}

            <OrdinaryTextInput
             label='Country'
             value={props.countryvalue}
             onChange={ props.countryonChange }
             disable
             />

            {/* <div className="mapform-div-form" >
                <label htmlFor="state" className="mapform-div-form-label" >
                    state
                </label>
                <input type='text' className="mapform-div-form-input" id="state" value={props.state} />
            </div> */}

            <OrdinaryTextInput 
             label="State"
             value={props.statevalue}
             onChange={ props.stateonChange }
              />

            {/* <div className="mapform-div-form" >
                <label htmlFor="address" className="mapform-div-form-label" >
                    address
                </label>
                <textarea type='text' className="mapform-div-form-input" id="address" value={props.address} >
                </textarea>    
            </div> */}

            <OrdinaryTextInput 
              label="Local Government Area" 
             value={props.lgavalue}
             onChange={ props.lgaonChange }
              />

            <OrdinaryTextArea 
              label="Address" 
              value={props.addressvalue}
              onChange={ props.addressonChange }
              />

                <div className="mapform-div-top-2" >
                    Please Select the location of the Work Destination
                    Location or a location close to the Work Destination Location on the map
                </div>

            <OrdinaryTextInput 
              label="Map Address" 
              disable
              value={props.mapAddress}
            //   onChange={ props.longitudeonChange }
              />
{/* 
            <OrdinaryTextInput 
              label="Latitude" 
              disable
              value={props.latitudevalue}
              onChange={ props.latitudeonChange }
              /> */}

            <div className="mapform-div-sbt" >
                <button className="mapform-div-sbt-btn" onClick={props.Openmap} >
                    Open Map
                </button>
            </div>

        </div>
        
      );

}

export default Mapform;