import React from 'react';

const Orderdetails = (props) => {

      return ( 
          <div className="orderdetails-div" >

              <div className="orderdetails-div-top" >
                My Order Summary
              </div>

              <div className="orderdetails-div-middle" >
                {props.children}
              </div>

              <div className="orderdetails-div-bottom" >
                    <div className="orderdetails-div-bottom-first" >
                        <span className="orderdetails-div-bottom-first-total" > 
                          Cost of all product </span> 
                        <span className="orderdetails-div-bottom-first-number" > ₦ {props.totalcost} </span>
                    </div>
                    <div className="orderdetails-div-bottom-second" >
                        Cost for delivery each product has been added  
                    </div>
              </div>
               
          </div>
      );

}

export default Orderdetails;