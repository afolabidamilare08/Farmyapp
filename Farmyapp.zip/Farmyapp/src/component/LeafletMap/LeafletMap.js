import React from 'react';
import { Map, TileLayer } from 'react-leaflet'
import ReactLeafletSearch from "react-leaflet-search";


const LeafletMapDiv = (props) => {


    const  state = {
        lat:'6.524379' ,
        long:'3.379206' ,
        zoom:'15' ,
    }


      var position = [ state.lat , state.long ]

      return ( 


         <div className="LeafletMapDiv" >
            <div className="LeafletMapDiv_top" >
              <div className="LeafletMapDiv_top_story" >
                  <div className="LeafletMapDiv_top_story_story" > {props.story} </div>
              </div>
            <button className="LeafletMapDiv_top_close" onClick={ props.closeMap } >
                Close Map
            </button>
            </div>
        <div className="LeafletMapDiv_body"  >
               
                             <Map center={position} zoom={12}
                             viewport={ null } >
       
                               <TileLayer
                                 attribution='&amp;copy <a href="http://osm.org/copyright">OpenStreetMap</a> contributors'
                                 url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                               />
       
       
                                 <ReactLeafletSearch 
                                     position='topright'
                                     openSearchOnLoad={true}
                                     closeResultsOnClick={true}
                                     showMarker={true} 
                                     showPopup={true}
                                     inputPlaceholder="Search for a place close to your location "
                                     popUp={props.myPopup}
                                       />
               
                       </Map>
      

         </div>
    </div>


       
      );

}

export default LeafletMapDiv;








