import React from 'react';
import Svg from '../utilities/Svg';

const OtheruserProfile = (props) => {


      return (
        <> 
          {/* <div className="OtheruserProfile-div" > */}
              {/* <div className="OtheruserProfile-div-back" >
                <button className="OtheruserProfile-div-back-btn" onClick={props.goBack} >
                    <Svg
                        href="sprite2.svg#icon-arrow_back"
                        className="OtheruserProfile-div-back-btn-ic"
                    />
                </button>  
                <div className="OtheruserProfile-div-back-txt" ></div>
              </div> */}
              {/* <div className="OtheruserProfile-div-img" > 

                 {  props.img && props.img !== '' ? 

                    <img alt="" src={props.img} className="OtheruserProfile-div-img-img" />
                    :
                    <Svg 
                    href="contact.svg#icon-person"
                    className="OtheruserProfile-div-img-ic"
                  />
                 }

              </div>
              <div className="OtheruserProfile-div-name" >
                  {props.first_name} {props.last_name}
              </div> */}
              {/* <div className="OtheruserProfile-div-abtme" >
                About Me
              </div> */}
              {/* <div className="OtheruserProfile-div-bio" >
                {props.bio}
              </div>
              <div className="OtheruserProfile-div-condet" >
                  Contact Details
              </div>
              <div className="OtheruserProfile-div-Allcontact" >
                <div className="OtheruserProfile-div-Allcontact-div" >
                    <Svg
                        className="OtheruserProfile-div-Allcontact-div-ic"
                        href="sprite4.svg#icon-mail"
                    />
                    <div className="OtheruserProfile-div-Allcontact-div-txt" > {props.email} </div>
                </div>
                <div className="OtheruserProfile-div-Allcontact-div" >
                    <Svg
                        className="OtheruserProfile-div-Allcontact-div-ic"
                        href="contact.svg#icon-phone"
                    />
                    <div className="OtheruserProfile-div-Allcontact-div-txt" > {props.phone_number} </div>
                </div>
              </div>
              <div className="OtheruserProfile-div-more" >
                More About Me
              </div>
              <div className="OtheruserProfile-div-Allmore" >
                 <div className="OtheruserProfile-div-Allmore-div" >
                    <span className="OtheruserProfile-div-Allmore-div-1" > Interests : </span>
                    <span className="OtheruserProfile-div-Allmore-div-2" > {props.interests} </span>
                 </div>
                 <div className="OtheruserProfile-div-Allmore-div" >
                    <span className="OtheruserProfile-div-Allmore-div-1" > Languages Known : </span>
                    <span className="OtheruserProfile-div-Allmore-div-2" > {props.languages_known} </span>
                 </div>
                 <div className="OtheruserProfile-div-Allmore-div" >
                    <span className="OtheruserProfile-div-Allmore-div-1" > Gender : </span>
                    <span className="OtheruserProfile-div-Allmore-div-2" style={{
                      textTransform:'uppercase',
                      fontSize:'1.1rem'
                    }} > {props.gender} </span>
                 </div>
              </div>
          </div> */}


          <div className="otheruser-first" >
            <div className="otheruser-first-cover-img-box" >
                <div className="otheruser-first-cover-img-box-picture" >
                    <div className="otheruser-first-cover-img-box-picture-no" >
                    {  props.img && props.img !== '' ? 

                        <img src={props.img} alt="" className="otheruser-first-cover-img-box-picture-img" />
                        :
                        <Svg className="otheruser-first-cover-img-box-picture-no-ic" href="contact.svg#icon-person" />
                    }
                       
                    </div>
                </div>
                <div className="otheruser-first-cover-img-box-name" >
                    <div className="otheruser-first-cover-img-box-name-first" >
                        <div className="otheruser-first-cover-img-box-name-first-name" >
                            {props.first_name} {props.last_name}
                        </div>
                        <div className="otheruser-first-cover-img-box-name-first-tag" >
                            @{props.user_name}
                        </div>
                    </div>
                </div>
            </div>
            <div className="otheruser-first-adverts" >
                <div className="otheruser-first-adverts-left" >
                  <div className="otheruser-first-adverts-left-top" > {props.productlength} </div>
                  <div className="otheruser-first-adverts-left-btm" > 
                   <Svg className="otheruser-first-adverts-left-btm-ic" href="sprite4.svg#icon-store_mall_directorystore" />
                   Products </div>
                </div>
                <div className="otheruser-first-adverts-left" >
                  <div className="otheruser-first-adverts-left-top" > {props.servicelength} </div>
                  <div className="otheruser-first-adverts-left-btm" > 
                   <Svg className="otheruser-first-adverts-left-btm-ic" href="sprite4.svg#icon-suitcase1" />
                   Services </div>
                </div>
            </div>
            <div className="otheruser-first-about" >
                <div className="otheruser-first-about-tag" >
                    About Me
                </div>
                <div className="otheruser-first-about-narate" >
                {props.bio}
                </div>
            </div>

            <div className="otheruser-first-about" >
                <div className="otheruser-first-about-tag" >
                    Gender
                </div>
                <div className="otheruser-first-about-narate" >
                    {props.gender}
                </div>
            </div>

            <div className="otheruser-first-split" >  
                <div className="otheruser-first-split-1" >
                    <div className="otheruser-first-about-tag" >
                        Email
                    </div>
                    <div className="otheruser-first-about-narate" >
                        {props.email}
                    </div>
                </div>
                <div className="otheruser-first-split-1" >
                      <div className="otheruser-first-about-tag" >
                          Phone Number
                      </div>
                      <div className="otheruser-first-about-narate" >
                          {props.phone_number}
                      </div>
                </div>
            </div>

            <div className="otheruser-first-about" >
                <div className="otheruser-first-about-tag" >
                    Interests
                </div>
                <div className="otheruser-first-about-narate" >
                {props.interests}
                </div>
            </div>

            <div className="otheruser-first-about" >
                <div className="otheruser-first-about-tag" >
                    languages known
                </div>
                <div className="otheruser-first-about-narate" >
                    {props.languages_known}
                </div>
            </div>

          </div>
       
          <div className="OtheruserProfile-bottom" >
              <div className="OtheruserProfile-bottom-top" >
                  <button className="OtheruserProfile-bottom-top-btn" style={{color:props.pcolor}} onClick={ props.showproducts } > products 
                      <Svg className="OtheruserProfile-bottom-top-btn-ic" href="sprite4.svg#icon-store_mall_directorystore" />
                  </button>
                  <button className="OtheruserProfile-bottom-top-btn" onClick={ props.showservices } > Services 
                      <Svg className="OtheruserProfile-bottom-top-btn-ic" href="sprite4.svg#icon-suitcase1" />
                  </button>
              </div>
              <div className="OtheruserProfile-bottom-main" >
                 { props.allshow }
              </div>
          </div>

        </>
      );

}

export default OtheruserProfile;