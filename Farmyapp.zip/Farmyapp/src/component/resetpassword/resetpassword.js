import React from 'react';
import {Link} from 'react-router-dom';
import Leftlogoslide from '../../layout/header/logo/headerleftslide/leftlogoslide';

const ResetPasswordDiv = (props) => {

    if(props.message){
        var show =  <div className="loginerror" > {props.message} </div>
    }

      return ( 

        <form className="login-box" onSubmit={props.login} >

            <Leftlogoslide/>

            <div className="login-box-sign-in" >
                Reset Password!
            </div>

            {show}

            <div className="login-box-form-div" >

                <div className="login-box-form-div-form" >
                    <input type="email" placeholder="Email" className="login-box-form-div-form-input" value={props.emailvalue} onChange={props.emailonchange} />
                    <label className="login-box-form-div-form-label" >Email</label> 
                </div>

                <div className="login-btn-div" >
                    <button className="login-btn-div-btn" onClick={props.login} >
                            <span> Send password reset link to email </span>
                            {props.btnIcn}
                    </button>
                </div>

                <div className="dont-have-account" >
                    <Link to="/signin" className="dont-have-account-lin" >I already have an account </Link>
                </div>

            </div>
        </form>

      );

}

export default ResetPasswordDiv;