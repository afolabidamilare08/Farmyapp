import React from 'react';
import { Link } from 'react-router-dom';


export const ServicesMiniTemp = (props) => {

    if(props.description){

        if(props.description.length > 300  ){

            var serv_des = []

            for (let j = 0; j < 300; j++) {
                serv_des.push(props.description[j])
            }

        }
        else{
            serv_des = props.description
        }

    }

    // 
      return ( 
          <div className="Userproduct-div" >
              <div className="Userproduct-div_first" >
                  <div className="Userproduct-div_first_left" >
                        <div className="Userproduct-div_first_left_img" >
                            <img alt="" src={props.service_img} className="Userproduct-div_first_left_img_img" />
                        </div>
                  </div>
                  <div className="Userproduct-div_first_right" >    
                        <div className="Userproduct-div_first_right_name" >
                            {props.serviceName}
                        </div>
                        <div className="Userproduct-div_first_right_desc" >
                            {serv_des}
                        </div>
                  </div>
              </div>
              <div className="Userproduct-div_mid" >
                        {/* <div className="Userproduct-div_first_right_nar" >
                            <span className="Userproduct-div_first_right_nar_1" >
                                Quantity Available :
                            </span>
                            <span className="Userproduct-div_first_right_nar_2" >
                                { props.quantityavailable + ' ' + props.mesurementscale }
                            </span>
                        </div> */}
                        
                         <div className="Userproduct-div_first_right_nar" >
                            <span className="Userproduct-div_first_right_nar_1" >
                                Date posted :
                            </span>
                            <span className="Userproduct-div_first_right_nar_2" >
                                {props.date_created}
                            </span>
                        </div>

                        <div className="Userproduct-div_first_right_nar" >
                            <span className="Userproduct-div_first_right_nar_1" >
                                Total Hires :
                            </span>
                            <span className="Userproduct-div_first_right_nar_2" >
                                {props.Thires}
                            </span>
                        </div>
                        <div className="Userproduct-div_first_right_nar" >
                            <span className="Userproduct-div_first_right_nar_1" >
                                Hire Price
                            </span>
                            <span className="Userproduct-div_first_right_nar_2" >
                            ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.service_price)}
                            </span>
                        </div>
              </div>

              
              <div className="Userproduct-div_second" >  
                    <Link disabled="true" to={props.edit} className="Userproduct-div_second_btn1" onClick={ props.OpenDetails } >
                        Edit
                    </Link>
                    <button className="Userproduct-div_second_btn2" onClick={props.delete} >
                        Delete
                    </button>
              </div>
              

          </div>
      );

}




















export const ProductMiniTemp = (props) => {

    if( props.product_description ){
        
        var desc = props.product_description

        if( desc.length < 300 ){
            var applydesc = desc
        }
        
        if( desc.length > 300 ){
            var Alright = []

            for (let h = 0; h < 300; h++) {
                Alright.push(desc[h])
            }

            applydesc = Alright

        }

    }

    // 
      return ( 
          <div className="Userproduct-div" >
              <div className="Userproduct-div_first" >
                  <div className="Userproduct-div_first_left" >
                        <div className="Userproduct-div_first_left_img" >
                            <img alt="" src={props.firstimage} className="Userproduct-div_first_left_img_img" />
                        </div>
                  </div>
                  <div className="Userproduct-div_first_right" >    
                        <div className="Userproduct-div_first_right_name" >
                            {props.productname}
                        </div>
                        <div className="Userproduct-div_first_right_desc" >
                            {applydesc}
                        </div>
                  </div>
              </div>
              <div className="Userproduct-div_mid" >
                        {/* <div className="Userproduct-div_first_right_nar" >
                            <span className="Userproduct-div_first_right_nar_1" >
                                Quantity Available :
                            </span>
                            <span className="Userproduct-div_first_right_nar_2" >
                                { props.quantityavailable + ' ' + props.mesurementscale }
                            </span>
                        </div> */}
                        
                         <div className="Userproduct-div_first_right_nar" >
                            <span className="Userproduct-div_first_right_nar_1" >
                                Total Quantity of product :
                            </span>
                            <span className="Userproduct-div_first_right_nar_2" >
                               { props.totalquantityofproducts }
                            </span>
                        </div>

                        <div className="Userproduct-div_first_right_nar" >
                            <span className="Userproduct-div_first_right_nar_1" >
                                Measurement Scale :
                            </span>
                            <span className="Userproduct-div_first_right_nar_2" >
                               { props.mesurementscale }
                            </span>
                        </div>
                        <div className="Userproduct-div_first_right_nar" >
                            <span className="Userproduct-div_first_right_nar_1" >
                                Unit Price :
                            </span>
                            <span className="Userproduct-div_first_right_nar_2" >
                            ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.price)}
                            </span>
                        </div>
                        <div className="Userproduct-div_first_right_nar" >
                            <span className="Userproduct-div_first_right_nar_1" >
                                Total Number Of Orders :
                            </span>
                            <span className="Userproduct-div_first_right_nar_2" >
                                { props.quantityordered + ' ' + props.mesurementscale }
                            </span>
                        </div>
              </div>

              { props.ShouldDisplay ? 
              
              <div className="Userproduct-div_second" >  
                    <Link to={props.edit} className="Userproduct-div_second_btn1" onClick={ props.OpenDetails } >
                        Edit
                    </Link>
                    { props.showDelete ? 
                        null :
                        <button className="Userproduct-div_second_btn2" onClick={props.delete} >
                        Delete
                    </button>
                    }
              </div>
              
              : null }

          </div>
      );

}


