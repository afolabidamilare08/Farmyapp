import React from 'react';

const GoBackDiv = (props) => {

      return (
          <div className="goback-div" >
              <button onClick={ props.to } className="goback-div_link" >
                  Go Back
              </button>
          </div> 
      );

}

export default GoBackDiv;