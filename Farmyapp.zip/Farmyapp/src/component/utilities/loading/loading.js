import React from 'react';
import './loading.css';

const Loading = (props) => {

      return ( 

        <div className="spinner" style={{
          backgroundColor:props.color
        }} ></div>

      );

}

export default Loading;