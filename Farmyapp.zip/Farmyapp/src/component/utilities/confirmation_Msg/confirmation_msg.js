import React from 'react';
import Backdrop from '../Backdrop/backdrop';
import Loading from '../loading/loading';

const ConfirmationMsg = (props) => {

      return (
        
        <Backdrop show={props.show} >
            <div className="confirmation_msg_div" >
                <div className="confirmation_msg_div_msg" >
                    {/* <Loading/> */}
                    { props.isloading ? <Loading/> :
                    <div className="confirmation_msg_div_msg_txt" >
                    {props.msg}
                    </div> 
                }
                </div>
                <div className="confirmation_msg_div_opt" >
                    <button className="confirmation_msg_div_opt-yes" onClick={props.confirm} >
                        Yes
                    </button>
                    <button className="confirmation_msg_div_opt-no" onClick={props.decline} >
                        No
                    </button>
                </div>
            </div>
        </Backdrop>
        
      );

}

export default ConfirmationMsg;