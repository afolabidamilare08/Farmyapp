import React from 'react';
import './loading2.css';

const Loading = (props) => {

      return ( 

        <div className="spinner2"></div>

      );

}

export default Loading;