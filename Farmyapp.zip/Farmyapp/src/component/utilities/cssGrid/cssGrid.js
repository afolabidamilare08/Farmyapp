import React from 'react';

const CssGrid = (props) => {

      return ( 
          <div className="cssGrid" >
              <div className="item item--1" > 1: Header </div>
              <div className="item item--2" > 2: small box 1 </div>
              <div className="item item--3" > 3: small box 2 </div>
              <div className="item item--4" > 4: small box 3 </div>
              <div className="item item--5" > 5: main content </div>
              <div className="item item--6" > 6: side bar </div>
              <div className="item item--7" > 7: footer </div>
          </div>
      );

}

export default CssGrid;