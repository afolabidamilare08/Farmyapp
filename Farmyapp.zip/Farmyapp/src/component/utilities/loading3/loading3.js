import React from 'react';
import './loading3.css';

const Loading3 = (props) => {

      return (
        
             <div className="loading3"></div>
        
      );

}

export default Loading3;