import React from 'react';

const BtnSpin = (props) => {

      return ( 
            <div className="Btnspinner">
                <div className="bounceit1" style={{backgroundColor:props.bgColor}} ></div>
                <div className="bounceit2" style={{backgroundColor:props.bgColor}} ></div>
                <div className="bounceit3" style={{backgroundColor:props.bgColor}} ></div>
            </div> 
      );

}

export default BtnSpin;  