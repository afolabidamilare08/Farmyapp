import React from 'react';

const Backdrop = (props) => {

      return (
          props.show ? <div className="mainbackdrop" style={{backgroundColor:props.backgroundColor}} onClick={props.closebackdrop} >
              {props.children}
          </div> : null
      );

}

export default Backdrop;