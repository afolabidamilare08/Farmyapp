import React from 'react';
import Svg from '../../utilities/Svg';

const AddcreditCard = (props) => {

      return ( 
          <div className="addcreditcard-div" >
              
             <div className="addcreditcard-div_carnum" >
                <div className="addcreditcard-div_carnum_label" >
                    Card Number
                </div>
                <div className="addcreditcard-div_carnum_int" >
                    <Svg
                     className="addcreditcard-div_carnum_int_ic"
                     href="opps.svg#icon-credit-card-alt" />
                    <input
                     className="addcreditcard-div_carnum_int_input"  />
                </div>
             </div>

             <div className="addcreditcard-div_cardoth" >

                <div className="addcreditcard-div_cardoth_1" >
                    <div className="addcreditcard-div_carnum_label" >
                        Expiry Date
                    </div>
                    <div className="addcreditcard-div_carnum_int" >
                        <input
                        className="addcreditcard-div_carnum_int_input_oth" placeholder="MM / YY" />
                    </div>
                </div>

                <div className="addcreditcard-div_cardoth_1" >
                    <div className="addcreditcard-div_carnum_label" >
                        CVC
                    </div>
                    <div className="addcreditcard-div_carnum_int" >
                        <input
                        className="addcreditcard-div_carnum_int_input_oth"  />
                    </div>
                </div>

             </div>

              <div className="addcreditcard-div-sbt" >
                  <button className="addcreditcard-div-sbt-btn" >
                      Pay
                  </button>
              </div> 

          </div>
      );

}

export default AddcreditCard 