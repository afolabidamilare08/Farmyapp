import React from 'react';
import {Link} from 'react-router-dom';
import Svg from '../../utilities/Svg';

const Inditemp = (props) => {

   var product_name = []

   for (let p = 0; p < 30; p++) {
      product_name.push(props.product_name[p])      
   }

   var product_des = []

   for (let d = 0; d < 80; d++) {
      product_des.push(props.product_des[d]) 
      if( d === 79 ){
         product_des.push('...')
      }
   }

      return (

              <div className="cartitem-ind-div-details" >
                 
                 <div className="cartitem-ind-div-details-first" >

                     <div className="cartitem-ind-div-details-first-picture" >
                        <img src={props.product_img} alt="" className="cartitem-ind-div-details-first-picture-img" />
                     </div>

                     <div className="cartitem-ind-div-details-first-info" >
                        <div className="cartitem-ind-div-details-first-info-prodname" > 
                           
                           <Link to={props.to} className="cartitem-ind-div-details-first-info-prodname-1" > {product_name} </Link>
                           <div className="cartitem-ind-div-details-first-info-prodname-qty" >
                              <span className="cartitem-ind-div-details-first-info-prodname-qty-1" > Quantity Available : </span> 
                              <span className="cartitem-ind-div-details-first-info-prodname-qty-2" > {props.qutyavil} </span>
                           </div>
                           {/* <Link to={props.to} className="cartitem-ind-div-details-first-info-prodname-2" > {product_des  } </Link> */}
                        

                        </div>
                        <div className="cartitem-ind-div-details-first-info-remove" > 
                           <button className="cartitem-ind-div-details-first-info-remove-btn" onClick={props.removeItem} >
                              <Svg
                               className="cartitem-ind-div-details-first-info-remove-btn-ic"
                               href="sprite3.svg#icon-delete" />
                              remove
                           </button>
                        </div>
                     </div>

                 </div>

                  <div className="cartitem-ind-div-details-second" >
                     
                     <div className="cartitem-ind-div-details-second-qty" >

                        <div className="cartitem-ind-div-details-second-qty-1" >
                           Quantity
                        </div>

                        <div className="cartitem-ind-div-details-second-qty-2" >
                           <input className="cartitem-ind-div-details-second-qty-2-input" value={props.product_quantity} onChange={props.changequantity}  />
                        </div>

                        <button onClick={ props.updateItemquty } className="cartitem-ind-div-details_update_button" >
                           Update
                        </button>

                     </div>
                     
                     <div className="cartitem-ind-div-details-second-price" >
                           <div className="cartitem-ind-div-details-second-price-1" > price </div>
                           <div className="cartitem-ind-div-details-second-price-2" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.product_price)} </div>
                     </div>

                     <div className="cartitem-ind-div-details-second-subtotal" >
                           <div className="cartitem-ind-div-details-second-subtotal-1" > subtotal </div>
                           <div className="cartitem-ind-div-details-second-subtotal-2" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.product_subtotal)} </div>
                     </div>

                  </div>

              </div>

      );

}

export default Inditemp;