import React , { useContext , useEffect , useState } from 'react';
import Store from '../../store/managementstore/managementstore';
import Axios from 'axios';
import { TermsandCondition , TermsandConditionListOrder } from '../utilities/TermsAndCondition/termsandcondition';
import Backdrop from '../utilities/Backdrop/backdrop';
import { Link } from 'react-router-dom';
import {store} from 'react-notifications-component';
import { FoodCartItem,FoodCartHeader,FoodCartTotal } from '../../foods/components/cartpagecomponents';
import { EmptyCartDiv } from '../../foods/components/empty/no_product';


const WholeSaleCart = (props) => {

    const [total,settotal] = useState(null)

    const [ cartList , setcartList ] = useState([ ])

    const [ Opentc , setOpentc ] = useState(false)


    const context = useContext(Store)

    const User_cart_id = context.User_cart_id

    useEffect( () => {
      settotal(null)
      Axios({ method: 'GET',url:'carts/cart/' + User_cart_id + '/' })
      .then( response => {
          settotal(response.data.get_total_cost)
          setcartList(response.data.items)
          } )
    } , [User_cart_id] )


   const change_item_quantity = ( event , id ) => {

      const itemIndex = cartList.findIndex( i => {
        return i.product.id === id
      } )
  
        const item = {...cartList[itemIndex]}
  
        item.quantity = event.target.value
  
        const newlist = [...cartList]
  
        newlist[itemIndex] = item
  
        setcartList(newlist)    

    }

    const UpdateCartdetails = (id) => {

      store.addNotification({
        title: "Updating Cart",
        message: " Updating Item Quantity " ,
        type: "warning",
        insert: "top",
        container: "top-left",
        animationIn: ["animate__animated", "animate__fadeIn"],
        animationOut: ["animate__animated", "animate__fadeOut"],
        dismiss: {
          duration: 2000,
          onScreen: true
        }
      });

        const itemIndex = cartList.findIndex( i => {
          return i.product.id === id
        } )
  
        const item = {...cartList[itemIndex]}

        if( item.product.quantity_remaining ){
          var numberTochk = item.product.quantity_remaining
        }else{
          numberTochk = item.product.quantity_available
        }

        if( item.quantity > numberTochk ){

          store.addNotification({
            title: "Updating Cart",
            message: 'only ' + numberTochk + ' ' + item.product.measurement_scale + ' are remaining' ,
            type: "danger",
            insert: "top",
            container: "top-left",
            animationIn: ["animate__animated", "animate__fadeIn"],
            animationOut: ["animate__animated", "animate__fadeOut"],
            dismiss: {
              duration: 5000,
              onScreen: true
            }
          });
        }else{

          const quantityChange = { quantity:item.quantity , product_id: id }

  
        Axios.put( '/carts/cart/ ' + User_cart_id + ' /add_to_cart/' , quantityChange ).then(
          response => {
                var user_id = context.User_cart_id
                Axios({ method: 'GET',url:'carts/cart/' + user_id + '/' })
                .then( response => {
                    settotal(response.data.get_total_cost)
                    store.addNotification({
                      title: "Updating Cart",
                      message:" Quantity Was Successfully Updated" ,
                      type: "success",
                      insert: "top",
                      container: "top-left",
                      animationIn: ["animate__animated", "animate__fadeIn"],
                      animationOut: ["animate__animated", "animate__fadeOut"],
                      dismiss: {
                        duration: 5000,
                        onScreen: true
                      }
                    });
                    } ).catch( e => {
                      store.addNotification({
                        title: "Updating Cart",
                        message: "Something Went Wrong When Updating  Quantity" ,
                        type: "danger",
                        insert: "top",
                        container: "top-left",
                        animationIn: ["animate__animated", "animate__fadeIn"],
                        animationOut: ["animate__animated", "animate__fadeOut"],
                        dismiss: {
                          duration: 5000,
                          onScreen: true
                        }
                      });
                    } )
          }
        ).catch( e => {
          store.addNotification({
            title: "Updating Cart",
            message: "Something Went Wrong When Updating  Quantity" ,
            type: "danger",
            insert: "top",
            container: "top-left",
            animationIn: ["animate__animated", "animate__fadeIn"],
            animationOut: ["animate__animated", "animate__fadeOut"],
            dismiss: {
              duration: 5000,
              onScreen: true
            }
          });
        } )

        }

    }
  
  
    // add_to_userdetailsHandler = ( detail,detail2 ) => {
    //   this.setState({User_details:{detail,detail2}})
    // }
  
  
  
    const  remove_from_cart = ( productIndex , itemid ) => {
  
      store.addNotification({
        title: " Deleting... ",
        message:"Deleting An Item From Your Cart" ,
        type: "warning",
        insert: "top",
        container: "top-left",
        animationIn: ["animate__animated", "animate__fadeIn"],
        animationOut: ["animate__animated", "animate__fadeOut"],
        dismiss: {
          duration: 3000,
          onScreen: true
        }
      });

        // const item = [ ...cartList ]
  
        // item.splice(productIndex,1);
        // this.setState({cart:{...this.state.cart,items:item}})
  
        const prodId = { product_id: itemid }  
        Axios.post( 'carts/cart/' + User_cart_id + '/remove_from_cart/' , prodId ).then(
          response => {
            setcartList(response.data.items)
            settotal(response.data.get_total_cost)
            store.addNotification({
              title: "Updating Cart",
              message:" One Item In Your Cart Was removed " ,
              type: "success",
              insert: "top",
              container: "top-left",
              animationIn: ["animate__animated", "animate__fadeIn"],
              animationOut: ["animate__animated", "animate__fadeOut"],
              dismiss: {
                duration: 5000,
                onScreen: true
              }
            })
            context.updatecartHandler() 
          }
         ).catch(
           e => {
            store.addNotification({
              title: "Updating Cart",
              message: "Something Went Wrong When Deleting An Item " ,
              type: "danger",
              insert: "top",
              container: "top-left",
              animationIn: ["animate__animated", "animate__fadeIn"],
              animationOut: ["animate__animated", "animate__fadeOut"],
              dismiss: {
                duration: 5000,
                onScreen: true
              }
            });
           }
         )
  
    }




        if( cartList.length === 0 ){
          var show = <EmptyCartDiv/>
        }else{
            show =
            
            
            
            <>
            <div className="tablescroll" id="tablescroll" >

                <table className="retailcartpage-cart" >

                    <FoodCartHeader
                        lists={['#','Product','Name','Price','Quantity','Total','Action']}
                    />

                    { cartList.map( (rest , index) => {

                            return <FoodCartItem
                                    key={rest.id}
                                    index={ index + 1 }
                                    to={'/product' + rest.product.slug + ':' + rest.product.id}
                                    img={rest.product.product_img1}
                                    product_name={rest.product.product_name}
                                    price={rest.product.price}
                                    quantity={rest.quantity}
                                    changeQuantity={ (event) => change_item_quantity(event,rest.product.id) }
                                    total_price={ rest.quantity * rest.product.price }
                                    save={ () => UpdateCartdetails(rest.product.id) }
                                    delete={ () => remove_from_cart(index,rest.product.id) }
                                />

                            } )}

                </table>

            </div>

            <FoodCartTotal
                totals={[
                    {title:'Total',value:total},
                ]}
            />

            <div className="retailcartpage-btm" >
                <Link to="/wholesale" className="retailcartpage-btm-link" >
                    Continue Shopping
                </Link>
                <button onClick={ () => setOpentc(true) } className="retailcartpage-btm-link" >
                    Proceed To Checkout
                </button>
            </div>

        </>
            
            
            
            

        }

  

      return ( 

        <>

          <Backdrop  show={ Opentc } >

          { Opentc ? 
          
        
          <TermsandCondition 
              Agree={ props.gotofront }
              Cancel={ () => setOpentc(false) } >
              {TermsandConditionListOrder}
          </TermsandCondition>

          : null
          
           }

          </Backdrop>

          
            {show}
        </>

      );

}

export default WholeSaleCart;