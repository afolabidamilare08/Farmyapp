import React from 'react';
// import {Link} from 'react-router-dom';


const Cartpagebtm = (props) => {

      return ( 

                <div className="cartpage-bttom-top" >

                    <div className="cartpage-bttom-top-right" >
                        <div className="cartpage-bttom-top-right-det" >
                            <div className="cartpage-bttom-top-right-det-1" >
                                <span className="cartpage-bttom-top-right-det-1-total" >Total: </span> 
                                <span className="cartpage-bttom-top-right-det-1-value" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.totalprice)}</span>
                            </div>
                            <div className="cartpage-bttom-top-right-det-2" >
                                Transport fee not included yet
                            </div>
                        </div>
                        { props.totalprice < 1 ? null :
                          <button className="cartpage-bttom-top-right-procced" onClick={ props.moveForward } > checkout</button>
                        }
                    </div>

                </div>

      );

}

export default Cartpagebtm;