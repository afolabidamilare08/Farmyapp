import React , { useContext , useEffect , useState } from 'react';
import Individitem from './individual-item-temp/indi_temp';
import Store from '../../store/managementstore/managementstore';
import Cartbtm from './cart-sticky-btm/cart-page-bttom';
import Axios from 'axios';
import TopbannerDiv from '../utilities/top-banner-msg/topbannermsg';
import { TermsandCondition , TermsandConditionListOrder } from '../utilities/TermsAndCondition/termsandcondition';
import Backdrop from '../utilities/Backdrop/backdrop';
import { Link } from 'react-router-dom';
import CartPng from './cart.png';


const Cart = (props) => {

    const [total,settotal] = useState(null)

    const [ cartList , setcartList ] = useState([ ])

    const [ Opentc , setOpentc ] = useState(false)

    const [ message , setmessage ] = useState({
      status:false,
      message:'',
      bgcolor:'orange'
    })

    const context = useContext(Store)

    const User_cart_id = context.User_cart_id

    useEffect( () => {
      settotal(null)
      Axios({ method: 'GET',url:'carts/cart/' + User_cart_id + '/' })
      .then( response => {
          settotal(response.data.get_total_cost)
          setcartList(response.data.items)
          } )
    } , [User_cart_id] )


   const change_item_quantity = ( event , id ) => {

      const itemIndex = cartList.findIndex( i => {
        return i.product.id === id
      } )
  
        const item = {...cartList[itemIndex]}
  
        item.quantity = event.target.value
  
        const newlist = [...cartList]
  
        newlist[itemIndex] = item
  
        setcartList(newlist)    

    }

    const UpdateCartdetails = (id) => {

      setmessage({
        status:true,
        message:'Updating Cart .....',
        bgcolor:'orange'
      })

        const itemIndex = cartList.findIndex( i => {
          return i.product.id === id
        } )
  
        const item = {...cartList[itemIndex]}

        if( item.product.quantity_remaining ){
          var numberTochk = item.product.quantity_remaining
        }else{
          numberTochk = item.product.quantity_available
        }

        if( item.quantity > numberTochk ){
          setmessage({
            status:true,
            message:'only ' + numberTochk + ' ' + item.product.measurement_scale + ' are remaining' ,
            bgcolor:'red'
          })
        }else{

          const quantityChange = { quantity:item.quantity , product_id: id }

  
        Axios.put( '/carts/cart/ ' + User_cart_id + ' /add_to_cart/' , quantityChange ).then(
          response => {
                var user_id = context.User_cart_id
                Axios({ method: 'GET',url:'carts/cart/' + user_id + '/' })
                .then( response => {
                    settotal(response.data.get_total_cost)
                    setmessage({
                      status:true,
                      message:'Your Cart Was Successfully Updated',
                      bgcolor:'rgb(39, 180, 39)'
                    })
                    } ).catch( e => {
                        setmessage({
                          status:true,
                          message:'something went wrong , try reloading the page and try again',
                          bgcolor:'red'
                        })
                    } )
          }
        ).catch( e => {
            setmessage({
              status:true,
              message:'something went wrong , try reloading the page and try again',
              bgcolor:'red'
            })
        } )

        }

    }
  
  
    // add_to_userdetailsHandler = ( detail,detail2 ) => {
    //   this.setState({User_details:{detail,detail2}})
    // }
  
  
  
    const  remove_from_cart = ( productIndex , itemid ) => {
  
      setmessage({
        status:true,
        message:'Removing item.....',
        bgcolor:'orange'
      })

        // const item = [ ...cartList ]
  
        // item.splice(productIndex,1);
        // this.setState({cart:{...this.state.cart,items:item}})
  
        const prodId = { product_id: itemid }  
        Axios.post( 'carts/cart/' + User_cart_id + '/remove_from_cart/' , prodId ).then(
          response => {
            setcartList(response.data.items)
            settotal(response.data.get_total_cost)
            setmessage({
              status:true,
              message:' One Item In Your Cart Was removed',
              bgcolor:'rgb(39, 180, 39)'
            })
            context.updatecartHandler() 
          }
         )
  
    }




        if( cartList.length === 0 ){
          var show = <div className="empty-cart-div" > 
          
                          <img src={CartPng} alt="" className="empty-cart-div-img" />
                          <div className="empty-cart-div-txt" > Your Cart Is Currently Empty </div>
                          <Link className="empty-cart-div-btn" to='/' > Start Shopping </Link>

                      </div>
        }else{
            show = cartList.map( (rest , index) => {
              return <Individitem
                      key={rest.id}
                      to={'/product' + rest.product.slug + ':' + rest.product.id}
                      product_name={rest.product.product_name}
                      product_to={"/product"+rest.product.slug+":"+rest.product.id}
                      product_price={rest.product.price}
                      product_scale={rest.product.measurement_scale}
                      product_img={ 'http://127.0.0.1:8000' + rest.product.product_img1}
                      product_des={rest.product.description}
                      qutyavil={ rest.product.quantity_remaining !== null ? rest.product.quantity_remaining + ' ' + rest.product.measurement_scale : rest.product.quantity_available + ' ' + rest.product.measurement_scale }
                      updateItemquty={ () => UpdateCartdetails(rest.product.id) }
                      product_quantity={rest.quantity}
                      product_subtotal={ rest.quantity * rest.product.price }
                      changequantity={ (event) => change_item_quantity(event,rest.product.id) }
                      removeItem={ () => remove_from_cart(index,rest.product.id) } />
          } )
        }

  

      return ( 

        <>

        <TopbannerDiv
          closeshow={ () => setmessage({
            status:false,
            message:'',
            bgcolor:'orange'
          }) }
          show={ message.status }
          backgroundcolor={ message.bgcolor }
          message={ message.message } />

          <Backdrop  show={ Opentc } >

          { Opentc ? 
          
        
          <TermsandCondition 
              Agree={ props.gotofront }
              Cancel={ () => setOpentc(false) } >
              {TermsandConditionListOrder}
          </TermsandCondition>

          : null
          
           }

          </Backdrop>

        <div className="carty-div-box" style={ { height: cartList.length === 0 ? '80vh' : '' } } >
            
            <div className="carty-div-box-top" > 
              <div className="carty-div-box-top-1" > My Cart ( {cartList.length} ) </div>
            </div>

            {show}

                <Cartbtm
                  moveForward={ () => setOpentc(true) }
                  totalprice={ total ? total : '0' } />

        </div>
        
        </>

      );

}

export default Cart;