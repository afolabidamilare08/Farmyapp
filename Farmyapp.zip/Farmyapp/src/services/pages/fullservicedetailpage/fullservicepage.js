import React , { useState, useContext } from 'react';
import FullservComp from '../../components/fullservicedisplaycomp/fullservicesdisplaycomp';
import { useGetService } from './getServices';
import Backdrop from '../../../component/utilities/Backdrop/backdrop';
import Commentdiv from '../../components/fullservicedisplaycomp/coment-div/comment-div';
import Availabledays from '../../components/fullservicedisplaycomp/available_days/availabledays';
import Store from '../../../store/managementstore/managementstore';
import GoBackDiv from '../../../component/utilities/goBack/goback';
import Svg from '../../../component/utilities/Svg';

const FullServicepage = (props) => {

    const context = useContext(Store)

    const [serviceBigimg , setserviceBigimg] = useState(null)
    const [ openimgbigprev , setopenimgbigprev ] = useState( { status: false , image: '' } )
    const [ Daystobemaped , setDaystobemaped ] = useState([])
  

    const Servslug = props.match.params.slug
    const Servid = props.match.params.id

    const [ Servicedata ] = useGetService( { Servslug , Servid } )

    const [ wehavedays , setwehavedays ] = useState(false)
    
    const pushUnathorized = () => {
        props.history.push('/signin')
    }

    const mapingofAvailabledays = () => {

        var newDaysArray = []
        
            if( Servicedata.monday ){
                newDaysArray.push( { day:'Monday' ,
                                  available_hours1: Servicedata.monday_available_hours1 ,
                                  available_hours2: Servicedata.monday_available_hours2  } )
            }

            if( Servicedata.tuesday ){
                newDaysArray.push( { day:'Tuesday' ,
                                 available_hours1: Servicedata.tuesday_available_hours1 ,
                                 available_hours2: Servicedata.tuesday_available_hours2  } )
            }

            if( Servicedata.wednesday ){
                newDaysArray.push( { day:'Wednesday' ,
                                  available_hours1: Servicedata.wednesday_available_hours1 ,
                                  available_hours2: Servicedata.wednesday_available_hours2  } )
            }

            if( Servicedata.thursday ){
                newDaysArray.push( { day:'Thursday' ,
                                 available_hours1: Servicedata.thursday_available_hours1 ,
                                 available_hours2: Servicedata.thursday_available_hours2  } )
            }

            if( Servicedata.friday ){
                newDaysArray.push( { day:'Friday' ,
                                  available_hours1: Servicedata.friday_available_hours1 ,
                                  available_hours2: Servicedata.friday_available_hours2  } )
            }

            if( Servicedata.saturday ){
                newDaysArray.push( { day:'Saturday' ,
                                 available_hours1: Servicedata.saturday_available_hours1 ,
                                 available_hours2: Servicedata.saturday_available_hours2  } )
            }

            if( Servicedata.sunday ){
                newDaysArray.push( { day:'Sunday' ,
                                  available_hours1: Servicedata.sunday_available_hours1 ,
                                  available_hours2: Servicedata.sunday_available_hours2  } )
            }

        var BestDaysArray = []
        setwehavedays(true)

        for (let i = 0; i < newDaysArray.length; i++) {
            var dayY = newDaysArray[i]

            if( dayY.available_hours1 > 12 ){
                var openingTrange = 'Pm'
                var openingTime = dayY.available_hours1 - 12
            }else{
                openingTrange = 'Am'
                openingTime = dayY.available_hours1
            }

            if( dayY.available_hours2 > 12 ){
                var closingTrange = 'Pm'
                var closingTime = dayY.available_hours2 - 12
            }else{
                closingTrange = 'Am'
                closingTime = dayY.available_hours2
            }

            BestDaysArray.push( { day: dayY.day , openingTime: openingTime , openingTrange: openingTrange , closingTime: closingTime , closingTrange: closingTrange } )

        } 
        
        setDaystobemaped(BestDaysArray)

    }

    if ( Servicedata ) {
      
        var ratingNumber = Servicedata.avg_rating

        var ArrayStars = []

        var namwir = String(ratingNumber)

        if( namwir.length > 1 ){

            var firstNumber = Number(namwir[0])
            var putIt = String(namwir[0]) + '.' + String(namwir[2])

            for (let l = 0; l < firstNumber ; l++) {
  
              ArrayStars.push( { 
                href:'opps.svg#icon-star-full' , 
                fill:'rgba(13, 194, 94, 0.986)'
               } )
              
            }

            ArrayStars.push({
              href:'opps.svg#icon-star-half' , 
              fill:'rgba(13, 194, 94, 0.986)'
            })

            for (let j = firstNumber + 1 ; j < 5 ; j++) {
    
              ArrayStars.push( { 
                href:'opps.svg#icon-star-empty' , 
                fill:'rgba(13, 194, 94, 0.986)'
              } )
              
            }

        }


        if( namwir.length === 1 ){

          putIt = ratingNumber

          for (let l = 0; l < ratingNumber ; l++) {
  
            ArrayStars.push( { 
              href:'opps.svg#icon-star-full' , 
              fill:'rgba(13, 194, 94, 0.986)'
             } )
            
          }
  
          for (let j = ratingNumber; j < 5 ; j++) {
    
            ArrayStars.push( { 
              href:'opps.svg#icon-star-empty' , 
              fill:'rgba(13, 194, 94, 0.986)'
            } )
            
          }
        }



        var Wesss =                     ArrayStars.map( ( star , index ) => {
          return  <Svg
                    key={index}
                    className="productDetailBox-div-seller-rating-ic-col"
                    href={ star.href } /> 
        } )

    }

    if(Servicedata){

        if( Servicedata && Daystobemaped.length === 0  && wehavedays === false ){
            mapingofAvailabledays()
        }
        
        var ServicesDetail = 
        <FullservComp
            mainimage={ serviceBigimg === null ? Servicedata.service_img1 : serviceBigimg } 
            openimgbigprev={ () => setopenimgbigprev({status:true,image: !serviceBigimg ? Servicedata.service_img1 : serviceBigimg }) }

            control1={ () => setserviceBigimg( Servicedata.service_img1 ) }
            productimage0={ Servicedata.service_img1 }

            control2={ () => setserviceBigimg( Servicedata.service_img2 ) }
            productimage2={ Servicedata.service_img2 }

            control3={ () => setserviceBigimg( Servicedata.service_img3 ) }
            productimage3={ Servicedata.service_img3 }

            serviceName={ Servicedata.service_name }

            serviceDescription={ Servicedata.description }

            rating={Wesss}
            ratenarate={ <span style={{ fontSize:'1.3rem' , fontWeight:'700' , marginLeft:'1rem' , color:'#333' }} > { putIt } Avg Rating </span> }

            workingHours={ Servicedata ?     
                
                Daystobemaped.map( Avil => {
                    return <Availabledays
                                key={Avil.day}
                                day={Avil.day}
                                openTime={Avil.openingTime}
                                openRange={Avil.openingTrange}
                                closeTime={Avil.closingTime}
                                closeRange={Avil.closingTrange} />
                } )   : null }

            listofAvailableDays={ Servicedata ?     
                
                Daystobemaped.map( Avil => {
                    return <Availabledays
                                key={Avil.day}
                                day={Avil.day}
                                openTime={Avil.openingTime}
                                openRange={Avil.openingTrange}
                                closeTime={Avil.closingTime}
                                closeRange={Avil.closingTrange} />
                } )   : null }

            serviceprice={new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(Servicedata.price_per_hour)}

            hireservicebtn={ context.Token ? () => props.history.push( '/bookservice' + Servicedata.slug + ':' + Servicedata.id) : 
                                () => props.history.push( '/signin') }

            state={ Servicedata.address[0].state }

            lga={ Servicedata.address[0].lga }

            address={ Servicedata.address[0].address }

            />
        }else{
            ServicesDetail = <Backdrop show={true} />
        }

      return ( 
          <>
            
            <Backdrop show={openimgbigprev.status} >
              <button className="big_img_close" onClick={ () => setopenimgbigprev({ ...openimgbigprev , status:false }) } >
              <Svg className="big_img_close-ic" href="sprite2.svg#icon-add" />
              </button>
              <div className="big_img-div" >
                  <img alt="" className="big_img-div_img" src={openimgbigprev.image} />
                  <div className="big_img_ctr" >
                        <div className="big_img_ctr_img" >
                            <img alt="" src={ Servicedata ? Servicedata.service_img1 : '' } onClick={ () => setopenimgbigprev( { ...openimgbigprev , image: Servicedata ? Servicedata.service_img1 : '' } ) } className="big_img_ctr_img_img" />
                        </div>
                        <div className="big_img_ctr_img" >
                            <img alt="" src={ Servicedata ? Servicedata.service_img2 : '' } onClick={ () => setopenimgbigprev( { ...openimgbigprev , image: Servicedata ? Servicedata.service_img2 : '' } ) } className="big_img_ctr_img_img" />
                        </div>
                        <div className="big_img_ctr_img" >
                            <img alt="" src={ Servicedata ? Servicedata.service_img3 : '' } onClick={ () => setopenimgbigprev( { ...openimgbigprev , image: Servicedata ? Servicedata.service_img3 : '' } ) } className="big_img_ctr_img_img" />
                        </div>
                  </div>
              </div>
          </Backdrop>

          <div className="fullservicepage-div" >
              { ServicesDetail }
              <Commentdiv
                comment_list={ Servicedata ? Servicedata.comments : null }
                service_id={ Servicedata ? Servicedata.id : null }
                notsignin={ pushUnathorized } />

                    <GoBackDiv to={ () => props.history.goBack() } />


          </div>



          </>
      );

}

export default FullServicepage;