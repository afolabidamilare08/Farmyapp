import { useState , useEffect } from 'react';
import Axios from 'axios'

export const useGetService = ( servinfo ) => {

    const [ servicedata , Setservicedata ] = useState()

    useEffect( () => {
        Axios.get( '/service/'  + servinfo.Servid + '/' ).then(
            response => {
                Setservicedata(response.data)
            }
        ).catch()
        
    } , [servinfo.Servid] )
    

    return [ servicedata ]

}