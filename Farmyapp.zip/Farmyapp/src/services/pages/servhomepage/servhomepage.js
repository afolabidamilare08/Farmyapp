import React , { useState } from 'react';
import SliderIndex from '../../../component/home-slider/home-slider';
import {useGetservices} from './getservicesLogic';
import Product from '../../../component/product_template/product_template';
import {Link} from 'react-router-dom';
import Buisness from './customer-service.png';

const Servhomepage = (props) => {

      const [ limit ] = useState({ limit: 0 , offset:0 })

      const [ datafrombackend ] = useGetservices(limit)

          //checking if Homeproduct do exit in other to aviod infinite loop and also to display the content with mapping
    //////////////////////////////////////////

    if( datafrombackend ){

        if( datafrombackend.results.length > 0 ){

            var display =   datafrombackend.results.map( ( service , index) => {
      
                return <Product
                img={service.service_img1}
                product={service.service_name}
                key={service.id}
                product_des={service.description}
                add_to_cart
                action={'HIRE ME'}
                lga={service.address[0].lga}
                state={service.address[0].state}
                price={service.price_per_hour}
                kg={'Hour'}
                to={'/fullserv' + service.slug + ":" + service.id } />
            
            }
    
            )

        }else{
            display = display = <div className="empty-cart-div" style={{marginTop:'4rem'}} > 
          
                                    <img src={Buisness} alt="" className="empty-cart-div-img" />
                                    <div className="empty-cart-div-txt" style={{ textAlign:'center' }} >  All Service Agents Seem To Be Busy At The Moment Please Check Back In A Moment </div>

                                </div>

        }
 
         var paglink = []
 
         for (let f = 0; f < (datafrombackend.count/24) ; f++) {
             paglink.push( { no: 1 + f  , limit: 1 , offset: f * 24 } )
         }
 
     }
 
     ///////////////////////////////////////////
     //====

      return (

        <div className="servhomepage" >
            <SliderIndex/>
            <div className="servhomepage_sev-div" >

            {display}

            </div>
            <div className="pagination_div" >
                { datafrombackend ? 
                         
                         paglink.map( pag => {

                             if( pag.no === 1 ){
                                 return <Link key={'/services'} className="pagination_div_link" to={ '/services'} > 
                                     { pag.no }
                                 </Link>
                             }else{
                                 return <Link key={ '/' + pag.limit + ':' + pag.offset }  className="pagination_div_link" to={  '/moreserv' + pag.offset  } > 
                                 { pag.no }
                             </Link>
                             }

                         } )

                      : null   }
              </div>
        </div>

      );

}

export default Servhomepage;
