import { useState , useEffect } from 'react';
import Axios from 'axios';

export const useGetservices = ( limitandoffset ) => {

  const [ datafrombackend , setdatafrombackend ] = useState()

  useEffect( () => {
    Axios({
      method:'GET',
      url:'/service/',
      params:{ limit: limitandoffset.limit , offset: limitandoffset.offset }
    }).then( response => {
      setdatafrombackend(response.data)
    } )
    // eslint-disable-next-line
  } , [] )

  return [ datafrombackend ]

}
