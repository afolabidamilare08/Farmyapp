import React , { useState , useEffect } from 'react';
import SliderIndex from '../../../component/home-slider/home-slider';
import Product from '../../../component/product_template/product_template';
import {Link} from 'react-router-dom';
import Axios from 'axios';

const MoreServices = (props) => {

    // console.log(props)

    var offset = props.match.params.offset

      const [ MoreServices , setMoreServices ] = useState(null)

     useEffect( () => {

         Axios( {
             method:'GET',
             url:'/service/',
             params:{ limit:24 , offset:offset }
         } ).then( 
             response => {
                 setMoreServices(response.data)
             }
          )

     } , [offset] )

    if( MoreServices ){
      var display =   MoreServices.results.map( ( service , index) => {
      
             return <Product
             img={service.service_img1}
             product={service.service_name}
             key={service.id}
             product_des={service.description}
             add_to_cart
             action={'HIRE ME'}
             price={service.price_per_hour}
             kg={'Hour'}
             to={'/fullserv' + service.slug + ":" + service.id } />
         
         }
 
         )
 
         var paglink = []
 
         for (let f = 0; f < (MoreServices.count/24) ; f++) {
             paglink.push( { no: 1 + f  , limit: 1 , offset: f * 24 } )
         }
 
 
 
     }
 
     ///////////////////////////////////////////
     //====

      return (

        <div className="servhomepage" >
            <SliderIndex/>
            <div className="servhomepage_sev-div" >

            {display}

            </div>
            <div className="pagination_div" >
                { MoreServices ? 
                         
                         paglink.map( pag => {

                             if( pag.no === 1 ){
                                 return <Link key={'/services'} className="pagination_div_link" to={ '/services'} > 
                                     { pag.no }
                                 </Link>
                             }else{
                                 return <Link key={ '/' + pag.limit + ':' + pag.offset }  className="pagination_div_link" to={ '/moreserv' + pag.offset } > 
                                 { pag.no }
                             </Link>
                             }

                         } )

                      : null   }
              </div>
        </div>

      );

}

export default MoreServices;
