import React, { useState, useEffect } from 'react';
import Svg from '../../../component/utilities/Svg'
import Backdrop from '../../../component/utilities/Backdrop/backdrop';
import PayStackDiv from '../../../component/payment_component/payment_component';
import Axios from 'axios';

const FinalchkServ = (props) => {

      const [ OrderDetails , setOrderDetails ] = useState(null)
      
      const [ OpenPaymentSytem , setOpenPaymentSytem  ] = useState(false)

      const OderId = props.match.params.id

      useEffect( () => {
            Axios.get( '/sorder/dodo/' + OderId + '/' ).then( 
                  response => {
                        setOrderDetails(response.data)
                  }
             )
      } , [ OderId ] )

      if( OrderDetails ){

            var op = OrderDetails.prefered_time[0] + OrderDetails.prefered_time[1]
            var newop = Number(op)

            
            if( newop > 12 ){
                  var openingTrange = 'PM'
                  var openingTime = newop - 12
              }else{
                  openingTrange = 'AM'
                  openingTime = newop
              }

      }


      const payOrderHandler = () => {

            Axios.patch( '/sorder/dodo/' + OderId + '/' , {status:'paid'} ).then(
                  response => {
                        var Tosend = {
                              user:OrderDetails.customer.id,
                              to:OrderDetails.service.user.id,
                              target_id:OrderDetails.service.id,
                              target_ct:'service',
                              verb:' someone hired you ',
                              read:false
                          }
          
                          Axios.post('/notification/action/' , Tosend ).then( 
                              response => {
                                    props.history.push('/services_hired')

                              }
                           )
                  }
            )

      }


      const CancelOrder = () => {

            Axios.delete( '/sorder/dodo/' + OderId + '/' ).then(
                  response => {
                        props.history.push('/bookservice' + OrderDetails.service.slug + ':' + OrderDetails.service.id)
                  }
            )

      }


      return ( 



           <> 

            <Backdrop show={ OpenPaymentSytem } >  
                  <PayStackDiv
                        cancelpayment={ () => setOpenPaymentSytem(false) }
                        callback={ payOrderHandler }
                        email={ OrderDetails ? OrderDetails.customer.email : '' }
                        amount={ OrderDetails ? OrderDetails.cost + '00' : '' }
                      />
            </Backdrop>

      { OrderDetails ?

          <div className="FinalchkServ-div" >
 
                <div className="FinalchkServ-div-main" >
                   <div className="FinalchkServ-div-main-top" >
                        Hire Summary
                   </div>
                   <div className="FinalchkServ-div-main-main" >

                        <div className="FinalchkServ-div-main-main-top" >
                              <div className="FinalchkServ-div-main-main-top-1" >
                                    <img className="FinalchkServ-div-main-main-top-1-img" alt="" src={ OrderDetails.service.service_img1 } />
                              </div>
                              <div className="FinalchkServ-div-main-main-top-2" >
                                    { OrderDetails.service.service_name }
                              </div>
                        </div>

                        <div className="FinalchkServ-div-main-main-title" >
                          Service Location
                        </div>

                        <div className="FinalchkServ-div-main-main-location" >
                              
                              { OrderDetails.service.address[0].address }

                              <div className="FinalchkServ-div-main-main-location-inside" >
                                    { OrderDetails.service.address[0].lga } , { OrderDetails.service.address[0].state }
                              </div>

                        </div>

                        <div style={{ display:'flex' , justifyContent:'space-evenly' }} > 
                              <div>
                                    <div className="FinalchkServ-div-main-main-title" >
                                    Service Contact
                                    </div>

                                    <div className="FinalchkServ-div-main-main-contact" >
                                          { OrderDetails.service.user.first_name } { OrderDetails.service.user.last_name }
                                          <br/>
                                          { OrderDetails.service.user.pro.phone_number }
                                          <br/>
                                          {/* adeey@gmail.com */}

                                    </div>
                              </div>

                              <div>
                                    <div className="FinalchkServ-div-main-main-title" >
                                    Opening Time
                                    </div>

                                    <div className="FinalchkServ-div-main-main-duration" style={{ textAlign:'center' }} >
                                          { OrderDetails.day } <br/> { openingTime } { openingTrange } 
                                    </div>
                              </div>

                              <div>
                                    <div className="FinalchkServ-div-main-main-title" >
                                    Hire Duration
                                    </div>

                                    <div className="FinalchkServ-div-main-main-duration" style={{ textAlign:'center' }}  >
                                          { OrderDetails.duration } Hours 
                                    </div>
                              </div>
                        </div>

                   </div>

                   <div className="FinalchkServ-div-main-btm" >

                        <div className="FinalchkServ-div-main-btm-right" >
                        <div className="FinalchkServ-div-main-btm-right-det" >
                              <div className="FinalchkServ-div-main-btm-right-det-1" >
                                    <span className="FinalchkServ-div-main-btm-right-det-1-total" >Total: </span> 
                                    <span className="FinalchkServ-div-main-btm-right-det-1-value" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(OrderDetails.cost)} </span>
                              </div>
                              <div className="FinalchkServ-div-main-btm-right-det-2" >
                                    Transport fee is not included
                              </div>
                        </div>
                        <button className="FinalchkServ-div-main-btm-right-procced" onClick={ () =>setOpenPaymentSytem(true) } > Procced To Pay </button>
                        </div>

                  </div>

                </div>

                <div className="FinalchkServ-div-sub" >
                   <div className="FinalchkServ-div-sub-split" >
                        <div className="FinalchkServ-div-sub-split-top" >
                            My Contact Details
                        </div>
                        <div className="FinalchkServ-div-sub-split-profileDetail" >
                              <Svg className="FinalchkServ-div-sub-split-profileDetail-ic" href="contact.svg#icon-person" />
                              <span className="FinalchkServ-div-sub-split-profileDetail-span" > { OrderDetails.customer.first_name } { OrderDetails.customer.last_name } </span>
                        </div>
                        <div className="FinalchkServ-div-sub-split-profileDetail" >
                              <Svg className="FinalchkServ-div-sub-split-profileDetail-ic" href="sprite4.svg#icon-mail" />
                              <span className="FinalchkServ-div-sub-split-profileDetail-span" > { OrderDetails.customer.email } </span>
                        </div>
                        <div className="FinalchkServ-div-sub-split-profileDetail" >
                              <Svg className="FinalchkServ-div-sub-split-profileDetail-ic" href="contact.svg#icon-phone" />
                              <span className="FinalchkServ-div-sub-split-profileDetail-span" > { OrderDetails.customer.pro.phone_number } </span>
                        </div>
                   </div>
                   <div className="FinalchkServ-div-sub-split" >
                        <div className="FinalchkServ-div-sub-split-top" >
                            Work Address
                        </div>
                        <div className="FinalchkServ-div-sub-split-location" >
                           <div className="FinalchkServ-div-sub-split-location-1" >
                              <Svg 
                                    className="FinalchkServ-div-sub-split-location-1-ic"
                                    href="sprite4.svg#icon-location_onplaceroom"
                              /> 
                           </div>
                           <div className="FinalchkServ-div-sub-split-location-2" >

                              { OrderDetails.address }

                              <div className="FinalchkServ-div-sub-split-location-2-sub" >
                                    {OrderDetails.lga} , { OrderDetails.state }
                              </div>

                           </div>
                        </div>
                   </div>
                   <div className="FinalchkServ-div-sub-split" >
                    <button className="FinalchkServ-div-sub-split-cancelOrder" onClick={ CancelOrder } > Cancel order </button>
                   </div>
                </div>

          </div>

            : <Backdrop show={true} /> }

          </>
      );

}

export default FinalchkServ;