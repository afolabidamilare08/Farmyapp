import { useState , useEffect } from 'react';
import Axios from 'axios';

export const useSearch = ( query  , address , mainOffset  ) => {

    const [ result , setresult ] = useState(null)



    if( address === '' ){
        if( mainOffset === '0' ){
            // console.log('i have offset ')
            var add = { search: query  }
        }else{
            add = { search: query , offset: mainOffset }
        }
    }else{
        if( mainOffset === '0' ){
            add = { search: query + ' ' + address }
        }else{
            add = { search: query + ' ' + address , offset: mainOffset }
        }
    }

    useEffect( () => {

        Axios({
            method:'GET',
            url:'/service/',
            params:add
        }).then(
            response => {
                setresult(response.data)
            }
        )

        // eslint-disable-next-line
    } , [query, address,mainOffset] )

    return [result]

} 

