import React , {useState,useEffect} from 'react';
import AddServices from '../../components/add_services/add_services';
import Topbanner from '../../../component/utilities/top-banner-msg/topbannermsg';
import {useVerifynum} from '../../../component/utilities/checkingforletter';
import Axios from 'axios';
import {AddtimeComp} from '../../components/booking_service_component/addtime_date';
import Backdrop from '../../../component/utilities/Backdrop/backdrop';
import Availabledays from '../../components/fullservicedisplaycomp/available_days/availabledays';
import Svg from '../../../component/utilities/Svg';
import LeafletMapDiv from '../../../component/LeafletMap/LeafletMap';
import { Popup } from 'react-leaflet';


const EditServices = (props) => {

    const [ postdata , setpostdata ] = useState(
        {
          serviceName: '',
          serviceDescription:'',
          servicesPrice:'',
          openingHours1:'',
          openingHours2:'',
          imagetopost:{
            img1:null,
            img2:null,
            img3:null
          },
          imagetopreview:{
            img1:null,
            img2:null,
            img3: null
          },
          country:'',
          state:'',
          Lga:'',
          address:'',
          longitude:'',
          latitude:'',
          address_Id:'',
          account_name:'',
          account_number:'',
          bank_name:''
        }
      ) 

      const [ openMap , setopenMap ] = useState(false)

      const [initialpictures,setinitialpictures] = useState(
        {
          img1:null,
          img2:null,
          img3: null
        }
      )

      var service_id = props.match.params.id
      // var service_slug = props.match.params.slug
      
      useEffect( () => {

          Axios.get( '/service/' + service_id + '/' ).then(
              response => {
                  // console.log(response)
                  setinitialpictures({
                      img1:response.data.service_img1,
                      img2:response.data.service_img2,
                      img3:response.data.service_img3
                  })
                  setpostdata( 
                    {
                        serviceName: response.data.service_name,
                        serviceDescription:response.data.description,
                        servicesPrice:response.data.price_per_hour,
                        openingHours1:'',
                        openingHours2:'',
                        imagetopost:{
                          img1:null,
                          img2:null,
                          img3:null
                        },
                        imagetopreview:{
                          img1: response.data.service_img1 ,
                          img2: response.data.service_img2,
                          img3: response.data.service_img3
                        },
                        country:response.data.address[0].country,
                        state:response.data.address[0].state,
                        Lga:response.data.address[0].lga,
                        address:response.data.address[0].address,
                        longitude:response.data.address[0].longitude,
                        latitude:response.data.address[0].latitude,
                        address_Id:response.data.address[0].id,
                        account_name:response.data.account_name,
                        account_number:response.data.account_number,
                        bank_name:response.data.bank_name
                      
                  } )

                  var newDaysArray = []
        
                  if( response.data.monday ){
                      newDaysArray.push( { day:'Monday' ,
                                        available_hours1: response.data.monday_available_hours1 ,
                                        available_hours2: response.data.monday_available_hours2  } )
                  }
      
                  if( response.data.tuesday ){
                      newDaysArray.push( { day:'Tuesday' ,
                                       available_hours1: response.data.tuesday_available_hours1 ,
                                       available_hours2: response.data.tuesday_available_hours2  } )
                  }
      
                  if( response.data.wednesday ){
                      newDaysArray.push( { day:'Wednesday' ,
                                        available_hours1: response.data.wednesday_available_hours1 ,
                                        available_hours2: response.data.wednesday_available_hours2  } )
                  }
      
                  if( response.data.thursday ){
                      newDaysArray.push( { day:'Thursday' ,
                                       available_hours1: response.data.thursday_available_hours1 ,
                                       available_hours2: response.data.thursday_available_hours2  } )
                  }
      
                  if( response.data.friday ){
                      newDaysArray.push( { day:'Friday' ,
                                        available_hours1: response.data.friday_available_hours1 ,
                                        available_hours2: response.data.friday_available_hours2  } )
                  }
      
                  if( response.data.saturday ){
                      newDaysArray.push( { day:'Saturday' ,
                                       available_hours1: response.data.saturday_available_hours1 ,
                                       available_hours2: response.data.saturday_available_hours2  } )
                  }
      
                  if( response.data.sunday ){
                      newDaysArray.push( { day:'Sunday' ,
                                        available_hours1: response.data.sunday_available_hours1 ,
                                        available_hours2: response.data.sunday_available_hours2  } )
                  }
      
              var BestDaysArray = []
      
              for (let i = 0; i < newDaysArray.length; i++) {
                  var dayY = newDaysArray[i]
      
                  if( dayY.available_hours1 > 12 ){
                      var openingTrange = 'Pm'
                      var openingTime = dayY.available_hours1 - 12
                  }else{
                      openingTrange = 'Am'
                      openingTime = dayY.available_hours1
                  }
      
                  if( dayY.available_hours2 > 12 ){
                      var closingTrange = 'Pm'
                      var closingTime = dayY.available_hours2 - 12
                  }else{
                      closingTrange = 'Am'
                      closingTime = dayY.available_hours2
                  }
      
                  BestDaysArray.push( { day: dayY.day , openingTime: openingTime , openingTrange: openingTrange , closingTime: closingTime , closingTrange: closingTrange } )
      
              }

                  setDaystoprev(BestDaysArray)

                  
              }
          ).catch()

      } , [service_id] )

      const [ postprogress , setpostprogress ] = useState({
        status: false ,
        bgcolor:'',
        message:''
      })


      const [ addtimeerror , setaddtimeerror ] = useState(null)

      // All Logic concerning adding Date and time
      //////////////////////////

      const [ openaddtime , setopenaddtime ] = useState(false)

      const [ editdate , seteditdate ] = useState(false)
      const [ editdatedetail , seteditdatedetail ] = useState()


      const [ difftimelist , setdifftimelist ] = useState({
        opendayslist: false,
        openOpeniningAmpm: false,
        openClosingAmpm: false
      })

      const [ availdate , setavaildate ] = useState({
        day:'Monday',
        openingTime:'',
        openingTrange: 'Am',
        closingTime:'',
        closingTrange: 'Am'
      })

      const [ Daystosend , setDaystosend ] = useState([])

      const [ Daystoprev , setDaystoprev ] = useState([])

      const  daysinaweek = [
        'Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'
      ]


      const chooseDayHandler = (day) => {
        setavaildate({...availdate,day:day})
        setdifftimelist({...difftimelist,opendayslist:false})
      }

      var printalldaysinaweek = daysinaweek.map( day => {
         return <div className="ad_information_hiring_form_time_3_li" onClick={ () => chooseDayHandler(day) } > {day} </div>
      } )

      const Timerange = [ 'Am' , 'Pm' ]
      
      const chooseopeningRange = (range) => {
        setavaildate({...availdate,openingTrange:range})
        setdifftimelist({...difftimelist,openOpeniningAmpm:false})
      }

      var printopeningrange = Timerange.map( range => {
        return <div className="ad_information_hiring_form_time_3_li" onClick={ () => chooseopeningRange(range) } > {range} </div>
     } )

     const chooseclosingRange = (range) => {
      setavaildate({...availdate,closingTrange:range})
      setdifftimelist({...difftimelist,openClosingAmpm:false})
    }

      var printclosingrange = Timerange.map( range => {
        return <div className="ad_information_hiring_form_time_3_li" onClick={ () => chooseclosingRange(range) } > {range} </div>
    } )

    const deleteatimezoneHandler = (index) => {

      const oldDayslist = [ ...Daystoprev ]

      oldDayslist.splice(index,1)

      setDaystoprev(oldDayslist)

    }

    const edittimezoneHandler = ( time , index ) => {

      setavaildate({
        day:time.day,
        openingTime:time.openingTime,
        openingTrange:time.openingTrange,
        closingTime:time.closingTime,
        closingTrange:time.closingTrange
      })

      
      seteditdatedetail(time)
      seteditdate(true)
      setopenaddtime(true)

    }

    const editdateHandler = () => {

        // console.log(editdatedetail)

        const TimezoneIndex = Daystoprev.findIndex( day => {
          return day.day === editdatedetail.day 
        } )

        var Thattimezone = {...Daystoprev[TimezoneIndex]}

        Thattimezone = { 
          day: editdatedetail.day,
          openingTime:availdate.openingTime,
          openingTrange:availdate.openingTrange,
          closingTime:availdate.closingTime,
          closingTrange:availdate.closingTrange
         }

         const AlltimeZone = [...Daystoprev]

         AlltimeZone[TimezoneIndex] = Thattimezone

         setDaystoprev(AlltimeZone)

         seteditdate(false)
         setopenaddtime(false)
      
    }

    const closeAddtimeHandler = () => {
      setopenaddtime(false)
      setaddtimeerror(null)
      setavaildate({
        day:'Monday',
        openingTime:'',
        openingTrange: 'Am',
        closingTime:'',
        closingTrange: 'Am'
      })

    }

      var mappingdaysTopreview = Daystoprev.map( ( time , index ) => {
        return <div className="editday-div" > 
                    <Availabledays
                      day={ time.day }
                      openTime={time.openingTime}
                      openRange={time.openingTrange}
                      closeTime={time.closingTime}
                      closeRange={time.closingTrange}
                        />
                      <button className="editday-div-btn" onClick={ () => edittimezoneHandler(time,index) } >
                        <Svg 
                          href="contact.svg#icon-pencil"
                          className="editday-div-btn-ic" />
                          edit
                      </button>
                      <button className="editday-div-btn  editday-div-btn-red" onClick={ () => deleteatimezoneHandler(index) } >
                        <Svg 
                          href="sprite3.svg#icon-delete"
                          className="editday-div-btn-ic" />
                          delete
                      </button>
                </div>
      } ) 


    const AddDayHandler = () => {

      if( (Number(availdate.closingTime) < 1 || Number(availdate.closingTime) > 12 ) || (Number(availdate.openingTime) < 1 || Number(availdate.openingTime) > 12 ) ){
        setaddtimeerror('Invalid time range')
      }else{
        
        var daychk = availdate.day
        const totalchk = Daystoprev.find( day => {
          return day.day === daychk
        } )

        if( totalchk ){
          setaddtimeerror( 'You have chosen "' + availdate.day + '" already' )
        }else{
           // setDaystoprev()
          // setDaystosend()
          var oldprev = [...Daystoprev]
          var oldsend = [...Daystosend]

          oldprev.push(availdate)
          setDaystoprev(oldprev)

          if( availdate.openingTrange === 'Pm' ){
            var addtopm1 = 12 + Number(availdate.openingTime)
          }else{
            addtopm1 = availdate.openingTime
          }

          if( availdate.closingTrange === 'Pm' ){
            var addtopm = 12 + Number(availdate.closingTime)
          }else{
            addtopm = availdate.closingTime
          }

          oldsend.push({day:availdate.day,opening_hour:addtopm1,closing_hour:addtopm})
          setDaystosend(oldsend)

          setavaildate({
            day:'Monday',
            openingTime:'',
            openingTrange: 'Am',
            closingTime:'',
            closingTrange: 'Am'
          })

          setaddtimeerror(null)

          // console.log(Daystoprev,Daystosend)

          setopenaddtime(false)
          
        }

      }


    }

    /////////////////////////
    /////=================================================



          //logic to check if the image uploaded is actually a picture and not another file
    //===========================


    const acceptedFileType = 'image/x-png , image/png, image/jpg, image/jpeg, image/gif '
    const acceptedFileTypeArray = acceptedFileType.split(',').map((item) => {return item.trim()} )

    const veriyfyFile = (file) => {
      const currentfile = file
      const currentfileType = currentfile.type

      if( !acceptedFileTypeArray.includes(currentfileType) ){
        return false
      }else{
        return true
      }

    }

    //////////////
    //=================================

    //logic for chexking the validation of the three image input with the verfiyfile function above 
    //and also to show the preview with the showpreview function below

    const choosefirstimageHandler = (event) => {
        if(veriyfyFile(event.target.files[0])){
          showpreview(event.target.files[0],1)
        }else{
          setpostprogress({ status: true , message:'Only jpg , jpeg , png , x-png and gif files are allowed', bgcolor:'red'})
          setpostdata( { ...postdata , imagetopost:{ ...postdata.imagetopost , img1: null } , imagetopreview: { ...postdata.imagetopreview , img1: initialpictures.img1 } } )
        }
    } 

    const choosesecondimageHandler = (event) => {
      if(veriyfyFile(event.target.files[0])){
        showpreview(event.target.files[0],2)
      }else{
        setpostprogress({ status: true , message:'Only jpg , jpeg , png , x-png and gif files are allowed', bgcolor:'red'})
        setpostdata( { ...postdata , imagetopost:{ ...postdata.imagetopost , img2: null } , imagetopreview: { ...postdata.imagetopreview , img2: initialpictures.img2 } } )
      }
    }  

    const choosethirdimageHandler = (event) => {
      if(veriyfyFile(event.target.files[0])){
        showpreview(event.target.files[0],3)
      }else{
        setpostprogress({ status: true , message:'Only jpg , jpeg , png , x-png and gif files are allowed', bgcolor:'red'})
        setpostdata( { ...postdata , imagetopost:{ ...postdata.imagetopost , img3: null } , imagetopreview: { ...postdata.imagetopreview , img3: initialpictures.img3 } } )
      }
    }  

    /////////////////
    //==================================



    // this function is used to show the preview of an image about to be uploaded 
    // or it can be called a function that converts a file to base 64


    const showpreview = (file,where) => {

        const currentfile = file 
        const reader = new FileReader()
        reader.addEventListener("load",()=>{
            if(where === 1){
                setpostdata( { ...postdata , imagetopost:{ ...postdata.imagetopost , img1: file } , imagetopreview: { ...postdata.imagetopreview , img1: reader.result } } )
            }
            if(where === 2){
              setpostdata( { ...postdata , imagetopost:{ ...postdata.imagetopost , img2: file } , imagetopreview: { ...postdata.imagetopreview , img2: reader.result } } )
            }
            if(where === 3){
              setpostdata( { ...postdata , imagetopost:{ ...postdata.imagetopost , img3: file } , imagetopreview: { ...postdata.imagetopreview , img3: reader.result } } )
            }
        },false)

        reader.readAsDataURL(currentfile)

    }

    ////////////////
    //===================================


    // logic to check if there is letter in the price

    const CheckforletterNumberHandler = (detail) => {

      const [ result ] = useVerifynum( detail )

      return result

    }

    /////
    //=================



      const postServiceHandler = () => {

        setpostprogress( {
          status: true,
          message: 'Please wait while your request is being sent',
          bgcolor:'orange'
        } )

        if( postdata.serviceName === '' ||
            postdata.serviceDescription === '' ||
            postdata.servicesPrice === '' ||
            Daystoprev.length === 0 || 
            postdata.country === '' ||
            postdata.state === '' ||
            postdata.Lga === '' ||
            postdata.address === '' ||
            postdata.longitude === '' ||
            postdata.latitude === '' ||
            postdata.account_name === '' ||
            postdata.account_number === '' ||
            postdata.bank_name === ''
            ){

                        setpostprogress( {
                          status: true,
                          message: 'All fileds must be filled and make sure you selected priod when you would be available ',
                          bgcolor:'red'
                        } )

        }else{

          if( !CheckforletterNumberHandler( postdata.servicesPrice ) || !CheckforletterNumberHandler( postdata.account_number ) ){
            setpostprogress( {
              status: true,
              message: 'Price and account number Should contain only Numbers ',
              bgcolor:'red'
            } )
          }else{
            const Datatosubmit = new FormData();

            Datatosubmit.append('service_name',postdata.serviceName)
            Datatosubmit.append('description',postdata.serviceDescription)
            Datatosubmit.append('price_per_hour',postdata.servicesPrice)
            Datatosubmit.append('bank_name',postdata.bank_name)
            Datatosubmit.append('account_name',postdata.account_name)
            Datatosubmit.append('account_number',postdata.account_number) 

            if( postdata.imagetopost.img1 ){
                Datatosubmit.append('service_img1',postdata.imagetopost.img1,postdata.imagetopost.img1.name)
            }

            if( postdata.imagetopost.img2 ){
                Datatosubmit.append('service_img2',postdata.imagetopost.img2,postdata.imagetopost.img2.name)
            }

            if( postdata.imagetopost.img3 ){
                Datatosubmit.append('service_img3',postdata.imagetopost.img3,postdata.imagetopost.img3.name)
            }


            for (let b = 0; b < Daystosend.length; b++) {
              
              var CurrentDay = Daystosend[b]

              if( CurrentDay.day === 'Monday' ){
                Datatosubmit.append( 'monday' , true )
                Datatosubmit.append( 'monday_available_hours1' , CurrentDay.opening_hour )
                Datatosubmit.append( 'monday_available_hours2' , CurrentDay.closing_hour )
              }

              if( CurrentDay.day === 'Tuesday' ){
                Datatosubmit.append( 'tuesday' , true )
                Datatosubmit.append( 'tuesday_available_hours1' , CurrentDay.opening_hour )
                Datatosubmit.append( 'tuesday_available_hours2' , CurrentDay.closing_hour )
              }

              if( CurrentDay.day === 'Wednesday' ){
                Datatosubmit.append( 'wednesday' , true )
                Datatosubmit.append( 'wednesday_available_hours1' , CurrentDay.opening_hour )
                Datatosubmit.append( 'wednesday_available_hours2' , CurrentDay.closing_hour )
              }

              if( CurrentDay.day === 'Thursday' ){
                Datatosubmit.append( 'thursday' , true )
                Datatosubmit.append( 'thursday_available_hours1' , CurrentDay.opening_hour )
                Datatosubmit.append( 'thursday_available_hours2' , CurrentDay.closing_hour )
              }

              if( CurrentDay.day === 'Friday' ){
                Datatosubmit.append( 'friday' , true )
                Datatosubmit.append( 'friday_available_hours1' , CurrentDay.opening_hour )
                Datatosubmit.append( 'friday_available_hours2' , CurrentDay.closing_hour )
              }

              if( CurrentDay.day === 'Saturday' ){
                Datatosubmit.append( 'saturday' , true )
                Datatosubmit.append( 'saturday_available_hours1' , CurrentDay.opening_hour )
                Datatosubmit.append( 'saturday_available_hours2' , CurrentDay.closing_hour )
              }

              if( CurrentDay.day === 'Sunday' ){
                Datatosubmit.append( 'sunday' , true )
                Datatosubmit.append( 'sunday_available_hours1' , CurrentDay.opening_hour )
                Datatosubmit.append( 'sunday_available_hours2' , CurrentDay.closing_hour )
              }

            }


            //posting to back end 

            ///

            Axios.patch( '/service/' + service_id + '/'  , Datatosubmit ).then(
              response => {

                    var AddressToPost = {
                      country:postdata.country,
                      state:postdata.state,
                      Lga:postdata.Lga,
                      address:postdata.address,
                      longitude:postdata.longitude,
                      latitude:postdata.latitude,
                    }

                  Axios.patch('/service/slocation/' + postdata.address_Id + '/' , AddressToPost ).then( 
                    response => {
                        setinitialpictures({
                          img1:response.data.service_img1,
                          img2:response.data.service_img2,
                          img3:response.data.service_img3
                        })
                        setpostprogress( {
                          status: true,
                          message: 'Your Service was successfully updated',
                          bgcolor:'rgb(39, 180, 39)'
                        } )
                      } 
                    ).catch( 
                      error => {
                        setpostprogress( {
                          status: true,
                          message: 'Your request was not successfully sent pls refresh the page and try again',
                          bgcolor:'red'
                        } )
                      }
                     )
              }
            ).catch(
              error => {
                setpostprogress( {
                  status: true,
                  message: 'Your request was not successfully sent pls refresh the page and try again',
                  bgcolor:'red'
                } )
              }
            )

            //=======================

          }

        }

      }

      const myPopup = (SearchInfo) => {

    
        return(
                    <Popup>
                        {/* <div> */}
                        <p 
    
                        style={{
                            fontWeight:'800'
                        }}
    
                        >{SearchInfo.info}</p>
                        {/* {/* <div>Latitude:{SearchInfo.latLng.lat}</div> */} 
                        {/* {/* <div>Longitude:{SearchInfo.latLng.lng}</div> */} 
    
                        <button className="Mappupop_btn" onClick={ 
                            () => setAllUserlocationdetails(SearchInfo)
                         } > Select Location </button>
                    </Popup>
        );
      }

      const setAllUserlocationdetails = (SearchInfo) => {
    
        setpostdata({
          ...postdata,
          mapstory:'Please wait , this might take some time...  '
        })
    
        setpostdata({
          ...postdata,
          latitude:SearchInfo.latLng.lat,
          longitude:SearchInfo.latLng.lng,
          mapstory:'Location was successfully saved..',
          maparea:SearchInfo.info
        })
    
        // setselldata({
        //   ...selldata,
        //   mapstory:'Search and select the closest place to your farm on the map',
        // })
    
        setopenMap(false)
      }

      return ( 

        <div className="Edit_service_page" >

        <Backdrop show={ openMap } />

        { openMap ? 
          <LeafletMapDiv 
          myPopup={ myPopup }
          story={ postdata.mapstory } 
            closeMap={ () => setopenMap(false) }
          />
          : null  }

        <Backdrop show={openaddtime} >
              <div className="add_service_Days" style={{ transform: openaddtime ? 'translateY(0rem)' : 'translateY(10rem)' }} >
                <div className="add_service_Days-top" >
                    <div className="add_service_Days-top-1" >
                        Add Working Hours
                    </div>
                    <Svg className="add_service_Days-top-2" href="sprite2.svg#icon-add" onClick={ closeAddtimeHandler } />
                </div>
                <div className="add_service_Days_Error" style={{ color: !addtimeerror ? '' : 'red' , display: addtimeerror ? true : 'false' }} > { addtimeerror ? addtimeerror : '' } </div>
                  <div className="add_service_Days_mid" >
                        <AddtimeComp
                          first_day={ availdate.day }
                          listofdays={printalldaysinaweek}
                          openlistofdays={ () => setdifftimelist( {...difftimelist,opendayslist:true} ) }
                          showListofDays={ difftimelist.opendayslist }
                          openingrange_first={ availdate.openingTrange }
                          openingrangeList={ printopeningrange }
                          open_am_pmHandler={ () => setdifftimelist({...difftimelist,openOpeniningAmpm:true}) }
                          openAm_Pm={ difftimelist.openOpeniningAmpm }
                          closingrange_first={availdate.closingTrange}
                          closeingrangeList={ printclosingrange }
                          close_am_pmHandler={ () => setdifftimelist({...difftimelist,openClosingAmpm:true}) }
                          closeAm_Pm={ difftimelist.openClosingAmpm }

                          OpeningTimeValue={ availdate.openingTime }
                          OpeningTimeOnchange={ (event) => setavaildate( {...availdate,openingTime:event.target.value} ) }
        
                          ClosingTimeValue={ availdate.closingTime }
                          ClosingTimeOnchange={ (event) => setavaildate( {...availdate,closingTime:event.target.value} ) }
                          />

                  </div>
                  <button className="add_service_Days_mid_add" onClick={ editdate ? editdateHandler : AddDayHandler } > { editdate ? 'Edit Time' : 'Add Time' } </button>

              </div>
        </Backdrop>

        <Topbanner
          show={ postprogress.status }
          backgroundcolor={ postprogress.bgcolor }
          message={ postprogress.message }
          closeshow={ () => setpostprogress({...postprogress,status:false}) }
            />

            <AddServices

             whichaction="Edit Service"

             servicesNamevalue={ postdata.serviceName }
             servicesNameonChange={ (event) => setpostdata( { ...postdata , serviceName: event.target.value } ) }

             servicesDescriptionvalue={ postdata.serviceDescription }
             servicesDescriptiononChange={ (event) => setpostdata( { ...postdata , serviceDescription: event.target.value } ) }

             servicePrice={ postdata.servicesPrice }
             servicePriceonChange={ (event) => setpostdata( { ...postdata , servicesPrice: event.target.value } ) }

             choosefirstimage={ choosefirstimageHandler }
             previewfirstimage={ postdata.imagetopreview.img1}

             choosesecondimage={ choosesecondimageHandler }
             previewsecondimage={ postdata.imagetopreview.img2 }

             choosethirdimage={ choosethirdimageHandler }
             previewthirdimage={ postdata.imagetopreview.img3 }

             availabledayslist={ mappingdaysTopreview }
             addtime={ Daystoprev.length === 7 ? null : setopenaddtime }


             buttonoption='Save Changes'
             postservice={postServiceHandler}
             
                    //Address part

                    countryvalue={ postdata.country }
                    countryonChange={ (event) => setpostdata({...postdata,country:event.target.value}) }
      
                    statevalue={ postdata.state }
                    stateonChange={ (event) => setpostdata({...postdata,state:event.target.value}) }
      
                    lgavalue={ postdata.Lga }
                    lgaonChange={ (event) => setpostdata({...postdata,Lga:event.target.value}) }
      
                    servaddressvalue={ postdata.address }
                    servaddressonChange={ (event) => setpostdata({...postdata,address:event.target.value}) }
      
                    //
      
                    //Map Longitude and latitude
      
                    latitudevalue={ postdata.latitude }
      
                    
                    longitudevalue={ postdata.longitude }

                    maplocationValue={ postdata.maparea }

                    Openmap={ () => setopenMap(true) }

                    accountnamevalue={ postdata.account_name }
                    accountnameonChange={ (event) => setpostdata({ ...postdata , account_name: event.target.value }) }

                    accountnumbervalue={ postdata.account_number }
                    accountnumberonChange={ (event) => setpostdata({ ...postdata , account_number: event.target.value }) }

                    banknamevalue={ postdata.bank_name }
                    banknameonChange={ (event) => setpostdata({ ...postdata , bank_name: event.target.value }) }


             />

        </div>

      );

}

export default EditServices;