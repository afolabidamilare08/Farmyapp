import React , { useEffect , useState, useContext } from 'react';
import BookingServ from '../../components/booking_service_component/booking_serv';
import Axios from 'axios';
import Store from '../../../store/managementstore/managementstore';
import Backdrop from '../../../component/utilities/Backdrop/backdrop';
import Availabledays from '../../components/fullservicedisplaycomp/available_days/availabledays';
import TopbannerDiv from '../../../component/utilities/top-banner-msg/topbannermsg';
import LeafletMapDiv from '../../../component/LeafletMap/LeafletMap';
import { Popup } from 'react-leaflet';
import Editprofile from '../../../component/user-profile-box/middle-div/profile-details/profile_details';
import { TermsandCondition , TermsandConditionListSOrder } from '../../../component/utilities/TermsAndCondition/termsandcondition';


const BookingservicePage = (props) => {

    const context = useContext(Store)

    const [ openeditprofilemodal , setopeneditprofilemodal ] = useState(false)

    const [ opentc , setopentc ] = useState(false)


    const [ serviceTObook , setserviceTObook ] = useState({
        serviceName:'',
        servicePrice:'',
        serviceId:'',
        serviceAvailabledays:[],
        gottenThedata:false,
        serviceSender:''
    })

    const [ Userdetails , setUserdetails ] = useState({
        first_name:'',
        last_name:'',
        email:'',
        phone_number:''
    })

    const [ openLeafletmap , setopenLeafletmap ] = useState(false)

    const [ selectedTimeRange , setselectedTimeRange ] = useState({
        day: null,
        openingNumber:null,
        openingRange:'am',
        closingNumber:null,
        closingRange:'am',
        duration:''
    })

    const [ UserlocationDetails , setUserlocationDetails ] = useState({
        country:'Nigeria',
        state:'',
        lga:'',
        address:'',
        longitude:'',
        latitude:'',
        mapArea:'',
        mapStory:' Search and select the closest place to your farm on the map '
    })


    const [ progressmessage , setprogressmessage ] = useState({
        status:false,
        msg:'',
        bgcolor:''
    })

    const [ ServiceDetail , setServiceDetail ] = useState(null)

    const [ openAlldays , setopenAlldays ] = useState(false)

    const [ Oprange , setOprange ] = useState(false)

    const [ Clrange , setClrange ] = useState(false)

    const [ 
        days ,
        //  setdays 
        ] = useState([null])

    const timeRange = [ 'am' , 'pm' ]

    const [ Daystobemaped , setDaystobemaped ] = useState([null])
    const [ wehavedays , setwehavedays ] = useState(false)



    useEffect( () => {

        Axios.get( '/service/' +  props.match.params.id + '/' ).then(
            response => {
                setserviceTObook( {
                    serviceName:response.data.service_name,
                    servicePrice:response.data.price_per_hour,
                    serviceAvailabledays:response.data.days,
                    serviceId: response.data.id ,
                    serviceSender: response.data.user.id ,
                    gottenThedata:true
                } )
                setServiceDetail(response.data)

            }
        ).catch()

    } , [props.match.params.id ] )

    useEffect( () => {
        setUserdetails( {
            ...context.User_details.detail,
            ...context.User_details.detail2
        } )
    } , [ context.User_details.detail , context.User_details.detail2 ] )   

    if( Daystobemaped[0] !== null   ){
        // setwehavedays(true)
        // setselectedTimeRange( { ...selectedTimeRange , day:Daystobemaped[0].day } )
        var alreadymap =  Daystobemaped.map( day => {
            return <div className="ad_information_hiring_form_time_3_li"
                         onClick={ () => chooseDayHandler(day.day) } > {day.day} </div>
        } )
    }

    if( Daystobemaped[0] !== null && !wehavedays  ){
        setselectedTimeRange( { ...selectedTimeRange , day:Daystobemaped[0].day } )
        // var alreadymap =  Daystobemaped.map( day => {
        //     return <div className="ad_information_hiring_form_time_3_li"
        //                  onClick={ () => chooseDayHandler(day.day) } > {day.day} </div>
        // } )
        setwehavedays(true)
    }

    const chooseDayHandler = (day) => {

        setselectedTimeRange({...selectedTimeRange , day: day})
        setopenAlldays(false)
    }

    const OPtimeRangeHandler = (timeRange) => {
        setselectedTimeRange({...selectedTimeRange,openingRange:timeRange})
        setOprange(false)
    }

    var mappingOpTrange = timeRange.map( timerange => {
        return <div className="ad_information_hiring_form_time_3_li"
                     onClick={ () => OPtimeRangeHandler(timerange) } > {timerange} </div>
    } )

    const CLtimeRangeHandler = (timeRange) => {
        setselectedTimeRange({...selectedTimeRange,closingRange:timeRange})
        setClrange(false)
    }

    var mappingCLTrange = timeRange.map( timerange => {
        return <div className="ad_information_hiring_form_time_3_li"
                     onClick={ () => CLtimeRangeHandler(timerange) } > {timerange} </div>
    } )



    // Logic to get all the available Days 

    const mapingofAvailabledays = () => {

        var newDaysArray = []
        
        if( ServiceDetail.monday ){
            newDaysArray.push( { day:'Monday' ,
                              available_hours1: ServiceDetail.monday_available_hours1 ,
                              available_hours2: ServiceDetail.monday_available_hours2  } )
        }

        if( ServiceDetail.tuesday ){
            newDaysArray.push( { day:'Tuesday' ,
                             available_hours1: ServiceDetail.tuesday_available_hours1 ,
                             available_hours2: ServiceDetail.tuesday_available_hours2  } )
        }

        if( ServiceDetail.wednesday ){
            newDaysArray.push( { day:'Wednesday' ,
                              available_hours1: ServiceDetail.wednesday_available_hours1 ,
                              available_hours2: ServiceDetail.wednesday_available_hours2  } )
        }

        if( ServiceDetail.thursday ){
            newDaysArray.push( { day:'Thursday' ,
                             available_hours1: ServiceDetail.thursday_available_hours1 ,
                             available_hours2: ServiceDetail.thursday_available_hours2  } )
        }

        if( ServiceDetail.friday ){
            newDaysArray.push( { day:'Friday' ,
                              available_hours1: ServiceDetail.friday_available_hours1 ,
                              available_hours2: ServiceDetail.friday_available_hours2  } )
        }

        if( ServiceDetail.saturday ){
            newDaysArray.push( { day:'Saturday' ,
                             available_hours1: ServiceDetail.saturday_available_hours1 ,
                             available_hours2: ServiceDetail.saturday_available_hours2  } )
        }

        if( ServiceDetail.sunday ){
            newDaysArray.push( { day:'Sunday' ,
                              available_hours1: ServiceDetail.sunday_available_hours1 ,
                              available_hours2: ServiceDetail.sunday_available_hours2  } )
        }

            var BestDaysArray = []

            for (let i = 0; i < newDaysArray.length; i++) {
                var dayY = newDaysArray[i]

                if( dayY.available_hours1 > 12 ){
                    var openingTrange = 'Pm'
                    var openingTime = dayY.available_hours1 - 12
                }else{
                    openingTrange = 'Am'
                    openingTime = dayY.available_hours1
                }

                if( dayY.available_hours2 > 12 ){
                    var closingTrange = 'Pm'
                    var closingTime = dayY.available_hours2 - 12
                }else{
                    closingTrange = 'Am'
                    closingTime = dayY.available_hours2
                }

                BestDaysArray.push( { day: dayY.day , openingTime: openingTime , openingTrange: openingTrange , closingTime: closingTime , closingTrange: closingTrange } )

            }
        
        setDaystobemaped(BestDaysArray)

    }

    ///////////////////////
    //=======================================





    // a logic to make sure that the user dose not input letters but only digit
    ////////////////////

    const accepteddigit = '1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 0'
    const accepteddigitarray = accepteddigit.split(',').map((item) => {return item.trim()} )

    
    const verifynum = (file,message) => {

      const currentfile = file

      for (let k = 0; k < currentfile.length; k++) {

        if( !accepteddigitarray.includes(currentfile[k]) ){

            setprogressmessage( { msg: message , status: true , bgcolor: 'red' } );
          return false

        }else{

          return true

        }

      }

    }


    /////////////////
    ////=============================


    const FirstCheck = () => {

        if( 
            Userdetails.first_name === '' ||
            Userdetails.last_name === '' ||
            Userdetails.email === '' ||
            Userdetails.phone_number === '' 
         ){
            setprogressmessage({
                status:true,
                msg:' All Filled In The Contact Details ',
                bgcolor:'red'
            })
         }else{

            OrderServiceHandler()

         }

    }




     const OrderServiceHandler = () => {


        setprogressmessage({
            status:true,
            msg:'Please wait while your request is being procced',
            bgcolor:'orange'
        })

        const error_number = ' Hire Duration Must Be Numeric '
        const error_open = ' Hire Duration Must Be Numeric '

        if( !selectedTimeRange.day  ||
            !selectedTimeRange.openingNumber  || 
             selectedTimeRange.duration === '' ||
             UserlocationDetails.address === '' ||
             UserlocationDetails.country === '' ||
             UserlocationDetails.latitude === '' ||
             UserlocationDetails.lga === '' ||
             UserlocationDetails.state === '' ||
             UserlocationDetails.longitude === '' ||
             UserlocationDetails.mapArea === '' 

            ){
                setprogressmessage({
                    status:true,
                    msg:'All Fields Must Be Filled  ',
                    bgcolor:'red'
                })
            }             //  

            
            if(
                selectedTimeRange.openingNumber  && 
                 selectedTimeRange.duration !== ''  &&
                UserlocationDetails.address !== '' &&
                UserlocationDetails.country !== '' &&
                UserlocationDetails.latitude !== '' &&
                UserlocationDetails.lga !== '' &&
                UserlocationDetails.state !== '' &&
                UserlocationDetails.longitude !== '' &&
                UserlocationDetails.mapArea !== '' &&
                verifynum(selectedTimeRange.duration,error_number) &&
                verifynum(selectedTimeRange.openingNumber,error_open)
            ){
            
                if( selectedTimeRange.openingRange === 'am' ){
            
                    if( selectedTimeRange.openingNumber === '12' ){
                        var openingHour = '0'
                    }else{
                        openingHour = selectedTimeRange.openingNumber
                    }
        
                }
        
                if( selectedTimeRange.openingRange === 'pm' ){
                    if( selectedTimeRange.openingNumber === '12' ){
                         openingHour = 12
                    }else{
                        openingHour = Number(selectedTimeRange.openingNumber) + 12
                    }
                }
        
                //////////////////////////////////
                ///=================================================

        
                if(selectedTimeRange.day){
                    var sDay = selectedTimeRange.day
                }else{
                    sDay = days[0]
                }
        
        
                var VariablesTopost = {
                    day:sDay,
                    duration:selectedTimeRange.duration,
                    prefered_time:openingHour + ':00',
                    country: UserlocationDetails.country ,
                    state: UserlocationDetails.state ,
                    lga: UserlocationDetails.lga ,
                    longitude: UserlocationDetails.longitude ,
                    latitude: UserlocationDetails.latitude ,
                    area: UserlocationDetails.mapArea,
                    address:UserlocationDetails.address,
                    service:serviceTObook.serviceId
                }    
        
        
                Axios.post( '/sorder/' , VariablesTopost ).then(
                    response => {
                        var id = response.data.id 
                        props.history.push('/finalServchk' + id )
                    }
                )
                }

    }

    /////////////////
    //================================

    const myPopup = (SearchInfo) => {

        return(
                    <Popup>
                        {/* <div> */}
                        <p 

                        style={{
                            fontWeight:'800'
                        }}

                        >{SearchInfo.info}</p>
                        {/* {/* <div>Latitude:{SearchInfo.latLng.lat}</div> */} 
                        {/* {/* <div>Longitude:{SearchInfo.latLng.lng}</div> */} 

                        <button className="Mappupop_btn" onClick={ 
                            () => setAllUserlocationdetails(SearchInfo)
                         } > Select Location </button>
                    </Popup>
        );
      }


    // Map Address issues

      const setAllUserlocationdetails = (SearchInfo) => {
        setUserlocationDetails({
            ...UserlocationDetails,
            latitude:SearchInfo.latLng.lat,
            longitude:SearchInfo.latLng.lng,
            mapStory:'Search and select the closest place to your farm on the map',
            mapArea:SearchInfo.info
        })
        setopenLeafletmap(false)

      }

    ////


    if( serviceTObook.gottenThedata && ServiceDetail &&  Daystobemaped[0] === null && wehavedays === false ){
        mapingofAvailabledays()
    }

      return ( 
          <>


        <Backdrop show={ opentc } >
            <TermsandCondition
                Agree={ FirstCheck }
                Cancel={ () => setopentc(false) }>
                    {TermsandConditionListSOrder}
            </TermsandCondition>
        </Backdrop>

          <TopbannerDiv
            backgroundcolor={ progressmessage.bgcolor }
            closeshow={ () => setprogressmessage({...progressmessage,status:false}) }
            show={ progressmessage.status }
            message={ progressmessage.msg }
            />

            <Backdrop show={openeditprofilemodal} >
                <div className="checkout-page-box-editprofile_top" >
                    <button className="checkout-page-box-editprofile_top_btn" onClick={ () => setopeneditprofilemodal(false) } >
                        Close Edit profile
                    </button>
                </div>
                <div style={{width:'100%',height:'80vh',overflowY:'auto'}} >
                <Editprofile/>
                </div>
            </Backdrop>

            <Backdrop
             show={openLeafletmap} />

            { openLeafletmap ? 
                    
            <LeafletMapDiv
            myPopup={ myPopup }
            story={ UserlocationDetails.mapStory }
            closeMap={ () => setopenLeafletmap(false) } 
            />
             
            :

            null

        }

          <div className="bookingservicepage-div">
              <TopbannerDiv
                message={progressmessage.msg}
                show={progressmessage.status}
                backgroundcolor={progressmessage.bgcolor}
                closeshow={ () => setprogressmessage({...progressmessage,status:false}) } />

            { ServiceDetail && Daystobemaped && context.User_details ? 
        
                    <BookingServ
                        
                    serviceName={ ServiceDetail.service_name }

                    servicePrice={ ServiceDetail.price_per_hour }

                    showListofDays={ openAlldays }

                    openlistofdays={ () => setopenAlldays(!openAlldays) }

                    listofdays={alreadymap}
                    
                    first_day={ Daystobemaped[0] !== null ? selectedTimeRange.day : '' }

                    openingrange_first={ selectedTimeRange.openingRange ? selectedTimeRange.openingRange : timeRange[0] }
                    openingrangeList={ mappingOpTrange }

                    closingrange_first={ selectedTimeRange.closingRange ? selectedTimeRange.closingRange : timeRange[0] }
                    closeingrangeList={mappingCLTrange}

                    openAm_Pm={ Oprange }
                    closeAm_Pm={ Clrange }

                    listOfAvailableDays={ 
                        wehavedays ? 

                            Daystobemaped.map( Avil => {
                                return <Availabledays
                                            day={Avil.day}
                                            openTime={Avil.openingTime}
                                            openRange={Avil.openingTrange}
                                            closeTime={Avil.closingTime}
                                            closeRange={Avil.closingTrange} />
                            } )  : null
                     }

                    open_am_pmHandler={ () => setOprange(!Oprange) }
                    close_am_pmHandler={ () => setClrange(!Clrange) }

                    OpeningTimeValue={ selectedTimeRange.openingNumber }
                    OpeningTimeOnchange={ (event) => setselectedTimeRange( {...selectedTimeRange , openingNumber: event.target.value} ) }
                    
                    ClosingTimeValue={ selectedTimeRange.closingNumber }
                    ClosingTimeOnchange={ (event) => setselectedTimeRange( {...selectedTimeRange , closingNumber: event.target.value } ) }

                    state={ ServiceDetail.address[0].state }

                    lga={ ServiceDetail.address[0].lga }

                    address={ ServiceDetail.address[0].address }

                    UserStateValue={ UserlocationDetails.state }
                    UserStateOnchange={ (event) => setUserlocationDetails({...UserlocationDetails,state:event.target.value}) }

                    UserLgaValue={ UserlocationDetails.lga }
                    UserLgaonChange={ (event) => setUserlocationDetails({...UserlocationDetails,lga:event.target.value}) }

                    UsercountryValue={ UserlocationDetails.country }

                    noofhoursValue={ selectedTimeRange.duration }
                    noofhoursOnchange={ (event) => setselectedTimeRange({...selectedTimeRange,duration:event.target.value}) }

                    UserAddressValue={ UserlocationDetails.address }
                    UserAddressonChange={(event) => setUserlocationDetails({...UserlocationDetails,address:event.target.value})}

                    NextToPdetails={ () => setopentc(true) }

                    openeditprofile={ () => setopeneditprofilemodal(true) }

                    first_name={ Userdetails ? Userdetails.first_name : '' }
                    last_name={ Userdetails ? Userdetails.last_name : '' }
                    email={ Userdetails ? Userdetails.email : '' }
                    phone_number={ Userdetails ? Userdetails.phone_number : ''}

                    maparea={ UserlocationDetails.mapArea }

                    Openmap = { () => setopenLeafletmap(true) }

                    />
        
                    : <Backdrop show={true} /> 
         
         }

          </div>

          </>
      );

}

export default BookingservicePage;