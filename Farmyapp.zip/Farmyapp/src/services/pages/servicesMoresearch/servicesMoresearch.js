import React , {useState,useEffect} from 'react';
import Producttemp from '../../../component/product_template/product_template';
import Backdrop from '../../../component/utilities/Backdrop/backdrop';
import { Link } from 'react-router-dom';
import Axios from 'axios';

const MoreSearchpage = (props) => {

    const chk = props.match.params.query
    const offset = props.match.params.offset

   const [ result , setresult ] = useState(null)

   useEffect( () => {

        Axios({
            method:'GET',
            url:'/service/',
            params:{ limit:24 , search: chk , offset:offset }
        }).then( 
            response => {
                setresult(response.data)
            }
         )

   } , [chk,offset] )


   if( result ){
       if( result.results.length !== 0 ){
           var allresult = result.results.map( service => {
               return <Producttemp
               img={service.service_img1}
               key={service.id}
               product={service.service_name}
               product_des={service.description}
               add_to_cart
               action='HIRE ME'
               price={service.price_per_hour}
               kg={'Hour'}
               to={'/fullserv' + service.slug + ":" + service.id } />
           } )

           
           var paglink = []

           for (let f = 0; f < (result.count/24) ; f++) {    
               paglink.push( { no: 1 + f  , limit: 24 , offset: 24 * f } )
           }

       }else{
           
       }
   }else{
       allresult = <Backdrop show={true} />
   }

      return ( 

        <>

        <div className="searchpage-box" >

            <div className="searchpage-box-msg" >
                Found { result ? result.count : '' } Results Related With "{ chk }" 
            </div>

            <div className="searchpage-box-result" >
                {allresult}
            </div>

            <div className="pagination_div" >
                { paglink ? 
                         
                         paglink.map( pag => {

                            if( pag.no === 1 ){
                                return <Link className="pagination_div_link" to={ '/search' + chk  } > 
                                    { pag.no }
                                </Link>
                            }else{
                                return <Link className="pagination_div_link" to={ '/moreservsearch' + chk + ':' + pag.offset } > 
                                { pag.no }
                            </Link>
                            }

                         } )

                      : null   }
                </div>

        </div>

        </>

      );

}

export default MoreSearchpage;