import React from 'react';
import Imgdisplay from '../../../component/Product-fullpage-components/product_and_info_box/product-image-box/product-image-box';
import Svg from '../../../component/utilities/Svg';

const FullservComp = (props) => {

      return ( 
          <div className="fullcompdiv-box" >


                <div className="fullcompdiv-box_1" >

                    <div className="fullcompdiv-box_1_top" >
                        <Imgdisplay
                         productimage1={props.mainimage}
                         openbigprev={props.openimgbigprev}
                         
                         control1={props.control1}
                         productimage0={props.productimage0} 
                         
                         control2={props.control2}
                         productimage2={props.productimage2}

                         control3={props.control3}
                         productimage3={props.productimage3}
                         />

                         <div className="fullcompdiv-box_1_top_head" >
                            <div className="fullcompdiv-box_1_top_head_name" > { props.serviceName } </div>
                            <div className="fullcompdiv-box_1_top_head_rate" style={{ marginTop:'1rem' , marginLeft:'.5rem' , display:'flex' , alignItems:'center' }}  >
                                {props.rating}
                                {props.ratenarate}
                            </div>
                            <div className="fullcompdiv-box_1_top_head_loc" > { props.lga } , { props.state } </div>
                         </div>

                    </div>

                    <div className="fullcompdiv-box_1_mid" >

                        <div className="fullcompdiv-box_1_mid_des" >
                            <div className="fullcompdiv-box_1_mid_des_top" >
                                Services Description
                            </div>
                            <div className="fullcompdiv-box_1_mid_des_mid" >
                                { props.serviceDescription }
                            </div>
                        </div>

                        <div className="fullcompdiv-box_1_mid_available" >
                            <div className="fullcompdiv-box_1_mid_des_top" > Time Available </div>
                            <div className="fullcompdiv-box_1_mid_available_mid" >
                                { props.listofAvailableDays }
                            </div>
                        </div>

                        <div className="fullcompdiv-box_1_mid_book" >
                             
                             <div className="fullcompdiv-box_1_mid_book_price" >
                                <span className="fullcompdiv-box_1_mid_book_price_1" > ₦{ props.serviceprice } </span>
                                <span className="fullcompdiv-box_1_mid_book_price_2" > per Hour </span>
                             </div>

                             <div className="fullcompdiv-box_1_mid_book_sbt" >
                                 <button className="fullcompdiv-box_1_mid_book_sbt_btn" onClick={props.hireservicebtn} >
                                 <Svg
                                      className="fullcompdiv-box_1_mid_book_sbt_btn_ic"
                                      href="sprite3.svg#icon-stopwatch" />
                                     Hire Me 
                                 </button>
                             </div>
                        </div>

                    </div>

                </div>


                <div className="fullcompdiv-box_2" >

                    <div className="fullcompdiv-box_2_safety" >
                        <div className="fullcompdiv-box_2_safety_top" > Service Address </div>

                        <div className="fullcompdiv-box_2_safety_div" >
                            <div className="fullcompdiv-box_2_safety_div_ic" >
                            <Svg
                              href="sprite3.svg#icon-location_onplaceroom"
                              className="fullcompdiv-box_2_safety_div_ic_ic"   />
                            </div>
                            <div className="fullcompdiv-box_2_safety_div_nat" >
                                { props.address }

                                <div style={{ marginTop:'1rem' }} >
                                     {props.lga} , {props.state}
                                </div>


                            </div>
                        </div>

                    </div>

                    <div className="fullcompdiv-box_2_safety" >
                        <div className="fullcompdiv-box_2_safety_top" > Working Hours </div>
                        <div className="fullcompdiv-box_2_safety_working" >
                            {props.workingHours}
                        </div>
                    </div>

                </div>

          </div>
      );

}

export default FullservComp;