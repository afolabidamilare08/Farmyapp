import React , { useState , useRef , useContext  } from 'react';
import Commentlist from '../../../../component/Product-fullpage-components/coment-div/comment-list/commentlist';
import CreateComment from '../../../../component/Product-fullpage-components/coment-div/compose-comment/compose-comment';
import Axios from 'axios';
import Backdrop from '../../../../component/utilities/Backdrop/backdrop';
import CommentReplyDiv from './reply-div/comment_reply';
import Store from '../../../../store/managementstore/managementstore';
import TopbannerDiv from '../../../../component/utilities/top-banner-msg/topbannermsg';


const Commentdiv = (props) => {

    const context = useContext(Store)

    const [ CommentstoMap , SetCommentstoMap ] = useState(null)
    const [ pagnumber , setpagnumber ] = useState(3)
    const [ postablecomment , setpostablecomment ] = useState('')
    const  [ commentprogress , Setcommentprogress ] = useState( { msg: '' , backgroundcolor: '' , status:false } )
    const [ openreplycommentmodal , setopenreplycommentmodal  ] = useState(false)
    const [ commenttoreply , setcommenttoreply ] = useState(null)


    const inputref = useRef();


    const openreplycommentmodalHandler = (comment_id) => {
        // inputref.current.focus()
        setopenreplycommentmodal(true)
        setcommenttoreply(comment_id)
    }



    const closereplycommentmodalHandler = () => {
        // inputref.current.focus()
        setopenreplycommentmodal(false)
    }



    const postablecommentonchangeHandler = (event) => {
        setpostablecomment(event.target.value)
    }

    // 
    const sendcommentHandler = () => {
        Setcommentprogress({msg:"Posting Comment ... ", status: true , backgroundcolor :'orange'})
        if( postablecomment === '' ){
            Setcommentprogress({msg:"You can't post an empty comment", status:true ,backgroundcolor:'red'})
        }else{

            var senddata = {comment:postablecomment}

            Axios.post( '/service/' + props.service_id + '/service_comment/' , senddata ).then(
                response => {
                    Axios.get( '/service/' + props.service_id + '/').then(
                        response => {
                          SetCommentstoMap(response.data.comments)
                          setpostablecomment('')
                          Setcommentprogress({msg:" Your comment about the product was posted successfully ", status:true , backgroundcolor:'rgb(39, 180, 39)'})
                        }
                      );
                }
            );

        }

    }


   // geting all comment after replying to comment 
   
   const getingallCommentagain = () => {
    Axios.get( '/service/' + props.service_id + '/' ).then(
        response => {
          SetCommentstoMap(response.data.comments)
          setpostablecomment('')
        }
      );
   } 
   
   ////////






    // putting the all comments in a state

    const setit = (info) => {
         SetCommentstoMap(info)
    }

    /////////////////



    // checking if the commetstoMap is empty 

    if( props.comment_list && CommentstoMap === null ){
        // console.log(props.comment_list)
        setit( props.comment_list )
    }

    // if comment to map is not empty procceding to mapping the state to list of comments to display

    if( CommentstoMap && pagnumber ){

        if( CommentstoMap.length > pagnumber ){
            var reduce = []

            for (let i = 0; i < pagnumber; i++) {
                reduce.push(CommentstoMap[i])
            }
        }else{
            reduce = [...CommentstoMap]  
        }

        var mappingit = reduce.map( ( rest ) => {
            return <Commentlist 
                    firstName={rest.user.first_name}
                    lastName={rest.user.last_name}
                    commentBody={rest.comment}
                    key={ rest.id }
                    profile_picture={rest.user.profile_picture}
                    time_since={rest.time_since}
                    reply={ !context.Token && !context.User_id && !context.user_cart ? props.notsignin : () => openreplycommentmodalHandler(rest) }
                    To={ '/user' + rest.user.id }
                    replies_list={ rest.replies ? 
                    rest.replies.map( replie => {
                       return <div className="CommentList-div-replies_list"  key={replie.id} >
                            <Commentlist
                               firstName={replie.user.first_name}
                               lastName={replie.user.last_name}
                               commentBody={replie.reply}
                               profile_picture={replie.user.profile_picture}
                               time_since={replie.time_since}
                               bg="lightgray" />
                        </div>
                    } ) : '' }
                    />
        } )


    }

    /////////////////////




      return ( 

        <>

        <TopbannerDiv
         show={ commentprogress.status }
         backgroundcolor={ commentprogress.backgroundcolor }
         message={ commentprogress.msg }
         closeshow={ () => Setcommentprogress( {...commentprogress , status: false } ) } />     

        <div className="comment-div-box" >

            <Backdrop show={openreplycommentmodal}>

                <CommentReplyDiv 
                    show={openreplycommentmodal}
                    closereplymodal={closereplycommentmodalHandler}
                    comment_to_reply={commenttoreply}
                    reload={ getingallCommentagain }
                     />

            </Backdrop>


            <div className="comment-div-box-top" >
                <div>
                    Comments
                </div>
                {/* <button className="comment-div-box-top_btn" onClick={ props.gotoallcommentHandler } >
                    see more
                </button> */}
            </div>

            <div className="comment-div-box-createcomment-div" >
                <CreateComment
                 inputValue={postablecomment}
                 inputOnchange={postablecommentonchangeHandler}
                 inputRef={inputref}
                 placeholder="Write a comment to find out more about the service"
                 first_name={ !context.User_details ? '' : context.User_details.detail.first_name }
                 last_name={ !context.User_details ? '' : context.User_details.detail.last_name }
                 profile_picture={ !context.User_details ? '' : context.User_details.detail.profile_picture }
                 postit={ !context.Token && !context.User_id && !context.user_cart ? props.notsignin : sendcommentHandler } />
            </div>

            <div className="comment-div-box-listOfcomment-div" >
                { CommentstoMap ? mappingit : '' }
            </div>

            { CommentstoMap ? 
                        <div className="comment-div-box-loadmore"  >
                            <button className="comment-div-box-loadmore_btn" style={{display: CommentstoMap.length < 3 || pagnumber >= CommentstoMap.length ? 'none' : 'block' }} onClick={ () => setpagnumber( pagnumber + 3 )} >
                                Load More Comments
                            </button>
                        </div>
                : '' }

        </div>

        </>

      );

}

export default Commentdiv;