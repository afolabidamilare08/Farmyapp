import React from 'react';

const Availabledays = (props) => {

      return ( 
          <div className="availabledays_toshow" >
              <div className="availabledays_toshow_day" > { props.day } : </div>
              <div className="availabledays_toshow_open" > { props.openTime + ' ' + props.openRange } </div>
              <div className="availabledays_toshow_open" > - </div>
              <div className="availabledays_toshow_open" > { props.closeTime + ' ' + props.closeRange } </div>
          </div>
      );

}

export default Availabledays;