import React , { useState } from 'react';

const CheckoutBtn = (props) => {

  const [ mid , showmid ] = useState(false)

      return ( 

        <div className="whole_chk" onClick={ () => showmid(!mid) } >

        <div className="checkout_btn"  >
            <div className="checkout_btn_mid" style={ { display: mid ? 'block' : 'none' } } >

            </div>
        </div>

        {/* <div className="checkout_name"  >
          { props.day }
        </div> */}

        {props.addit}

        </div>

      );

}

export default CheckoutBtn;