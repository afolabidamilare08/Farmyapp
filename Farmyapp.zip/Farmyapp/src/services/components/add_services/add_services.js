import React , { useState } from 'react';
import Pickimage from '../../../component/sellpage_template/pickimage/pickimage';
import { OrdinaryTextInput, OrdinaryTextArea, OrdinaryPriceandSale , Toggletitle } from '../../../component/sellpage_template/sell_temp/sell_.temp';

const AddServices = (props) => { 

    const [ showServiceInfo , setshowServiceInfo ] = useState(true)
    const [ showServiceAddress , setshowServiceAddress ] = useState(false)
    const [ Accountdetails , setAccountdetails ] = useState(false)


      return ( 

        <div className="sell-template-div" >

                <div className="sell-template-div_top" >
                    {props.whichaction}
                </div>

                <Toggletitle
                     title="Service Information"
                     position={showServiceInfo}
                     toggleposition={ () => setshowServiceInfo(!showServiceInfo) } />

                <div className="sell-template-div-middle" >
                    
                    <div className="sell-template-div-middle-product" style={{
                        display: showServiceInfo ? 'block' : 'none'
                    }} >

                        <OrdinaryTextInput
                         label="Service Name"
                         value={props.servicesNamevalue}
                         onChange={props.servicesNameonChange}
                         />

                         <OrdinaryTextArea
                            label="Service Description"
                            value={props.servicesDescriptionvalue}
                            onChange={props.servicesDescriptiononChange}
                         />

                        <OrdinaryPriceandSale
                        pricevalue={props.servicePrice}
                        priceonChange={props.servicePriceonChange}
                        scalevalue="Hour"
                        scaleonChange={props.productscaleonChange}
                        disable
                        />

                         <div className="services_days" >

                            <div className="sell-template-div-middle-product-gallery-top" >
                                Add Working days
                                <div className="sell-template-div-middle-product-gallery-top_info" >
                                    You are to add the days you would be available for hire.
                                    <br/>
                                    
                                </div>
                            </div>
                         </div>
                         
                         <div className="services_days_list" >
                            {props.availabledayslist}
                         </div>

                         <div className="services_days_add" >
                            <button className="services_days_add_btn" style={{ display: props.addtime ? 'block' : 'none' }} onClick={ props.addtime } > Add Time </button>
                         </div>


                        <div className="sell-template-div-middle-product-gallery" >

                        <div className="sell-template-div-middle-product-gallery-top" >
                                Add Photo 
                                <div className="sell-template-div-middle-product-gallery-top_info" >
                                    You are Expected to add pictures related to the service you want to post. ,
                                    <br/>
                                    Supported image formats are *jpg* , *jpeg* , and *png*
                                </div>
                            </div>
                            
                            <Pickimage
                             story={props.story1}
                             error={props.error1}
                             choseimage={props.choosefirstimage}
                             preview={props.previewfirstimage} />
                            <Pickimage
                             story={props.story2}
                             error={props.error2}
                             choseimage={props.choosesecondimage}
                             preview={props.previewsecondimage} />
                            <Pickimage
                             story={props.story3}
                             error={props.error3}
                             choseimage={props.choosethirdimage}
                             preview={props.previewthirdimage} />
                        </div>

                    </div>

                    <Toggletitle
                     title="Address Information"
                     position={showServiceAddress}
                     toggleposition={ () => setshowServiceAddress(!showServiceAddress) } />

                    <div className="sell-template-div-middle-seller" style={{
                        display: showServiceAddress ? 'block' : 'none'
                    }} >

                        <OrdinaryTextInput
                         label="Country"
                         disable
                         value={props.countryvalue}
                         onChange={props.countryonChange}
                         />

                        <OrdinaryTextInput
                         label="State"
                         value={props.statevalue}
                         onChange={props.stateonChange}
                         />

                        <OrdinaryTextInput
                         label="Local Government Area"
                         value={props.lgavalue}
                         onChange={props.lgaonChange}
                         />

                        <OrdinaryTextArea
                         label="Service Location"
                         value={props.servaddressvalue}
                         onChange={props.servaddressonChange} 
                         />

                        <div className="SellMap-div" >
                            <div className="SellMap-div_nar" >
                                Please Select the location of your service or a location close to your service on the map 
                            </div>
                        </div>

                        <OrdinaryTextInput
                         label="Map Location"
                         disable
                         value={props.maplocationValue}
                         onChange={props.maplocationonChange} />
{/* 
                        <OrdinaryTextInput
                         label="Latitude"
                         disable
                         value={props.latitudevalue}
                         onChange={props.latitudeonChange} /> */}

                            <div className="SellMap-div_sbt" >
                                <button className="SellMap-div_sbt-btn" onClick={ props.Openmap } >
                                    Open Map
                                </button>
                            </div>

                    </div>

                    <Toggletitle
                     title="Account Information"
                     position={Accountdetails}
                     toggleposition={ () => setAccountdetails(!Accountdetails) } />

                    <div className="sell-template-div-middle-seller" style={{
                        display: Accountdetails ? 'block' : 'none'
                    }} >

                        <OrdinaryTextInput
                         label="Account Name"
                         value={props.accountnamevalue}
                         onChange={props.accountnameonChange}
                         />

                        <OrdinaryTextInput
                         label="Account Number"
                         value={props.accountnumbervalue}
                         onChange={props.accountnumberonChange}
                         />

                        <OrdinaryTextInput
                         label="Bank Name"
                         value={props.banknamevalue}
                         onChange={props.banknameonChange}
                         />

                         </div>

                </div>

                <div className="sell-template-div-bottom" >

                    <button className="sell-template-div-bottom-btn" disabled={props.btnDisable} onClick={props.postservice} >
                        { props.buttonoption }
                    </button>
                </div>

          </div>


      );

}

export default AddServices;