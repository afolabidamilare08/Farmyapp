import React from 'react';

const AdInput = (props) => {

      if(props.textarea){
            return ( 
                <div className="ad_Iinput_form_div"  >
                    <label className="ad_Iinput_form_div-label" > {props.labelName} </label>
                        <textarea type="text" value={props.value} onChange={ props.onChange } disabled={props.disabled} className="ad_Iinput_form_div-textarea" >
                        </textarea>
                </div> 
            ); 
      }

      if(props.price){
          return ( 
                <div className="ad_Iinput_form_div"  >
                    <label className="ad_Iinput_form_div-label" > {props.labelName} </label>
                    <div className="ad_Iinput_form_div-price" >
                        <div className="ad_Iinput_form_div-price-1" >₦</div>
                        <input type="text" value={props.value} onChange={ props.onChange } disabled={props.disabled} className="ad_Iinput_form_div-price-2" />
                    </div>
                </div> 
          );
      }

      if( props.text ){ 
          return (
                <div className="ad_Iinput_form_div"  >
                    <label className="ad_Iinput_form_div-label" > {props.labelName} </label>
                    <input type="text" value={props.value} onChange={ props.onChange } disabled={props.disabled} className="ad_Iinput_form_div-input" />
                </div> 
          );
      }

}

export default AdInput;