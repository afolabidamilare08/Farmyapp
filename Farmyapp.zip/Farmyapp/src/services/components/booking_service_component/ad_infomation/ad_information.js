import React, { useState } from 'react';
import AdInput from '../ad_input/ad_input';
import {AddtimeComp2} from '../addtime_date';
import { Link } from 'react-router-dom';
import { Toggletitle } from '../../../../component/sellpage_template/sell_temp/sell_.temp';

const AdInformation = (props) => {

            const [ showServiceInformation , setshowServiceInformation ] = useState(false)
            const [ showuserAddress , setshowuserAddress ] = useState(false)
            const [ showinformation , setshowinformation ] = useState(true)


      return ( 
          <div className="ad_information" >

            <Toggletitle
                title='My Contact Details'
                position={ showinformation }
                toggleposition={ () => setshowinformation(!showinformation) }
            />

                <div className="ad_information_form" style={{
                    display: showinformation ? 'block' : 'none',
                    marginBottom:'4rem'
                }} >

                
                    <AdInput
                     value={props.first_name}
                     disabled={true}
                     text={true}
                     labelName="First Name"
                    />

                    <AdInput
                     value={props.last_name}
                     disabled={true}
                     text={true}
                     labelName="Last Name"
                    />

                    <AdInput
                     value={props.email}
                     disabled={true}
                     text={true}
                     labelName="Email"
                    />

                    <AdInput
                     value={props.phone_number}
                     disabled={true}
                     text={true}
                     labelName="Phone Number"
                    />

                    <div className="paymentfirststep-div-bottom" >
                        <div className="paymentfirststep-div-bottom-left" >
                            Note : if your details are not correct <Link className="paymentfirststep-div-bottom-left-click" to="#" onClick={ props.openeditprofile } >click here</Link> to change it in your profile
                        </div>
                    </div> 
                    
                </div>

                <Toggletitle
                title='Service Information'
                position={ showServiceInformation }
                toggleposition={ () => setshowServiceInformation(!showServiceInformation) }
            />

                <div className="ad_information_form" style={{
                    display: showServiceInformation ? 'block' : 'none'
                }} >

                    <AdInput
                     value={props.serviceName}
                     disabled={true}
                     text={true}
                     labelName="Service Name"
                    />

                    <AdInput
                     value={new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(props.servicePrice)}
                     disabled={true}
                     price={true}
                     labelName="Service price per hour"
                    />

                    <div className='ad_information_available' >
                        <div className='ad_information_available_top' > Time Available </div>    
                        <div className='ad_information_available_mid' >
                            { props.listOfAvailableDays }
                        </div>
                    </div>

                    <div className="ad_information_hiring" >
                        <div className="ad_information_hiring_top" >
                            Hire duration 
                        </div>
                        <AddtimeComp2
                                first_day={props.first_day}
                                openlistofdays={props.openlistofdays}
                                showListofDays={props.showListofDays}
                                listofdays={props.listofdays}
                                openingrange_first={props.openingrange_first}
                                openingrangeList={props.openingrangeList}
                                open_am_pmHandler={props.open_am_pmHandler}
                                openAm_Pm={props.openAm_Pm}
                                OpeningTimeValue={props.OpeningTimeValue}
                                OpeningTimeOnchange={props.OpeningTimeOnchange}
                                noofhoursValue={ props.noofhoursValue }
                                noofhoursOnchange={ props.noofhoursOnchange }
                          />
                    </div>

                </div>

                <div style={{marginTop:'4rem'}} ></div>

                <Toggletitle
                    title='Work Location'
                    position={ showuserAddress }
                    toggleposition={ () => setshowuserAddress(!showuserAddress) }
                />

                <div className="ad_information_form" style={{
                    display: showuserAddress ? 'block' : 'none'
                }}  >

                 <div style={{
                    //  marginLeft:'-1rem',
                     fontSize:'1.5rem',
                     fontWeight:'600',
                     marginTop:'3rem'
                 }} >
                     Please fill the Work Destination Location
                 </div>

                 <AdInput
                     value={props.UsercountryValue}
                     onChange={props.UsercountryOnchange}
                     disabled
                     text={true}
                     labelName="Country"
                    />

                    <AdInput
                     value={props.UserStateValue}
                     onChange={props.UserStateOnchange}
                     text={true}
                     labelName="State"
                    />

                    <AdInput
                     value={props.UserLgaValue}
                     onChange={props.UserLgaonChange}
                     text={true}
                     labelName="Local Government Address"
                    />

                    <AdInput
                     value={props.UserAddressValue}
                     onChange={props.UserAddressonChange}
                     textarea={true}
                     labelName="Address"
                    />


                </div>

                <div className="ad_information_form" style={{
                    display: showuserAddress ? 'block' : 'none'
                }}   >

                    <div style={{
                    //  marginLeft:'-1rem',
                        fontSize:'1.5rem',
                        fontWeight:'600',
                        marginTop:'6rem'
                    }} >
                         Select the location of the Work Destination Location or a location close to the Work Destination Location on the map
                    </div>

                    <AdInput
                        value={props.maparea}
                        onChange={props.mapareaonChange}
                        text={true}
                        disabled={true}
                        labelName="Map Area"
                    />


                    <button className="ad_information_open_map" onClick={ props.Openmap } >
                        Open Map
                    </button>

                    </div>

                <div className="ad_information_sbt" >
                         <button className="ad_information_sbt_btn" onClick={ props.NextToPdetails } > Proceed To CheckOut </button>
                    </div>

          </div>
      );

}

export default AdInformation;