import React from 'react';
import AdInformation from './ad_infomation/ad_information';

const BookingServ = (props) => {

      return ( 
          <div className="booking_serv-div" >
                <div className="booking_serv-div-top" > Hiring Service </div>
                    <AdInformation
                    serviceName={props.serviceName}
                    serviceLocation={props.serviceLocation}
                    servicePrice={props.servicePrice}
                    showListofDays={props.showListofDays}
                    openlistofdays={props.openlistofdays}
                    listofdays={props.listofdays}
                    first_day={props.first_day}
                    openingrange_first={props.openingrange_first}
                    openingrangeList={props.openingrangeList}
                    listOfAvailableDays={props.listOfAvailableDays}
                    openAm_Pm={ props.openAm_Pm }
                    proceedtoprofile={props.proceedtoprofile}
                    open_am_pmHandler={props.open_am_pmHandler}
                    noofhoursOnchange={ props.noofhoursOnchange }
                    noofhoursValue={ props.noofhoursValue }
                    OpeningTimeValue={props.OpeningTimeValue}
                    OpeningTimeOnchange={props.OpeningTimeOnchange}
                    state={props.state}
                    lga={props.lga}
                    address={props.address}

                    UserStateValue={props.UserStateValue}
                    UserStateOnchange={props.UserStateOnchange}

                    UserLgaValue={props.UserLgaValue}
                    UserLgaonChange={props.UserLgaonChange}

                    UserAddressValue={props.UserAddressValue}
                    UserAddressonChange={props.UserAddressonChange}

                    UsercountryValue={props.UsercountryValue}
                    UsercountryonChange={ props.UsercountryonChange }

                    maparea={ props.maparea }

                    Openmap={props.Openmap}

                    NextToPdetails={props.NextToPdetails}

                    openeditprofile={ props.openeditprofile }

                    first_name={ props.first_name }
                    last_name={ props.last_name }
                    email={ props.email }
                    phone_number={ props.phone_number }

                    />
          </div>
      );

}

export default BookingServ;