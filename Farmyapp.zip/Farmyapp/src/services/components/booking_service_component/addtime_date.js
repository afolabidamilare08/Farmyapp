import React from 'react';
import Svg from '../../../component/utilities/Svg';

export const AddtimeComp = (props) => {

      return ( 
        <div className="ad_information_hiring_form" >

        <div className="ad_information_hiring_form_day" >
            <label className="ad_information_hiring_form_day-label" > day </label>
            <button className="ad_information_hiring_form_day-button" onClick={ props.openlistofdays } > 
                {props.first_day} 
                <Svg
                 href="contact.svg#icon-triangle-down"
                 className="ad_information_hiring_form_day-button-ic" /> 
            </button>
            <div className="ad_information_hiring_form_day-hide" style={{
                display: props.showListofDays ? 'block' : 'none'
            }} >
                { props.listofdays }
            </div>
        </div>

        <div className="ad_information_hiring_form_time" >
            <label className="ad_information_hiring_form_time_label" >opening hour</label>
            <div className="ad_information_hiring_form_time_2" >
                <input type='text' className="ad_information_hiring_form_time_2_input" placeholder="0" value={props.OpeningTimeValue} onChange={props.OpeningTimeOnchange} />
                <button className="ad_information_hiring_form_day-button" onClick={ props.open_am_pmHandler } > 
                    {props.openingrange_first}
                    <Svg
                        href="contact.svg#icon-triangle-down"
                        className="ad_information_hiring_form_day-button-ic" /> 
                </button>
            </div>
            <div className="ad_information_hiring_form_time_3" style={{ display: props.openAm_Pm ? 'block' : 'none' }} >
                {props.openingrangeList}
            </div>
        </div>

        <div className="ad_information_hiring_form_time" >
            <label className="ad_information_hiring_form_time_label" >closing hour</label>
            <div className="ad_information_hiring_form_time_2" >
                <input type='text' className="ad_information_hiring_form_time_2_input" placeholder="0" value={props.ClosingTimeValue} onChange={props.ClosingTimeOnchange} />
                <button className="ad_information_hiring_form_day-button" onClick={props.close_am_pmHandler} > 
                  {props.closingrange_first}
                    <Svg
                        href="contact.svg#icon-triangle-down"
                        className="ad_information_hiring_form_day-button-ic" /> 
                </button>
            </div>
            <div className="ad_information_hiring_form_time_3"  style={{ display: props.closeAm_Pm ? 'block' : 'none' }} >
                {props.closeingrangeList}
            </div>
        </div>

    </div>
      );

}















export const AddtimeComp2 = (props) => {

    return ( 
      <div className="ad_information_hiring_form" style={{
          display:'flex',
          justifyContent:'space-evenly'
      }} >

      <div className="ad_information_hiring_form_day" >
          <label className="ad_information_hiring_form_day-label" > day </label>
          <button className="ad_information_hiring_form_day-button" onClick={ props.openlistofdays } > 
              {props.first_day} 
              <Svg
               href="contact.svg#icon-triangle-down"
               className="ad_information_hiring_form_day-button-ic" /> 
          </button>
          <div className="ad_information_hiring_form_day-hide" style={{
              display: props.showListofDays ? 'block' : 'none'
          }} >
              { props.listofdays }
          </div>
      </div>
-
      <div className="ad_information_hiring_form_time" >
          <label className="ad_information_hiring_form_time_label" >opening hour</label>
          <div className="ad_information_hiring_form_time_2" >
              <input type='text' className="ad_information_hiring_form_time_2_input" placeholder="0" value={props.OpeningTimeValue} onChange={props.OpeningTimeOnchange} />
              <button className="ad_information_hiring_form_day-button" onClick={ props.open_am_pmHandler } > 
                  {props.openingrange_first}
                  <Svg
                      href="contact.svg#icon-triangle-down"
                      className="ad_information_hiring_form_day-button-ic" /> 
              </button>
          </div>
          <div className="ad_information_hiring_form_time_3" style={{ display: props.openAm_Pm ? 'block' : 'none' }} >
              {props.openingrangeList}
          </div>
      </div>

      -

      <div className="ad_information_hiring_form_time" >
          <label className="ad_information_hiring_form_time_label" >Hours</label>
          <div className="ad_information_hiring_form_time_2" >
                <input type='text' style={{ textAlign:'center' }} className="ad_information_hiring_form_time_2_input" placeholder="0" value={props.noofhoursValue} onChange={props.noofhoursOnchange} />
          </div>
      </div>

  </div>
    );

}



