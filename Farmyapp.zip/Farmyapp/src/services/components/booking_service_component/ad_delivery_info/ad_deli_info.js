import React from 'react';

const AddeliInfo = (props) => {

      return ( 
          <div className="" >
                ceeveveve
          </div>
      );

}

export default AddeliInfo;