import React from 'react';
import Header from '../../layout/header/header';

const ServicesHeader = (props) => {

      return ( 

        <Header
         services={true}
         changequery={props.changequery}
         searchquery={props.searchquery}
         whereonChange={ props.whereonChange }
         wherevalue={ props.wherevalue }
         search={props.search}
         placeholder=" What Service are you looking for ... ? "
         towhere='/' />

      );

}

export default ServicesHeader;