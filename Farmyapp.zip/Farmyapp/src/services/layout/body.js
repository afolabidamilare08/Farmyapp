import React from 'react';
import {Route,Switch} from 'react-router-dom';
import Servhomepage from '../pages/servhomepage/servhomepage';
import AddservPage from '../pages/Addservpage/addservpage';
import Loginpage from '../../pages/login-page/loginpage';
import FullServicepage from '../pages/fullservicedetailpage/fullservicepage';
import Servicesearch from '../pages/searchpage/searchpage';
import Axios from 'axios';
import BookingservicePage from '../pages/booking_service/booking_service';
import EditServices from '../pages/edit_Services/edit_services';
import MoreServices from '../pages/moreServices/moreservices';
import FinalchkServ from '../pages/finalservchk/finalservchk';

const ServicesBody = (props) => {

    // const 

    if( Axios.defaults.headers.common['Authorization'] ){
        var avilLinks =
        <Switch>
            <Route path="/services" exact component={Servhomepage} />
            <Route path="/services_add_service" exact  component={AddservPage} />
            <Route path="/fullserv:slug::id" exact component={FullServicepage} />
            <Route path="/servsearch:query::address::offset" exact component={Servicesearch} />
            <Route path="/bookservice:slug::id" exact component={BookingservicePage} />
            <Route path="/editservice:slug::id" exact component={EditServices} />
            <Route path="/moreserv:offset" exact component={MoreServices} />
            <Route path="/finalServchk:id" exact component={FinalchkServ}  />
            <Route path="/servsearch:query::offset" exact component={Servicesearch}  />
        </Switch>
    }else{
      avilLinks =
      <Switch>
          <Route path="/services" exact component={Servhomepage} />
          <Route path="/services_add_service" exact component={Loginpage} />
          <Route path="/servsearch:query::address::offset" exact component={Servicesearch} />
          <Route path="/fullserv:slug::id" exact component={FullServicepage} />
          <Route path="/bookservice:slug::id" exact component={Loginpage} />
          <Route path="/editservice:slug::id" exact component={Loginpage} />
          <Route path="/moreserv:offset" exact component={MoreServices} />
          <Route path="/finalServchk:id" exact component={Loginpage}  />
          <Route path="/servsearch:query::offset" exact component={Servicesearch}  />
      </Switch>
    }

      return (

        <>

        {avilLinks}

        </>

      );

}

export default ServicesBody;
