import React , {useState} from 'react';
import ServicesHeader from './header';
import ServicesBody from './body';
import Footerdiv from '../../layout/footer/footer';

const ServLayout = (props) => {

  const [ searchquery , setsearchquery ] = useState('');
  const [ wherequery , setwherequery ] = useState('');

  const changequery = (event) => {
      setsearchquery(event.target.value)
  }   

  const senddata = (e) => {
      e.preventDefault()

      if( searchquery !== '' ){
            if( searchquery === '' ){
                props.history.push('/servsearch' + searchquery + ':' + 0 )

            }else{
                props.history.push('/servsearch' + searchquery + ':' + wherequery + ':' + 0 )
            }
      }else{ 
          props.history.push('#')
      }
  }

      return ( 

        <>
            <ServicesHeader
              searchquery={searchquery}
              changequery={changequery}
              whereonChange={ (event) => setwherequery( event.target.value ) }
              wherevalue={ wherequery }
              search={senddata}
            />

            <ServicesBody/>
            <Footerdiv/>
        </>

      );

}

export default ServLayout;