import React from 'react';


 export  default React.createContext({
        notificationsLists:null,
        clearNotification: () => {} ,
        addNotification: () => {},
        gobackFunc: () => {}
    })


    

