import React from 'react';


 export  default React.createContext({
    
        Token: null,
        User_id : null,
        User_details:null,
        profile_slide:false,
        User_cart_id:null,
        profile_id:null,
        profile_page_slide:false,
        User_det:null,
        user_cart:{},
        add_product_slide:false, 
        home_products: {},
        add_to_homeproductsHandler: () => {} ,
        close_add_product_slideHandler: () => {},
        open_add_product_slideHandler: () => {},
        add_to_userdetails: () => {},
        close_profile_slide : () => {},
        open_profile_slide : () => {}, 
        close_profile_page_slideHandler : () => {},
        open_profile_page_slideHandler : () => {}, 
        Loginhandler : () => {},
        Logouthandler : () => {},
        add_userdetailsHandler : () => {},
        updatecartHandler: () => {},
        change_item_quantityHandler: () => {},
        remove_from_cartHandler: () => {},
        FoodCart:null,
        updatefoodcartHandler: () => {},
        FoodCartUpdateRemove: () => {},
    })


    

