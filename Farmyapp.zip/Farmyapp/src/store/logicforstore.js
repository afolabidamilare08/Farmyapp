import React,{Component} from 'react';
import '../css/main.css';
import {BrowserRouter} from 'react-router-dom';
import Store from './managementstore/managementstore';
import Axios from 'axios';


class LogicStore extends Component {

  state = {
    Token:null,
    User_id:null,
    User_details: null,
    User_cart_id: '',
    profile_id: null,
    profile_slide:false,
    profile_details:null,
    profile_page_slide:false,
    add_product_slide:false,
    home_products:{
      products:null,
      limit:0,
      offset:0,
      next:true
    },
    cart:null,
    some:1,
    FoodCart:null
  }













  close_add_product_slide = () => {
    this.setState({add_product_slide:false})
  }

  open_add_product_slide = () => {
    this.setState({add_product_slide:true})
  }

  close_profile_slide = () => {
    this.setState({profile_slide:false})
  }

  open_profile_slide = () => {
    this.setState({profile_slide:true})
  }

  addprofile_details = ( first , second ) => {
    var join = {first , second}
    this.setState({profile_details:join})
  }

  close_profile_page_slide = () => {
    this.setState({profile_page_slide:false})
  }

  add_to_homeproducts = (data) => {
    this.setState({products:data.products,limit:data.limt,offset:data.offset,next:data.next})
  }


  open_profile_page_slide = () => {
    this.setState({profile_page_slide:true})
  }









  GetFoodCartDetails = () => {

    Axios.get('/mycarts/mycart/').then(

      response => {

        if( response.data.results.length > 0 ){
          this.setState({FoodCart:response.data.results[0]})
        }else{
          this.AddnewCartjare()
        }

      }

    ).catch()

  }


  AddnewCartjare = () => {

    Axios.post('/mycarts/mycart/',{user:localStorage.getItem('farmyapp-userid')}).then(

      response => {
        this.setState({FoodCart:response.data})
      }

    ).catch()

  }


  UptodateFoodCartDetails = (CartDetails) => {

        this.setState({FoodCart:CartDetails})

  }








  updatecart = ( Fullcart ) => {
    this.setState({cart:Fullcart})

    var usernumid = localStorage.getItem('farmyapp-userid')

    //////////getting user details on refreshh or on new load

        Axios.get('/account/users/' + usernumid + '/' ).then(
          response => {
              const detail = response.data
              Axios.get('/account/userpro/' + usernumid + '/' ).then(
                  response => {
                      const detail2 = response.data.pro
                      this.setState({User_details:{ detail , detail2 }})
                      this.setState({User_cart_id:detail.carts[0].id})
                      this.setState({cart:detail.carts[0]})
                  }
              )
          }
      )

    //////////////////

  }


  add_to_userdetailsHandler = ( detail,detail2 ) => {
    this.setState({User_details:{detail,detail2}})
  }





  setitwell = (profileid) => {

    this.setState({profile_id:11})

  }












  componentDidMount(){
    // && localStorage.getItem('farmyapp-usercartid')
    if(localStorage.getItem('farmyapp-tok') && localStorage.getItem('farmyapp-userid')  ){
      this.setState({Token:localStorage.getItem('farmyapp-tok')})
      this.setState({User_id:localStorage.getItem('farmyapp-userid')})
      this.setState({User_cart_id:localStorage.getItem('farmyapp-usercartid')})
      Axios.defaults.headers.common['Authorization'] = 'Token ' +localStorage.getItem('farmyapp-tok');

      var usernumid = localStorage.getItem('farmyapp-userid')

      ////////getting user details on refreshh or on new load

          Axios.get('/account/users/' + usernumid + '/' ).then(
            response => {
                const detail = response.data
                this.GetFoodCartDetails()
                Axios.get('account/userpro/' + usernumid + '/' ).then(
                    response => {
                        const detail2 = response.data
                        this.setState({User_details:{ detail , detail2 }})
                        this.setitwell()
                    }
                )
            }
        )

      //////////////////

    }
    if(!localStorage.getItem('farmyapp-tok') || !localStorage.getItem('farmyapp-userid') ){
      this.setState({Token:null})
      this.setState({User_id:null})
      this.setState({profile_id:null})
      // Axios.defaults.headers.common['Authorization'] = 'Token';
    }

  }



  Logout= () => {
    this.setState({Token:false})
    this.setState({User_id:false})
    this.setState({profile_id:false})
    this.setState({cart:false})
    this.setState({User_details:false})
    this.setState({User_cart_id:false})
    this.setState({FoodCart:null})
    localStorage.removeItem('farmyapp-tok')
    localStorage.removeItem('farmyapp-userid')
    localStorage.removeItem('farmyapp-usercartid')
    Axios.defaults.headers.common['Authorization'] = '' ;
  }


  Login = (Token,User_id) => {
    this.setState({Token: Token,User_id:User_id})
    this.setState({Token:Token})
    this.setState({User_id:User_id})

      Axios.defaults.headers.common['Authorization'] = 'Token '+ Token;

          //////////getting user details on refreshh or on new load

          Axios.get('/account/users/' + User_id + '/' ).then(
            response => {
                const detail = response.data
                this.GetFoodCartDetails()
                Axios.get('/account/userpro/' + User_id + '/' ).then(
                    response => {
                        const detail2 = response.data.pro
                        this.setState({User_details:{ detail , detail2 }})
                        this.setState({User_cart_id:detail.carts[0].id})
                        this.setState({cart:detail.carts[0]})
                        this.setState({profile_id:detail2.id})
                        localStorage.setItem('farmyapp-usercartid',detail.carts[0].id)
                    }
                )
            }
        )

      //////////////////
  }

  render() {

    // console.log(this.props)

    setTimeout(() => {
      this.setState({...this.state, some: 3})
    }, 11010000);

        return (
          <BrowserRouter>
            {/* <ScrollMemory/> */}
              <Store.Provider

              value={{
                User_details:this.state.User_details,
                Token:this.state.Token,
                User_id:this.state.User_id,
                profile_id:this.state.profile_id,
                User_det:this.state.profile_details,
                User_cart_id:this.state.User_cart_id,
                user_cart:this.state.cart,
                Logouthandler:this.Logout,
                Loginhandler:this.Login,
                home_products:this.state.home_products,
                add_to_homeproductsHandler:this.add_to_homeproducts,
                add_to_userdetails: this.add_to_userdetailsHandler ,
                add_product_slide:this.state.add_product_slide,
                close_add_product_slideHandler:this.close_add_product_slide,
                open_add_product_slideHandler:this.open_add_product_slide,
                profile_slide:this.state.profile_slide,
                profile_page_slide:this.state.profile_page_slide,
                close_profile_slide:this.close_profile_slide,
                open_profile_slide:this.open_profile_slide,
                add_userdetailsHandler:this.addprofile_details,
                updatecartHandler:this.updatecart,
                remove_from_cartHandler:this.remove_from_cart ,
                change_item_quantityHandler:this.change_item_quantity,
                close_profile_page_slideHandler:this.close_profile_page_slide,
                open_profile_page_slideHandler:this.open_profile_page_slide,
                FoodCart:this.state.FoodCart,
                updatefoodcartHandler:this.UptodateFoodCartDetails,
                FoodCartUpdateRemove: this.GetFoodCartDetails
              }}

              >

                { this.props.children }
                  
              </Store.Provider>
          </BrowserRouter>
        );

 }

}


export default LogicStore;