import React from 'react';
import Userprofilediv from '../../component/user-profile-box/user_profile_box';
import Userprofilebottom from '../../component/user-profile-box/bottom_div/bottom_div';

const Userprofilepage = (props) => {

      return ( 
          <> 
            <Userprofilediv/>
            {/* <Userprofilebottom/> */}
          </>
      );

}

export default Userprofilepage;