import React , {useState,useEffect,useContext} from 'react';
import { CopyToClipboard } from "react-copy-to-clipboard";
import {GiWallet} from 'react-icons/gi';
import TopbannerDiv from '../../component/utilities/top-banner-msg/topbannermsg';
import Store from '../../store/managementstore/managementstore';
import Axios from 'axios';
import ProfileHeader from '../../foods/layout_components/profile_header/profile_header';
import LoadingPage from '../../foods/components/loading/loading';
import OppsPage from '../../foods/components/oppspage/oppspage';
// import DownloadLink from "react-download-link";
// import Fam from './fam.apk'

const Referal_page = (props) => {

    const context = useContext(Store)
    const [ Loadingpage , setLoadingpage ] = useState(false)
    const [ Errorpage , setErrorpage ] = useState(false)
    const [ wallet_balance , setwallet_balance ] = useState(false)


    const [ ReferalDetails , setReferalDetails ] = useState({
        ReferalLink:'',
        ReferalAccountDetails:{
            AccountNumber:'',
            AccountName:'',
            BankName:''
        },
        id:'',
        ReferalFriends:[],
        Status:false
    })

    const [ ReferalList , setReferalList ] = useState({
        list:[],
        status:false
    })

    const [ OriginalAccount , setOriginalAccount ] = useState({
        AccountNumber:'',
        AccountName:'',
        BankName:''
    })

    const [ CopyToClipboardState , setCopyToClipboardState ] = useState({
        status:false,
        message:'Referal Link Has Been Copied To Clipboard',
        bgColor:'rgba(13, 194, 94, 0.986)',
        btn:false
    })




    useEffect( () => {

        setLoadingpage(true)
        setErrorpage(false)

        if ( context.User_id !== null ) {
            getdataHandler()
            console.log(context.User_details)
        }

    } , [
        context.User_id 
    ] )



    const getdataHandler = () => {

        Axios.get( '/account/accountno/' ).then(
            response => {
                setReferalList({
                    list:[...response.data.results],
                    status:true
                })
                getIncomedetails()
            }
        ).catch(
            e => {
                setLoadingpage(false)
                setErrorpage(true)
            }
        );

    }


    const getIncomedetails = () => {

        Axios.get('account/income/?limit=100000&offset=0').then(

            response => {

                var res = response.data.results
                var accum_income = 0

                for (let r = 0; r < res.length ; r++) {

                    if ( res[r].profile === parseInt(context.User_id) ) {
                        accum_income = parseInt(accum_income) + parseInt(res[r].amount)
                    }

                }

                Axios.get('account/payment/?limit=100000&offset=0').then(

                    response => {

                        var debt = response.data.results
                        var accum_debt = 0
        
                        for (let r = 0; r < debt.length ; r++) {
        
                            if ( debt[r].profile === parseInt(context.User_id) ) {
                                accum_debt = parseInt(accum_debt) + parseInt(debt[r].amount)
                            }
        
                        }

                        var wallet_balanced = accum_income - accum_debt
                        setwallet_balance(wallet_balanced)
                        setLoadingpage(false)
                        setErrorpage(false)

                    }

                ).catch(
                    e => {
                        setLoadingpage(false)
                        setErrorpage(true)
                    }
                )

            }

        ).catch(
            e => {
                setLoadingpage(false)
                setErrorpage(true)
            }
        )

    }











    const CopyingToClipboard = () => {
        setCopyToClipboardState({ ...CopyToClipboardState , message:'Referal Link Has Been Copied To Clipboard', status:true , bgColor:'rgba(13, 194, 94, 0.986)' })
    }




    const Setitfast = () => {
        setReferalDetails({
            ReferalLink:RefLink,
            ReferalAccountDetails:{
                AccountNumber:'',
                AccountName:'',
                BankName:''
            },
            ReferalFriends:[],
            Status:true
        })
    }



    if( ReferalList.status && !ReferalDetails.Status  ){

        if (ReferalList.list.length > 0 ) {
            var workArray = [...ReferalList.list]

            var RefLink = ''
            

            for (let f = 0; f < workArray.length; f++) {
                if( Number(workArray[f].user) === Number(context.User_id) ){

                    setReferalDetails({
                        ReferalLink:RefLink,
                        ReferalAccountDetails:{
                            AccountNumber:workArray[f].account_number,
                            AccountName:workArray[f].account_name,
                            BankName:workArray[f].bank_name
                        },
                        id:workArray[f].id,
                        ReferalFriends:[],
                        Status:true
                    })

                    setOriginalAccount({
                        AccountNumber:workArray[f].account_number,
                        AccountName:workArray[f].account_name,
                        BankName:workArray[f].bank_name
                    })
                    break

                }else{

                    if ( f === workArray.length - 1 && Number(workArray[f].user) !== Number(context.User_id) ) {
                        Setitfast()
                    }

                }
            }



        }else{
            Setitfast()
        }
        
    }else{
        
    }



    const SendAccountDetails = () => {

        setCopyToClipboardState({ ...CopyToClipboardState , message:'Saving Account Details', status:true , bgColor:'orange' , btn:true })
        
        if( ReferalDetails.ReferalAccountDetails.AccountName !== '' && ReferalDetails.ReferalAccountDetails.AccountNumber !== '' && ReferalDetails.ReferalAccountDetails.BankName !== '' ){

            var SendData = {
                account_name:ReferalDetails.ReferalAccountDetails.AccountName,
                account_number:Number(ReferalDetails.ReferalAccountDetails.AccountNumber),
                bank_name:ReferalDetails.ReferalAccountDetails.BankName,
                user:Number(context.User_id)
            }

            // if( verifynum(ReferalDetails.ReferalAccountDetails.AccountNumber) ){

            if( OriginalAccount.AccountName === '' && OriginalAccount.AccountNumber === '' ){
                Axios.post('/account/accountno/' , SendData ).then(
                    response => {
                        setOriginalAccount({
                            AccountName:ReferalDetails.ReferalAccountDetails.AccountName,
                            AccountNumber:ReferalDetails.ReferalAccountDetails.AccountNumber,
                            BankName:ReferalDetails.ReferalAccountDetails.BankName
                        })
                        setCopyToClipboardState({ ...CopyToClipboardState , message:'Your Account Details Was Successfully Saved', status:true , bgColor:'rgba(13, 194, 94, 0.986)' , btn:false })
                    }
                )
            }else{
                Axios.patch('/account/accountno/' + ReferalDetails.id + '/' , SendData ).then(
                    response => {
                        setOriginalAccount({
                            AccountName:ReferalDetails.ReferalAccountDetails.AccountName,
                            AccountNumber:ReferalDetails.ReferalAccountDetails.AccountNumber,
                            BankName:ReferalDetails.ReferalAccountDetails.BankName
                        })
                        setCopyToClipboardState({ ...CopyToClipboardState , message:'Your Account Details Was Successfully Saved', status:true , bgColor:'rgba(13, 194, 94, 0.986)' , btn:false })
                    }
                )
            }
            
            // setOriginalAccount({
            //     AccountName:ReferalDetails.ReferalAccountDetails.AccountName,
            //     AccountNumber:ReferalDetails.ReferalAccountDetails.AccountNumber,
            //     BankName:ReferalDetails.ReferalAccountDetails.BankName
            // })

            // }else{
            //     setCopyToClipboardState({ ...CopyToClipboardState , message:'Invalid Account Number', status:true , bgColor:'red' })
            // }
    
        }else{
            setCopyToClipboardState({ ...CopyToClipboardState , message:'Fill All Account Details', status:true , bgColor:'red', btn:false })
        }

    }

    if(
        OriginalAccount.AccountName !== '' &&
        OriginalAccount.AccountNumber !== '' &&
        OriginalAccount.BankName !== '' 
    ){

        var Action = CopyingToClipboard

    }else{
        Action = null
    }






      const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }
    
    
      if( Loadingpage && !ReferalDetails.Status && !Errorpage ){
        var yapipi = <LoadingPage/>
      }else{
        if ( !Loadingpage && Errorpage && !ReferalDetails.Status ) {
          yapipi = <OppsPage tryagain={gogo} goback={goBack} />
        }else{

        }
      }


      if ( ReferalDetails.Status ) {

        if ( wallet_balance ) {
            if ( wallet_balance < 0 ) {
                var wal = 0
            }else{
                wal = wallet_balance
            }
        }

        var nations = 
        
        <div className="referal_page_div" >
              
              <div className="referal_page_div_title" > 
                  My Referrals
              </div>

              <div className="referal_page_div_top" >

                  <div className="referal_page_div_top_second" >
                      <GiWallet 
                          className="referal_page_div_top_second_ic"
                      />
                      <div className="referal_page_div_top_second_1txt" >
                        ₦ { wal }
                      </div>
                      <div className="referal_page_div_top_second_2txt" >
                          Wallet Balance
                      </div>
                  </div>
 
                  <div className="referal_page_div_top_first" >
                      <div className="referal_page_div_top_first_title" >
                          Referral Link
                      </div>
                      <div className="referal_page_div_top_first_main" >
                          <input disabled={true} type="text" className="referal_page_div_top_first_main_input" value={ context.User_id ? 'https://www.farmyapp.com/refer_user' + context.User_id : '' } />
                          <CopyToClipboard text={ context.User_id ? 'https://www.farmyapp.com/refer_user' + context.User_id : '' }
                              onCopy={ ReferalDetails.Status ? Action : '' }>
                              <button onClick={CopyingToClipboard} className="referal_page_div_top_first_main_btn" >Copy referal link to clipboard </button>
                          </CopyToClipboard>
                      </div>
                  </div>

              </div>

              <div className="referal_page_div_terms" >
                  <div className="referal_page_div_terms_top" >
                      Referral Terms And Conditions
                  </div>
                  <div className="referal_page_div_terms_mid" >
                   <ul className="referal_page_div_terms_mid_ul" >
                          <li className="referal_page_div_terms_mid_ul_li" >
                                  Conduct referrals to the company of farmers and agricultural producers by sharing the 
                                  personal account referral link in order to get them registered on the company platform
                              </li>
                              <li className="referal_page_div_terms_mid_ul_li" >
                                  Create enlightenment and teach such above referred farmers and agricultural personnel the
                                  process of performing transactions on the company platform and ascertain that agricultural 
                                  personnel will have no hitches while using the platform.
                              </li>
                              <li className="referal_page_div_terms_mid_ul_li" >
                                  Provide step by step guidelines for the already referred individual on processes to increase 
                                  their farm productivity cum income producing value on the platform
                              </li>
                              <li className="referal_page_div_terms_mid_ul_li" >
                                  Cannot inflate any prices and original process of farm products from the farmers. 
                                  All cost prices which the farmer intends to sell, hire, render or buy a product or service on the 
                                  company platform will remain at farm price. 
                              </li>
                              <li className="referal_page_div_terms_mid_ul_li" >
                                  Cannot use the partner’s personal account for referred individuals or groups personal transactions 
                                  unless explicitly agreed upon by such individual or group.
                              </li>
                              <li className="referal_page_div_terms_mid_ul_li" >
                                  Will not own multiple accounts on the company platform and will manage all multiple tasks with the partner’s single account.
                              </li>
                          </ul>
                  </div>
              </div>

              <div className="referal_page_div_account" >
                  <div className="referal_page_div_account_top" >
                      Referral Account Details 
                  </div>
                  <div className="referal_page_div_account_mid" >

                      <div className="referal_page_div_account_mid_div" >
                          <input type="text" className="referal_page_div_account_mid_div_input" value={ ReferalDetails.ReferalAccountDetails.AccountName } 
                            onChange={ (event) => setReferalDetails({
                                ...ReferalDetails,
                                ReferalAccountDetails:{
                                    ...ReferalDetails.ReferalAccountDetails,
                                    AccountName:event.target.value
                                }
                            }) }   />
                          <label className="referal_page_div_account_mid_div_label" > Account Name </label>
                      </div>


                      <div className="referal_page_div_account_mid_div" >
                          <input type="text" className="referal_page_div_account_mid_div_input" value={ ReferalDetails.ReferalAccountDetails.AccountNumber }
                              onChange={ (event) => setReferalDetails({
                              ...ReferalDetails,
                                  ReferalAccountDetails:{
                                      ...ReferalDetails.ReferalAccountDetails,
                                      AccountNumber:event.target.value
                                  }
                                  })}
                          />
                          <label className="referal_page_div_account_mid_div_label" > Account Number </label>
                      </div>


                      <div className="referal_page_div_account_mid_div" >
                          <input type="text" className="referal_page_div_account_mid_div_input" value={ ReferalDetails.ReferalAccountDetails.BankName } 
                              onChange={ (event) => setReferalDetails({
                                  ...ReferalDetails,
                                      ReferalAccountDetails:{
                                          ...ReferalDetails.ReferalAccountDetails,
                                          BankName:event.target.value
                                      }
                                      })}                                
                          />
                          <label className="referal_page_div_account_mid_div_label" > Bank Name </label>
                      </div>


                      <button onClick={ SendAccountDetails } disabled={CopyToClipboardState.btn} className="referal_page_div_account_mid_btn" >
                          Save Account Details
                      </button>
                  </div>
              </div>
{/* 
              <div className="referal_page_div_mid" >
                  <div className="referal_page_div_mid_top" >
                      Your Friends
                  </div>
                  <div className="referal_page_div_mid_mid" >


                  </div>
              </div> */}

        </div>
      
    }





      return ( 

        <>


        <TopbannerDiv
            show={ CopyToClipboardState.status }
            message={ CopyToClipboardState.message }
            closeshow={ 
                () => setCopyToClipboardState({
                    ...CopyToClipboardState,status:false
                })
             }
            backgroundcolor={ CopyToClipboardState.bgColor }
        />

            <ProfileHeader
                title='Referrals'
                goback={ () => props.history.goBack() }
            />


             {yapipi}
             {nations}


          </>

      );

}

export default Referal_page;