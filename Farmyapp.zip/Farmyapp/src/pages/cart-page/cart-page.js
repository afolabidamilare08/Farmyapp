import React from 'react';
import Cartdiv from '../../component/cart-components/cart';
import Footerdiv from '../../layout/footer/footer';

const CartPage = (props) => {

  const Goto = () => {
    props.history.push('/checkout')
  }

      return (

        <>
        <div className="cartpage-box" >
            <Cartdiv gotofront={ Goto } />
        </div>

        <Footerdiv/>

        </>

      );

}

export default CartPage;
