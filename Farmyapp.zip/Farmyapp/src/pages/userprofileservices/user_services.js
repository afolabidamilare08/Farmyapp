import React, { useEffect, useContext, useState } from 'react';
import Store from '../../store/managementstore/managementstore';
import Axios from 'axios';
import Loading from '../../component/utilities/loading/loading';
import { ServicesMiniTemp } from '../../component/mini_product-template/mini_product_template';
import ConfirmationMsg from '../../component/utilities/confirmation_Msg/confirmation_msg';
import { Link } from 'react-router-dom';
import Hand from './hand.png';
import ProfileHeader from '../../foods/layout_components/profile_header/profile_header';
import LoadingPage from '../../foods/components/loading/loading';
import OppsPage from '../../foods/components/oppspage/oppspage';

const UserservicesPage = (props) => {

    const context = useContext( Store )

    const [ deleteServ , setdeleteServ ] = useState({
        status:false,
        msg:'',
        service_id:null,
        loading:false
    })

    const [ myservices , setmyservices ] = useState(null)
    const [ Loadingpage , setLoadingpage ] = useState(false)
    const [ Errorpage , setErrorpage ] = useState(false)

    useEffect( () => {

        setLoadingpage(true)
        setErrorpage(false)

        Axios.get( '/account/users/' + context.User_id + '/' ).then( 
            response => {
                setmyservices( response.data )
                setLoadingpage(false)
                setErrorpage(false)
            }
         ).then(
             e => {
                setLoadingpage(false)
                setErrorpage(true)
             }
         )

    } , [context.User_details,context.User_id] )






















    const DeleteService = () => {
        
        if(deleteServ.service_id){
            setdeleteServ({...deleteServ,loading:true})
            var productId = deleteServ.service_id

            Axios.delete( '/service/' + productId + '/' ).then(
                response => {
                    Axios.get( '/account/users/' + context.User_id + '/' ).then( 
                        response => {
                            setmyservices( response.data )
                            setdeleteServ({...deleteServ,loading:false,status:false,service_id:null})
                        }
                     )
                }
            )
        }

    }

    if( myservices ){

        if( myservices.services.length > 0 ){

            var mappedIt = myservices.services.map( product => {
                
                var Date_Created = []

                for (let k = 0; k < product.created.length ; k++) {
                    if( product.created[k] === 'T' ){
                        break
                    }else{
                        Date_Created.push(product.created[k])
                    }
                }



                return  <ServicesMiniTemp
                            service_img = {"https://farmyapp.xyz" + product.service_img1}
                            serviceName={product.service_name}
                            description={product.description}
                            date_created={Date_Created} 
                            Thires={ product.sorderes.length } 
                            service_price={product.price_per_hour}
                            edit={'/editservice' + product.slug + ':' + product.id}
                            delete={() => setdeleteServ({ 
                                msg:'Are you sure you want to delete this service ? ',
                                status:true,
                                service_id:product.id
                             }) }
                            />
            } )

        }

        if( myservices.services.length === 0 ){
            mappedIt = <div className="UserservicesPage-div_page_empty" >
                            <img src={Hand} alt="" className="UserservicesPage-div_page_empty_img" />
                            <div className="UserservicesPage-div_page_empty_text" > You don't have a service currently for hire  </div>
                            <Link to="/sell" className="UserservicesPage-div_page_empty_btn">
                                Post a service
                            </Link>
                        </div>
        }

    }






    const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }
    
    
      if( Loadingpage && !myservices && !Errorpage ){
        var powerouse = <LoadingPage/>
      }else{
        if ( !Loadingpage && Errorpage && !myservices ) {
          powerouse = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
          if (  myservices ) {
            powerouse = <div className="UserservicesPage-div_page" >

                            <div className="UserservicesPage-div_page_top" >
                                My Services
                            </div>
                            <div className="UserservicesPage-div_page_mid" >

                            { myservices ?
                            
                                mappedIt
                                        
                            
                            : <Loading/> }

                            </div>
                        </div>
          }
        }
      }






      return ( 

         <>

         <ConfirmationMsg
           show={deleteServ.status}
           msg={deleteServ.msg}
           decline={ () => setdeleteServ({...deleteServ,status:false,service_id:null}) }
           confirm={ DeleteService }
           isloading={deleteServ.loading} />


            <ProfileHeader
              title="My Services"
              goback={ goBack }
            />

          { powerouse}

        </>

      );

}

export default UserservicesPage;