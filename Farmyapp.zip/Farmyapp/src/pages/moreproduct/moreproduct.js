import React , { useState , useEffect } from 'react';
import HomeSlider from '../../component/home-slider/home-slider';
import Product from '../../component/product_template/product_template';
import {Link} from 'react-router-dom';
import Footer from '../../layout/footer/footer';
import Axios from 'axios';

const MoreProduct = (props) => {


    var offset = props.match.params.offset

    var limit = props.match.params.limit

    const [ maindata , setmaindata ] = useState(  )

    useEffect( () => {
        Axios({
            method:'GET',
            url:'/product/',
            params:{ limit: limit , offset:offset }
        }).then(
            response => {
                setmaindata(response.data)
                // console.log(response)
            }
        );
        // eslint-disable-next-line
    } , [ limit , offset ] )



    // console.log(props.match.params,'home')

    //checking if maindata do exit in other to aviod infinite loop and also to display the content with mapping
    //////////////////////////////////////////

    if( maindata ){
     var display =   maindata.results.map( ( product , index) => {
     
            return <Product
            img={product.product_img1}
            product={product.product_name}
            key={product.product_name}
            product_des={product.description}
            add_to_cart
            lga={product.address[0].lga}
            state={product.address[0].state}    
            action="Add To Cart"
            price={product.price}
            kg={product.measurement_scale}
                to={'/product' + product.slug + ":" + product.id } />
        
        }

        )

        var paglink = []

        for (let f = 0; f < (maindata.count/24) ; f++) {
            paglink.push( { no: 1 + f  , limit: 24 , offset: 24 * f } )
        }

        // console.log(paglink)

    }



    ///////////////////////////////////////////
    //====


      return (

        <div className="home-page" >

           {/* <div className="sticky-sell-btn" >
                <Link to="/sell" className="sticky-sell-btn-link" >
                    <Svg
                     className="sticky-sell-btn-link-ic"
                     href="sprite3.svg#icon-store_mall_directorystore" />
                    Sell
                </Link>
            </div> */}

            <HomeSlider/>

                <div className="home-products-div" >
                        {display}
                </div>

                <div className="pagination_div" >
                { maindata ? 
                         
                         paglink.map( pag => {

                             if( pag.no === 1 ){
                                 return <Link className="pagination_div_link" to={ '/'} > 
                                     { pag.no }
                                 </Link>
                             }else{
                                 return <Link className="pagination_div_link" to={ '/more' + pag.limit + ':' + pag.offset } > 
                                 { pag.no }
                             </Link>
                             }

                         } )

                      : null   }
                </div>

             <Footer/>

          </div>

      );

}

export default MoreProduct;
