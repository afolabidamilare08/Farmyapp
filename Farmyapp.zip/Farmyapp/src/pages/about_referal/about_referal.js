import React , {useEffect} from 'react';
import Logo from '../../layout/header/logo/logo';
import { Link } from 'react-router-dom';
import Pic from './5867.jpg';
import Pic2 from './317.jpg'
import Pic3 from './howto.jpg'
import Footer from '../../layout/footer/footer';
import Aos from 'aos';
import 'aos/dist/aos.css';

const AboutReferal = (props) => {

    useEffect( () => {
        Aos.init({duration:2000})
    } , [] )

      return ( 

        <>

          <div className="aboutreferal_div" >

                {/* <div className="aboutreferal_div_header" >

                    <Logo towhere={'/'} />

                </div> */}
              
                <div className="aboutreferal_div_top" >

                    <Logo towhere={'/'} />

                    <div className="aboutreferal_div_top_narate" >
                        Refer the farmers around you to FarmyApp and get 16.67% of our profit from the farmer's first 30 
                        transactions . Same thing applies to buyers. 
                    </div>
                    <Link to="/my_referrals" className="aboutreferal_div_top_btn" >
                        Start Refering
                    </Link>
                    
                </div>

                <div className="aboutreferal_div_benefit" >

                    <div className="aboutreferal_div_benefit_top" >
                        Benefits
                    </div>

                    <div className="aboutreferal_div_benefit_div" data-aos="fade-up" data-aos-once={true} >

                        <div className="aboutreferal_div_benefit_div_1" >
                            <img alt="" src={Pic} className="aboutreferal_div_benefit_div_1_img" />
                        </div>

                        <div className="aboutreferal_div_benefit_div_2" >

                            <ul className="aboutreferal_div_benefit_div_1_ul" >
                                <li className="aboutreferal_div_benefit_div_1_ul_li" >A 0.5% cost price dividends upon referral and initial 
                                    transaction of an agricultural merchant and client will be delivered to the partner. 
                                    And upon the thirtieth transaction of the above referred agricultural merchant and client, such 0.5% referral 
                                    dividend will be revoked by the executive ownership, proprietorship and management
                                    of the above-named company. In an instance when such referrals of agriculturally based products
                                    merchant and client ultimately, do not yield any profitable income-based transactions, the partner
                                    will not be liable to referral dividend benefit and the referral will hence, be revoked. 
                                    After 365 days of such ultimately unprofitable cum non income producing referral of the said 
                                    merchant, the partner will not be liable to the 0.5% cost price referral dividend and will hence be revoked by the company.
                                </li>
                                <li className="aboutreferal_div_benefit_div_1_ul_li" >
                                	A 1% ownership and shareholding capacity will be awarded to the above-named partner upon referral of up to one
                                    million farmers and agricultural producers and translates to one hundred billion naira “a buy in opportunity 
                                    in the company” this opportunity is not transferable upon non-attainment of the marketing feat by the partner. 
                                    And only transferable after the partner has attained.
                                </li>
                                <li className="aboutreferal_div_benefit_div_1_ul_li" >
                                	Make data for research purposes only available to collaborators on this project for an efficient and sustainable
                                    agricultural practice. The above name organization should also be sited in every publication where the data for 
                                    analysis is made available via the platform.
                                </li>
                            </ul> 

                            <Link to="/my_referrals" className="aboutreferal_div_top_btn" >
                                Start Refering
                            </Link>

                        </div>

                    </div>

                </div>

                

                <div className="aboutreferal_div_benefit" >

                    <div className="aboutreferal_div_benefit_top" >
                        Terms And Conditions
                    </div>

                    <div className="aboutreferal_div_benefit_div" data-aos="fade-up" data-aos-once={true} >

                        <div className="aboutreferal_div_benefit_div_2" >

                            <ul className="aboutreferal_div_benefit_div_1_ul" >
                                <li className="aboutreferal_div_benefit_div_1_ul_li" >
                                    Conduct referrals to the company of farmers and agricultural producers by sharing the 
                                    personal account referral link in order to get them registered on the company platform
                                </li>
                                <li className="aboutreferal_div_benefit_div_1_ul_li" >
                                	Create enlightenment and teach such above referred farmers and agricultural personnel the
                                    process of performing transactions on the company platform and ascertain that agricultural 
                                    personnel will have no hitches while using the platform.
                                </li>
                                <li className="aboutreferal_div_benefit_div_1_ul_li" >
                                	Provide step by step guidelines for the already referred individual on processes to increase 
                                    their farm productivity cum income producing value on the platform
                                </li>
                                <li className="aboutreferal_div_benefit_div_1_ul_li" >
                                    Cannot inflate any prices and original process of farm products from the farmers. 
                                    All cost prices which the farmer intends to sell, hire, render or buy a product or service on the 
                                    company platform will remain at farm price. 
                                </li>
                                <li className="aboutreferal_div_benefit_div_1_ul_li" >
                                	Cannot use the partner’s personal account for referred individuals or groups personal transactions 
                                    unless explicitly agreed upon by such individual or group.
                                </li>
                                <li className="aboutreferal_div_benefit_div_1_ul_li" >
                                	Will not own multiple accounts on the company platform and will manage all multiple tasks with the partner’s single account.
                                </li>
                            </ul>

                            <Link to="/my_referrals" className="aboutreferal_div_top_btn" >
                                Start Refering
                            </Link>

                        </div>

                        <div className="aboutreferal_div_benefit_div_1" >
                            <img alt="" src={Pic2} className="aboutreferal_div_benefit_div_1_img" />
                        </div>

                    </div>

                </div>


                <div className="aboutreferal_div_benefit" >

                    <div className="aboutreferal_div_benefit_top" >
                        How To Refer
                    </div>

                    <div className="aboutreferal_div_benefit_div" data-aos="fade-up" data-aos-once={true} >

                        <div className="aboutreferal_div_benefit_div_1" >
                            <img alt="" src={Pic3} className="aboutreferal_div_benefit_div_1_img" />
                        </div>

                        <div className="aboutreferal_div_benefit_div_2" >

                            <ul className="aboutreferal_div_benefit_div_1_ul" >
                                <li className="aboutreferal_div_benefit_div_1_ul_li" >
                                    On the top navigation bar click on the profile icon.
                                </li>
                                <li className="aboutreferal_div_benefit_div_1_ul_li" >
                                	Click on referrals on the left side of the profile page.
                                    for android and ios devices  click on the menu button located at
                                    the bottom right corner of the profile page , click on referrals on the slider. 
                                </li>
                                <li className="aboutreferal_div_benefit_div_1_ul_li" >
                                    Input bank account detaails in the referral account details.
                                </li>
                                <li className="aboutreferal_div_benefit_div_1_ul_li" >
                                	Click on the copy link to clipboard button to copy your referral link.
                                </li>
                                <li className="aboutreferal_div_benefit_div_1_ul_li" >
                                	Share your referral with your network.
                                </li>
                            </ul>

                            <Link to="/my_referrals" className="aboutreferal_div_top_btn" >
                                Start Refering
                            </Link>

                        </div>

                    </div>

                </div>



          </div>

          <Footer/>

          </>


      );

}

export default AboutReferal;