import React,{useState} from 'react';
import Footerdiv from '../../layout/footer/footer';
import ProductSellpage from './productsale';
import AddservPage from '../../services/pages/Addservpage/addservpage';
import Svg from '../../component/utilities/Svg';

const Sellpage = (props) => {

    const [scroll,setscroll] = useState(true)

    const [ whichSell , setwhichsell ] = useState('product')



    if( scroll ){
      var lam = window.scrollTo(1,1)
      setscroll(false)
  }



      if(whichSell === 'product' ){
        var demshowsell = <ProductSellpage history={props.history} />
      }
      if(whichSell === 'service' ){
        demshowsell = <AddservPage history={props.history} />
      }

      return ( 

        <>

        <div className="sell-page-div" >

                    <div className="sell-page-div-oth" >
                        <div className="sell-page-div-oth-list" onClick={ () => setwhichsell('product') } style={{
                          backgroundColor: whichSell === 'product' ? '' : 'rgba(128, 128, 128, 0.589)' ,
                          border: whichSell === 'product' ? '' : '1px solid white' ,
                          color: whichSell === 'product' ? '' : 'white'
                        }} >
                        
                          <Svg className="sell-page-div-oth-list-ic" style={
                            whichSell === 'product' ? '' : 'white'
                          } href="sprite4.svg#icon-store_mall_directorystore" />

                           Sell a Product 
                        </div>
                        <div className="sell-page-div-oth-list" onClick={ () => setwhichsell('service') } style={{
                          backgroundColor: whichSell === 'service' ? '' : 'rgba(128, 128, 128, 0.589)' ,
                          border: whichSell === 'service' ? '' : '1px solid white' ,
                          color: whichSell === 'service' ? '' : 'white'
                        }} >
                        
                          <Svg className="sell-page-div-oth-list-ic" style={
                            whichSell === 'service' ? '' : 'white'
                          } href="sprite4.svg#icon-handshake-o" />

                           Post a Service 
                        </div>
                    </div>

            {lam}

            {demshowsell}

        </div>

        <Footerdiv/>

        </>

      );

}

export default Sellpage;