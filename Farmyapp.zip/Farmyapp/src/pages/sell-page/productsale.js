import React,{useState, useContext , useEffect } from 'react';
import Selltemplate from '../../component/sellpage_template/sellpage_template';
import Axios from 'axios';
import Topbanner from '../../component/utilities/top-banner-msg/topbannermsg';
import LeafletMapDiv from '../../component/LeafletMap/LeafletMap';
import Backdrop from '../../component/utilities/Backdrop/backdrop';
import {TermsandCondition, TermsandConditionList} from '../../component/utilities/TermsAndCondition/termsandcondition';
import { Popup } from 'react-leaflet';
import Store from '../../store/managementstore/managementstore';


const ProductSellpage = (props) => {
  
    const context = useContext(Store)

    const [ errormessage , seterrormessage ] = useState( { msg: '' , status:false , bgcolor: '' } )

    const [scroll,setscroll] = useState(true)

    const [ selldata , setselldata ] = useState({
      product_name:{
        value:'',
        error:false
      } ,
      product_description: '',
      product_price:'',
      product_scale:'',
      product_available:'',
      product_harvestdate:'' ,
      transport_means: null,
      amount_can_carry:'',
      country:'Nigeria',
      state:'',
      Lga:'',
      address:'',
      longitude:'',
      latitude:'',
      mapstory:'Search and select the closest place to your farm on the map',
      maparea:'',
      accountname:'',
      accountnumber:'',
      bankname:''
    }) 

    const [ openMap , setopenMap ] = useState(false)

    const [ ShowTerms , setShowTerms ] = useState(false)

    const [ btn , setbtn ] = useState(false)

    const [user_detail,setuser_detail] = useState(null)
    const [user_detail2,setuser_detail2] = useState(null)


    useEffect( () => {
      setuser_detail({...context.User_details.detail})
      setuser_detail2({...context.User_details.detail2})
} , [context.User_details.detail , context.User_details.detail2 , context.User_cart_id] )


    // logic for changing the state that has to do with text only e.g product name , product desc e.t.c
    //======================

    // const productnameonchangeHandler = (event) => {
    //   var initialdata = {...selldata}
    //   setselldata({...initialdata,product_name:event.target.value})
    // }

    const productdescriptiononchangeHandler = (event) => {
      var initialdata = {...selldata}
      setselldata({...initialdata,product_description:event.target.value})
    }

    const productpriceonchangeHandler = (event) => {
      var initialdata = {...selldata}
      setselldata({...initialdata,product_price:event.target.value})
    }

    const productscaleonchangeHandler = (event) => {
      var initialdata = {...selldata}
      setselldata({...initialdata,product_scale:event.target.value})
    }

    const productavailableonchangeHandler = (event) => {
      var initialdata = {...selldata}
      setselldata({...initialdata,product_available:event.target.value})
    }

    const productharvestdateonchangeHandler = (event) => {
      var initialdata = {...selldata}
      setselldata({...initialdata,product_harvestdate:event.target.value})
    }

    ///////////////////////////////////////
    //=====================================







    //All logic partaining to image upload and image validation
    //========================


    const [file1 , setfile1] = useState({image:null,preview:null})
    const [file2 , setfile2] = useState({image:null,preview:null})
    const [file3 , setfile3] = useState({image:null,preview:null})


    //logic to check if the image uploaded is actually a picture and not another file
    //===========================


    const acceptedFileType = 'image/x-png , image/png, image/jpg, image/jpeg, image/gif '
    const acceptedFileTypeArray = acceptedFileType.split(',').map((item) => {return item.trim()} )

    const veriyfyFile = (file) => {
      const currentfile = file
      const currentfileType = currentfile.type

      if( !acceptedFileTypeArray.includes(currentfileType) ){
        return false
      }else{
        return true
      }

    }

    //////////////
    //=================================

    //logic for chexking the validation of the three image input with the verfiyfile function above 
    //and also to show the preview with the showpreview function below

    const choosefirstimageHandler = (event) => {
        if(veriyfyFile(event.target.files[0])){
          showpreview(event.target.files[0],1)
        }else{
          setfile1({image:null,preview:''})
          seterrormessage( { msg: 'Only jpg , jpeg , png , x-png and gif files are allowed' , status: true , bgcolor: 'red' } )
        }
    } 

    const choosesecondimageHandler = (event) => {
        if(veriyfyFile(event.target.files[0])){
          showpreview(event.target.files[0],2)
        }else{
          setfile2({image:null,preview:''})
          seterrormessage( { msg: 'Only jpg , jpeg , png , x-png and gif files are allowed' , status: true , bgcolor: 'red' } )
        }
    }  

    const choosethirdimageHandler = (event) => {
      if(veriyfyFile(event.target.files[0])){
        showpreview(event.target.files[0],3)
      }else{
        setfile3({image:null,preview:''})
        seterrormessage( { msg: 'Only jpg , jpeg , png , x-png and gif files are allowed' , status: true , bgcolor: 'red' } )
      }
    }  

    /////////////////
    //==================================



    // this function is used to show the preview of an image about to be uploaded 
    // or it can be called a function that converts a file to base 64


    const showpreview = (file,where) => {

        const currentfile = file 
        const reader = new FileReader()
        reader.addEventListener("load",()=>{
            if(where === 1){
                setfile1({image:file,preview:reader.result})
            }
            if(where === 2){
                setfile2({image:file,preview:reader.result})
            }
            if(where === 3){
                setfile3({image:file,preview:reader.result})
            }
        },false)

        reader.readAsDataURL(currentfile)

    }

    ////////////////
    //===================================


    
    
    //////////////////////////
    //===================================





    // a logic to make sure that the user dose not input letters but only digit
    ////////////////////

    const accepteddigit = '1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 0'
    const accepteddigitarray = accepteddigit.split(',').map((item) => {return item.trim()} )

    
    const verifynum = (file,message) => {

      const currentfile = file

      for (let k = 0; k < currentfile.length; k++) {

        if( !accepteddigitarray.includes(currentfile[k]) ){

          seterrormessage( { msg: message , status: true , bgcolor: 'red' } );
          return false

        }else{

          return true

        }

      }

    }


    /////////////////
    ////=============================



    // a function that consist of final validation and posting of the validated form to the back end
    ////////////////////////

    const sellproductHandler = ( ) => {

      // console.log(selldata)

        seterrormessage( { msg: ' Please wait while your request is being uploaded ' , status: true , bgcolor: 'orange' } )

      if( 
          selldata.product_name === '' ||
          selldata.product_description === '' ||
          selldata.product_price === '' ||
          selldata.product_scale === '' ||
          selldata.product_harvestdate === '' ||
          selldata.product_available === '' ||
          selldata.Lga === '' ||
          selldata.address === '' ||
          selldata.amount_can_carry === '' ||
          selldata.country === '' ||
          selldata.latitude === '' ||
          selldata.longitude === '' ||
          selldata.state === '' ||
          selldata.maparea === '' ||
          selldata.accountname === '' ||
          selldata.accountnumber === '' ||
          selldata.bankname === '' ||
          selldata.transport_means === null ||
          file1.image === null ||
          file2.image === null ||
          file3.image === null ){

        seterrormessage( { msg: ' All fileds must be filled ' , status: true , bgcolor: 'red' } )
      }

      // if (verifynum(selldata.product_available)) {
      //   console.log('ok')
      // }

      const error_availabeharvest = 'Quantity available for sale should just be digit e.g(94) and measurement scale (kgs,bags,baskets e.t.c ) should not be added to it'
      const error_price = 'Price should just be digit only , letters or symbols should not be added to it'
      const error_cancarry = 'Amount of '+ selldata.product_scale +' the selected vehicle can carry should just be digit only , letters or symbols should not be added to it'
      const error_number = ' Your Account Number Should Only Be Numeric '


      if( selldata.product_name !== '' &&
          selldata.product_description !== '' &&
          selldata.product_price !== '' &&
          selldata.product_scale !== '' && 
          selldata.product_harvestdate !== '' && 
          selldata.product_available !== '' && 
          file1.image !== null && 
          file2.image !== null && 
          file3.image !== null  && 
          selldata.transport_means !== null  && 
          verifynum(selldata.product_price,error_price) && 
          verifynum(selldata.amount_can_carry,error_cancarry)  && 
          verifynum(selldata.product_available,error_availabeharvest) &&
          verifynum(selldata.accountnumber,error_number) &&
          selldata.Lga !== '' &&
          selldata.address !== '' &&
          selldata.amount_can_carry !== '' &&
          selldata.country !== '' &&
          selldata.latitude !== '' &&
          selldata.longitude !== '' &&
          selldata.state !== '' &&
          selldata.accountname !== '' &&
          selldata.accountnumber !== '' &&
          selldata.bankname !== '' &&
          selldata.maparea !== '' 
          ){
            if( 
              user_detail.first_name === '' || 
              user_detail.last_name === '' || 
              user_detail.email === '' || 
              (user_detail2.phone_number === null || user_detail2.phone_number === '' )
          ){
              seterrormessage( { msg: ' Your Profile details must be complete before you can sell , ' , status: true , bgcolor: 'red' } )
          }else{
            setShowTerms(true)
          }
      }

    }

   
   
   
   
   
   
    const SendDataForreal = () => {
      setShowTerms(false)
      setbtn(true)
      seterrormessage( { msg: ' Please wait while your request is being uploaded ' , status: true , bgcolor: 'orange' } )
      const Datatosubmit = new FormData();

      Datatosubmit.append('product_name',selldata.product_name)
      Datatosubmit.append('description',selldata.product_description)
      Datatosubmit.append('price',selldata.product_price)
      Datatosubmit.append('measurement_scale',selldata.product_scale)
      Datatosubmit.append('harvest_date',selldata.product_harvestdate)
      Datatosubmit.append('quantity_available',selldata.product_available)
      Datatosubmit.append('product_img1',file1.image,file1.image.name)
      Datatosubmit.append('product_img2',file2.image,file2.image.name)
      Datatosubmit.append('product_img3',file3.image,file3.image.name)
      Datatosubmit.append('bank_name',selldata.bankname)
      Datatosubmit.append('account_name',selldata.accountname)
      Datatosubmit.append('account_number',selldata.accountnumber)        
      Datatosubmit.append('available',true)
      
      Axios.post('/product/',Datatosubmit)
      .then( Response => {
           var productId = Response.data.id 
           var productSlug = Response.data.slug

           var Addressdet = {
             suitable_van: selldata.transport_means,
             can_carry: selldata.amount_can_carry,
             country: selldata.country,
             state: selldata.state,
             lga: selldata.Lga,
             address: selldata.address,
             longitude: selldata.longitude,
             latitude: selldata.latitude, 
             area: selldata.maparea,
           }

            Axios.post('/product/' + productId + '/product_address/' , Addressdet ).then(
              response => {
                props.history.push('/product' + productSlug + ":" + productId )
                seterrormessage( { msg: ' Your product was successfully uploaded ' , status: true , bgcolor: 'rgb(39, 180, 39)' } )        
              }
            ).catch(
              error => {
                seterrormessage({
                  status:true,
                  msg:' Something Went Wrong ',
                  bgcolor:'red'
                })
              }
            )


      } ).catch( (error) => {
        if(error.response){

            setbtn(false)
            if(error.response.data.quantity_available){
              seterrormessage({
                status:true,
                msg:'Make sure that the quantity available is less than or equals to 2500 ',
                bgcolor:'red'
              })
            }else{
              seterrormessage({
                status:true,
                msg:' Something Went Wrong ',
                bgcolor:'red'
              })
            }

        }
    } );
    }


    ////////////////////
    //=====================================




    if( scroll ){
      var lam = window.scrollTo(1,1)
      setscroll(false)
  }


  const myPopup = (SearchInfo) => {

    return(
                <Popup>
                    {/* <div> */}
                    <p 

                    style={{
                        fontWeight:'800'
                    }}

                    >{SearchInfo.info}</p>
                    {/* {/* <div>Latitude:{SearchInfo.latLng.lat}</div> */} 
                    {/* {/* <div>Longitude:{SearchInfo.latLng.lng}</div> */} 

                    <button className="Mappupop_btn" onClick={ 
                        () => setAllUserlocationdetails(SearchInfo)
                     } > Select Location </button>
                </Popup>
    );
  }


// Map Address issues

  const setAllUserlocationdetails = (SearchInfo) => {

    setselldata({
      ...selldata,
      mapstory:'Please wait , this might take some time...  '
    })

    setselldata({
      ...selldata,
      latitude:SearchInfo.latLng.lat,
      longitude:SearchInfo.latLng.lng,
      mapstory:'Location was successfully saved..',
      maparea:SearchInfo.info
    })

    // setselldata({
    //   ...selldata,
    //   mapstory:'Search and select the closest place to your farm on the map',
    // })

    setopenMap(false)
  }

////

      return ( 

        <>
      {/* Leaflet map comnponents and logics */}

            <Backdrop show={openMap}
             />
             { openMap ?   
               <LeafletMapDiv 
                  myPopup={ myPopup }
                  story={ selldata.mapstory }   
                 closeMap={ () => setopenMap(false) } /> 
            :
            null
            }

      {/* //////////////////////////////// */}


      {/* Terms and conditions to be accepted before posting */}

            <Backdrop show={ShowTerms} />

            <TermsandCondition 

                             style={{
                               transform: ShowTerms ? 'translateX(0)' : 'translateX(-200rem)' 
                             }}
                             Agree={ SendDataForreal }
                             Cancel={ () => setShowTerms(false) }>
                                { TermsandConditionList }
                             </TermsandCondition>
                             

      {/* ///////////////////////////////////// */}

        <Topbanner
          show={errormessage.status}
          backgroundcolor={errormessage.bgcolor}
          message={errormessage.msg}
          closeshow={ () => seterrormessage( { ...errormessage , status: false } ) } />

            {lam}

            <Selltemplate
             whataction="Sell a product"
             productnamevalue={selldata.product_name.value}
             productnameonChange={ (event) => setselldata({
               ...selldata,
               product_name:{
                ...selldata.product_name,
                 value:event.target.value,
               }
             }) }
             productnameerror={ errormessage.message === 'All fileds must be filled' ? true : false }
             productdescriptionvalue={selldata.product_description}
             productdescriptiononChange={productdescriptiononchangeHandler}
             productpricevalue={selldata.product_price}
             productpriceonChange={productpriceonchangeHandler}
             productscalevalue={selldata.product_scale}
             productscaleonChange={productscaleonchangeHandler}
             productavailablevalue={selldata.product_available}
             productavailableonChange={productavailableonchangeHandler}
             productharvestdatevalue={selldata.product_harvestdate}
             productharvestdateonChange={productharvestdateonchangeHandler}
             choosefirstimage={choosefirstimageHandler}
             previewfirstimage={file1.preview}
             choosesecondimage={choosesecondimageHandler}
             previewsecondimage={file2.preview}
             choosethirdimage={choosethirdimageHandler}
             previewthirdimage={file3.preview}
             
             sellproduct={ sellproductHandler }
             select_trans_1={ () => setselldata( {...selldata,transport_means:'tricycle'} ) }
             selected_mean_1={ selldata.transport_means === 'tricycle' ? true : false }
             select_trans_2={ () => setselldata( {...selldata,transport_means:'cabster'} ) }
             selected_mean_2={ selldata.transport_means === 'cabster' ? true : false } 
             select_trans_3={ () => setselldata( {...selldata,transport_means:'trailer'} ) }
             selected_mean_3={ selldata.transport_means === 'trailer' ? true : false }
             buttonoption='Sell product'
             disablebtn={ btn }

             //Delivery part

             amoutcancarry={ selldata.amount_can_carry }
             onChangeamoutcancarry={ (event) => setselldata({...selldata,amount_can_carry:event.target.value}) }

             //

             //Address part

             countryvalue={ selldata.country }
             countryonChange={ (event) => setselldata({...selldata,country:event.target.value}) }

             statevalue={ selldata.state }
             stateonChange={ (event) => setselldata({...selldata,state:event.target.value}) }

             lgavalue={ selldata.Lga }
             lgaonChange={ (event) => setselldata({...selldata,Lga:event.target.value}) }

             farmaddressvalue={ selldata.address }
             farmaddressonChange={ (event) => setselldata({...selldata,address:event.target.value}) }

             //

             //Map Longitude and latitude

             mapareaValue={selldata.maparea}

             latitudevalue={ selldata.latitude }
             latitudeonChange={ (event) => setselldata({...selldata,latitude:event.target.value}) }

             
             longitudevalue={ selldata.longitude }
             longitudeonChange={ (event) => setselldata({...selldata,longitude:event.target.value}) }

             Openmap={ () => setopenMap(true) }

             //

            //  Account details

              accountname={ selldata.accountname }
              accountnameonChange={ (event) => setselldata({ ...selldata , accountname:event.target.value }) }

              accountnumber={ selldata.accountnumber }
              accountnumberonChange={ (event) => setselldata({ ...selldata , accountnumber: event.target.value  }) }
              
              bankname={ selldata.bankname }
              banknameonChange={ (event) => setselldata({ ...selldata , bankname: event.target.value })  }

            //

              /> 


        </>

      );

}

export default ProductSellpage;