import React from 'react';


 const OrderList = (props) => {

    return (
        <div className="OrderList-div" clasName={ props.className } style={{
            width:props.width
        }} >
            <div clasName="OrderList-div-first" style={{
                borderBottom:'1px solid lightgray',
                padding:'1rem',
                display:'flex',
                justifyContent:'space-between',
            }} >
                <div className="OrderList-div-first-det" >
                    { props.Orderimg ?   <div className="OrderList-div-first-det-img" >
                                        <img alt="" src={props.Orderimg} className="OrderList-div-first-det-img-img" />
                                    </div> : '' }
                    <div className="OrderList-div-first-det-name" >
                        {props.productName}
                    </div>
                </div>

                { props.status ?
            
                    <div className="OrderList-div-first-status" style={{ backgroundColor:props.bgColor }} >
                        {props.status}
                    </div>

                : null
            
                 }

            </div>


                { props.putaddress ? 
                
                <>
                <div clasName="OrderList-div-to-second" style={{
                    borderBottom:'1px solid lightgray',
                    padding:'1rem',
                    fontSize:'1.2rem',
                    display:'flex',
                    // justifyContent:'space-between'
                }} >
    
                    <div  style={{
                    borderRight:'1px solid lightgray',
                    padding:'1rem',
                    width:'fit-content'
                    }} >
                        {props.whichaddress}
                    </div>
                    <div  style={{
                    padding:'1rem',
                    }} >

                        { props.address && props.lga && props.state ? 
                    
                            props.address +
                            <br/> +
                            props.lga + ' , ' + props.state 
                                +
                            <br/>

                    : null

                    }
                        
                        <div style={{ marginTop: props.address ? '1rem' : '' }} ></div>

                        { props.theFirst_name } { props.theLast_name }    
                        
                        <br/>
                        { props.theNumber }     
                
                    </div>
                    
                </div>
    

                </>                   
                
                : '' }

            <div clasName="OrderList-div-second" style={{
                display:'flex',
                borderBottom:'1px solid lightgray'
            }} >


            <div clasName="OrderList-div-second-seg" style={{
                    borderRight:'1px solid lightgray',
                    width:'25%',
                }} >
                    <div clasName="OrderList-div-second-seg-1" style={{
                        padding:'.5rem',
                        borderBottom:'1px solid lightgray',
                        fontSize:'1.3rem',
                        textAlign:'center'
                    }}  > Quantity </div>
                    <div clasName="OrderList-div-second-seg-2" style={{
                        padding:'.5rem',
                        textAlign:'center',
                        fontSize:'1.3rem'
                    }} > {props.quantity} { props.measurement_scale } </div>
                </div>

                <div clasName="OrderList-div-second-seg" style={{
                    borderRight:'1px solid lightgray',
                    width:'25%',
                }} >
                    <div clasName="OrderList-div-second-seg-1" style={{
                        padding:'.5rem',
                        borderBottom:'1px solid lightgray',
                        fontSize:'1.3rem',
                        textAlign:'center'
                    }}  > Product Cost </div>
                    <div clasName="OrderList-div-second-seg-2" style={{
                        padding:'.5rem',
                        textAlign:'center',
                        fontSize:'1.3rem'
                    }} > ₦ {props.product_cost} </div>
                </div>

                <div clasName="OrderList-div-second-seg" style={{
                    borderRight:'1px solid lightgray',
                    width:'25%',
                }} >
                    <div clasName="OrderList-div-second-seg-1" style={{
                        padding:'.5rem',
                        borderBottom:'1px solid lightgray',
                        fontSize:'1.3rem',
                        textAlign:'center'
                    }}  > Transport Cost </div>
                    <div clasName="OrderList-div-second-seg-2" style={{
                        padding:'.5rem',
                        textAlign:'center',
                        fontSize:'1.3rem'
                    }} > ₦ {props.tfare} </div>
                </div>

                <div clasName="OrderList-div-second-seg" style={{
                    width:'25%',
                }} >
                    <div clasName="OrderList-div-second-seg-1" style={{
                        padding:'.5rem',
                        borderBottom:'1px solid lightgray',
                        fontSize:'1.3rem',
                        textAlign:'center'
                    }}  > Total Cost </div>
                    <div clasName="OrderList-div-second-seg-2" style={{
                        padding:'.5rem',
                        textAlign:'center',
                        fontSize:'1.3rem'
                    }} > ₦ {props.totalcost} </div>
                </div>

            </div>
                { props.pending ?
                
                <div clasName="meorder-div-third" style={{
                    padding:'1.5rem'
                }} >
                    <button className="meorder-div-third-btn" onClick={props.ChangeToDelivered} style={{
                        backgroundColor:'rgba(13, 194, 94, 0.986)',
                        color:'white',
                        padding:'.6rem',
                        border:'none',
                        borderRadius:'4px',
                        cursor:'pointer',
                        fontSize:'1.1rem',
                    }} > Change product status to delivered </button>
                </div>
                
                : null }

                { props.switchtointransit ?
                
                <div clasName="meorder-div-third" style={{
                    padding:'1.5rem'
                }} >
                    <button className="meorder-div-third-btn" onClick={props.ChangeTointransit} style={{
                        backgroundColor:'rgb(50, 127, 241)',
                        color:'white',
                        padding:'.6rem',
                        border:'none',
                        borderRadius:'4px',
                        cursor:'pointer',
                        fontSize:'1.1rem',
                    }} > Change order status to in transit </button>
                </div>
                
                : null }
        </div>
    );

}

export default OrderList 