import React, { useState, useEffect } from 'react';
import Axios from 'axios';
import Backdrop from '../../component/utilities/Backdrop/backdrop';
import Loading from '../../component/utilities/loading/loading'
import Svg from '../../component/utilities/Svg';
import TopbannerDiv from '../../component/utilities/top-banner-msg/topbannermsg';
import { OrderProductWithDelivery } from '../../component/orderListTemplate/orderListTemplate';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';
import LoadingPage from '../../foods/components/loading/loading';
import OppsPage from '../../foods/components/oppspage/oppspage';
import ProfileHeader from '../../foods/layout_components/profile_header/profile_header';

const FullOrderDiv = (props) => {

    const Order_id = props.match.params.id

    const [ Loadingpage , setLoadingpage ] = useState(false)
    const [ Errorpage , setErrorpage ] = useState(false)
    const [ WholeOrder , setWholeOrder ] = useState(null)
    const [ status , setstatus ] = useState(null)
    const [ productToberated , setproductToberated ] = useState(null)
    const [ ratingNumber , setratingNumber ] = useState(null)
    const [ productid , setproductid ] = useState(null)
    const [ openModal , setopenModal ] = useState(false)
    const [ changingOrderstatus , setchangingOrderstatus ] = useState(false)

    const [ message , setmessage ] = useState({
        bgColor:'',
        msg:'',
        status:false
    })

    const [ ratingproduct , setratingproduct ] = useState(false)

    const [ Fullstar , setFullstar ] = useState([
        { fill: 'lightgray' , id:1 },
        { fill: 'lightgray' , id:2 },
        { fill: 'lightgray' , id:3 },
        { fill: 'lightgray' , id:4 },
        { fill: 'lightgray' , id:5 }
    ])

    useEffect( () => {

        setLoadingpage(true)
        setErrorpage(false)

        Axios.get('/orders/order/' + Order_id + '/').then(
            response => {
                setLoadingpage(false)
                setErrorpage(false)
                setWholeOrder(response.data)
            }
        ).catch(
            e => {
                setLoadingpage(false)
                setErrorpage(true)
            }
        )

    } , [ Order_id ] )









    if( WholeOrder && !status ){

        var get = []

        for (let u = 0; u < WholeOrder.items.length; u++) {
            if(WholeOrder.items[u].status === 'paid'  ){
                get.push(WholeOrder.items[u])
            }
            if(WholeOrder.items[u].status === 'in_transit'  ){
                get.push(WholeOrder.items[u])
            }
        }

        setstatus(get)

    }





    const AddColortostar = ( number ) => {

        if( number === 1 ){
            setFullstar([
                { fill: 'rgba(13, 194, 94, 0.986)' , id:1 },
                { fill: 'lightgray' , id:2 },
                { fill: 'lightgray' , id:3 },
                { fill: 'lightgray' , id:4 },
                { fill: 'lightgray' , id:5 }
            ])
            setratingNumber(1)
        }

        if( number === 2 ){
            setFullstar([
                { fill: 'rgba(13, 194, 94, 0.986)' , id:1 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:2 },
                { fill: 'lightgray' , id:3 },
                { fill: 'lightgray' , id:4 },
                { fill: 'lightgray' , id:5 }
            ])
            setratingNumber(2)
        }

        if( number === 3 ){
            setFullstar([
                { fill: 'rgba(13, 194, 94, 0.986)' , id:1 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:2 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:3 },
                { fill: 'lightgray' , id:4 },
                { fill: 'lightgray' , id:5 }
            ])
            setratingNumber(3)
        }

        if( number === 4 ){
            setFullstar([
                { fill: 'rgba(13, 194, 94, 0.986)' , id:1 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:2 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:3 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:4 },
                { fill: 'lightgray' , id:5 }
            ])
            setratingNumber(4)
        }

        if( number === 5 ){
            setFullstar([
                { fill: 'rgba(13, 194, 94, 0.986)' , id:1 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:2 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:3 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:4 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:5 }
            ])
            setratingNumber(5)
        }

    }






    const Finalrating = () => {

        if( ratingNumber && productid && productToberated ){

            Axios.post( '/product/' + productid + '/rate_product/' , {stars:ratingNumber} ).then(
                response => {
                    setFullstar([
                        { fill: 'lightgray' , id:1 },
                        { fill: 'lightgray' , id:2 },
                        { fill: 'lightgray' , id:3 },
                        { fill: 'lightgray' , id:4 },
                        { fill: 'lightgray' , id:5 }
                    ])
                    setratingproduct(false)
                    setproductToberated(null)
                    setproductid(null)
                    setopenModal(false)
                    setmessage({
                        status:true,
                        bgColor:'rgba(13, 194, 94, 0.986)',
                        msg:' Product Was Successfully rated ' 
                    })
                }
            )

        }

    }






    const AddTheratingStar = (number,prodName,productId) => {
        setopenModal(true)
        setchangingOrderstatus(true)
 

        Axios.patch('/orders/order_items/' + number + '/' , { status:'delivered' } ).then(
            response => {
                Axios.get('/orders/order/' + Order_id + '/').then(
                    response => {
                        setWholeOrder(response.data)
                        setchangingOrderstatus(false)
                        setratingproduct(true)
                        setproductToberated(prodName)
                        setproductid(productId)
                    }
                )
            }
        )

    }







      const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }
    
    
      if( Loadingpage && !WholeOrder && !status && !Errorpage ){
        var what_to_return = <LoadingPage/>
      }else{
        if ( !Loadingpage && Errorpage && !WholeOrder && !status ) {
          what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
          if ( !Loadingpage && !Errorpage && WholeOrder && status ) {
            what_to_return = 

                <div className="FullOrderDiv-div-page" >
                    <div className="FullOrderDiv-div" >
    
                        <div className="FullOrderDiv-div-items" >
                            <div className="FullOrderDiv-div-items-top" >
                                Order Items
                            </div>
                            <div className="FullOrderDiv-div-items-list" >
    
                                 { WholeOrder ? 
                                 
                                    WholeOrder.items.map( ( item , index ) => {
    
                                        if( item.status === 'paid'){
                                            var bgColor = 'orange'
                                            var status = 'Pending'
                                        }
    
                                        
                                        if( item.status === 'in_transit'){
                                             bgColor = 'rgb(50, 127, 241)'
                                             status = 'In Transit'
                                        }
    
                                        if( item.status === 'delivered'){
                                             bgColor = 'rgba(13, 194, 94, 0.986)'
                                             status = 'Delivered'
                                        }
    
                                        return    <OrderProductWithDelivery 
                                                            Orderimg={'https://farmyapp.xyz' + item.product.product_img1}
                                                            productName={ item.product.product_name }
                                                            key={index}
                                                            address={ item.product.address[0].address }
                                                            lga={ item.product.address[0].lga }
                                                            state={ item.product.address[0].state }
                                                            theFirst_name={ item.product.user.first_name }
                                                            theLast_name={ item.product.user.last_name }
                                                            theNumber={ item.product.user.pro.phone_number }
                                                            width='100%'
                                                            showAddress={true}
                                                            status={ status }
                                                            bgColor={ bgColor }
                                                            quantity={ item.quantity }
                                                            measurement_scale={ item.product.measurement_scale }
                                                            product_cost={ item.get_cost }
                                                            tfare={ item.get_tfare }
                                                            totalcost={ item.get_bsolute }
                                                            pending={item.status === 'in_transit' || ( !item.order.address[0] && item.status !== 'delivered' )  ? true : false }
                                                            ChangeToDelivered={ () => AddTheratingStar(item.id,item.product.product_name,item.product.id) }
                                          />
                                    } )
    
                                 : <Loading color='white' /> }
    
                            </div>
                            
                            <div className="FullOrderDiv-div-items-btm" >
    
                            <div className="FullOrderDiv-div-items-btm-right" >
                                <div className="FullOrderDiv-div-items-btm-right-det" >
                                    <div className="FullOrderDiv-div-items-btm-right-det-1" >
                                        <span className="FullOrderDiv-div-items-btm-right-det-1-total" >Total: </span> 
                                        <span className="FullOrderDiv-div-items-btm-right-det-1-value" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(WholeOrder ? WholeOrder.get_total_cost : '')} </span>
                                    </div>
                                    <div className="FullOrderDiv-div-items-btm-right-det-2" >
                                        Transport fee already included
                                    </div>
                                </div>
                            </div>
    
                            </div>
                        
                        </div>
    
                    </div>
    
            </div>
    
    
          }
        }
      }






      return ( 


          <>



          <TopbannerDiv 
             show={ message.status }
             message={ message.msg }
             backgroundcolor={ message.bgColor }
             closeshow={ () => setmessage({...message,status:false}) }  
          />



          

        <Backdrop
          show={ openModal } >
              
            { changingOrderstatus ?  
            
                <BtnSpin bgColor="white" />
            : ''
            }

            { ratingproduct ? 
            
            
            <div className="FullOrderDiv-div-page-Addstar" >
                <div className="FullOrderDiv-div-page-Addstar-top" > Rate this product : </div>
                <div className="FullOrderDiv-div-page-Addstar-prodName" > { productToberated ? productToberated : '' } </div>
                <div className="FullOrderDiv-div-page-Addstar-main" > 
                    { Fullstar.map( star => {
                        return  <Svg 
                        style={star.fill}
                        onClick={ () => AddColortostar(star.id) }
                        className="FullOrderDiv-div-page-Addstar-main-ic"
                        href="opps.svg#icon-star-full" />
                    } ) }
                </div>
                <div className="FullOrderDiv-div-page-Addstar-sbt" >
                    <button className="FullOrderDiv-div-page-Addstar-sbt-ic" onClick={Finalrating} > rate </button>
                </div>
            </div> 

             : '' }

        </Backdrop>      




        <ProfileHeader
            title="My Order"
            goback={ goBack }
        />

        {what_to_return}





        </>
      );

}

export default FullOrderDiv;