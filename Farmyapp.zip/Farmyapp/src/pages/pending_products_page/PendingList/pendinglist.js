import React from 'react';
import {Link} from 'react-router-dom';



export const PendingList = (props) => {
 
    // if( props.product_description ){
        
    //     var desc = props.product_description

    //     if( desc.length < 300 ){
    //         var applydesc = desc
    //     }
        
    //     if( desc.length > 300 ){
    //         var Alright = []

    //         for (let h = 0; h < 300; h++) {
    //             Alright.push(desc[h])
    //         }

    //         applydesc = Alright

    //     }

    // }

    // 
      return ( 
          <div className="pendingList-div" >
              <div className="pendingList-div_first" >
                  <div className="pendingList-div_first_left" >
                        <div className="pendingList-div_first_left_img" >
                            <img alt="" src={props.firstimage} className="pendingList-div_first_left_img_img" />
                        </div>
                  </div>
                  <div className="pendingList-div_first_right" >    
                        <div className="pendingList-div_first_right_name" >
                            {props.productname}
                        </div>
                        {/* <div className="pendingList-div_first_right_desc" >
                            {applydesc}
                        </div> */}
                  </div>
              </div>
              <div className="pendingList-div_mid" >
                        <div className="pendingList-div_first_right_nar" >
                            <span className="pendingList-div_first_right_nar_1" >
                                Quantity Available :
                            </span>
                            <span className="pendingList-div_first_right_nar_2" >
                                { props.quantityavailable + ' ' + props.mesurementscale }
                            </span>
                        </div>
                        <div className="pendingList-div_first_right_nar" >
                            <span className="pendingList-div_first_right_nar_1" >
                                Pending Orders :
                            </span>
                            <span className="pendingList-div_first_right_nar_2" >
                               { props.pendingorders }
                            </span>
                        </div>
                        <div className="pendingList-div_first_right_nar" >
                            <span className="pendingList-div_first_right_nar_1" >
                                In Transit Orders :
                            </span>
                            <span className="pendingList-div_first_right_nar_2" >
                               { props.in_transitorders }
                            </span>
                        </div>
                        <div className="pendingList-div_first_right_nar" >
                            <span className="pendingList-div_first_right_nar_1" >
                                Delivered Orders :
                            </span>
                            <span className="pendingList-div_first_right_nar_2" >
                                { props.deliveredOrders }
                            </span>
                        </div>
                        <div className="pendingList-div_first_right_nar" >
                            <span className="pendingList-div_first_right_nar_1" >
                                Total Number Of Orders :
                            </span>
                            <span className="pendingList-div_first_right_nar_2" >
                                { props.quantityordered + ' ' + props.mesurementscale }
                            </span>
                        </div>
              </div>
              <div className="pendingList-div_second" >  
                    <button className="pendingList-div_second_btn" onClick={ props.OpenDetails } >
                        View All Orders
                    </button>
              </div>
          </div>
      );

}



export const ProductList = (props) => {

    if( props.product_description ){
        
        var desc = props.product_description

        if( desc.length < 300 ){
            var applydesc = desc
        }
        
        if( desc.length > 300 ){
            var Alright = []

            for (let h = 0; h < 300; h++) {
                Alright.push(desc[h])
            }

            applydesc = Alright

        }

    }

    // 
      return ( 
          <div className="pendingList-div" >
              <div className="pendingList-div_first" >
                  <div className="pendingList-div_first_left" >
                        <div className="pendingList-div_first_left_img" >
                            <img alt="" src={props.firstimage} className="pendingList-div_first_left_img_img" />
                        </div>
                  </div>
                  <div className="pendingList-div_first_right" >    
                        <div className="pendingList-div_first_right_name" >
                            {props.productname}
                        </div>
                        <div className="pendingList-div_first_right_desc" >
                            {applydesc}
                        </div>
                  </div>
              </div>
              <div className="pendingList-div_mid" >
                        <div className="pendingList-div_first_right_nar" >
                            <span className="pendingList-div_first_right_nar_1" >
                                Quantity Available :
                            </span>
                            <span className="pendingList-div_first_right_nar_2" >
                                { props.quantityavailable + ' ' + props.mesurementscale }
                            </span>
                        </div>
                        {/* <div className="pendingList-div_first_right_nar" >
                            <span className="pendingList-div_first_right_nar_1" >
                                Total Quantity Of Products
                            </span>
                            <span className="pendingList-div_first_right_nar_2" >
                               { props.totalquantityofproducts }
                            </span>
                        </div> */}
                        <div className="pendingList-div_first_right_nar" >
                            <span className="pendingList-div_first_right_nar_1" >
                                Measurement Scale :
                            </span>
                            <span className="pendingList-div_first_right_nar_2" >
                               { props.mesurementscale }
                            </span>
                        </div>
                        <div className="pendingList-div_first_right_nar" >
                            <span className="pendingList-div_first_right_nar_1" >
                                Unit Price :
                            </span>
                            <span className="pendingList-div_first_right_nar_2" >
                                 ₦ {' ' + props.price }
                            </span>
                        </div>
                        <div className="pendingList-div_first_right_nar" >
                            <span className="pendingList-div_first_right_nar_1" >
                                Total Number Of Orders :
                            </span>
                            <span className="pendingList-div_first_right_nar_2" >
                                { props.quantityordered + ' ' + props.mesurementscale }
                            </span>
                        </div>
              </div>
              <div className="pendingList-div_second" >  
                    <Link to={props.to} className="pendingList-div_second_btn" onClick={ props.OpenDetails } >
                        View All Orders
                    </Link>
              </div>
          </div>
      );

}


export const ListOrders = (props) => {

 return <div className="Penddding_products_li" > 
{/* 
        <div className="Penddding_products_li-first" >
            <div className="Penddding_products_li-first-1" >
            <Svg 
                className="Penddding_products_li-first-1-ic"
                href="contact.svg#icon-person"
            />
            </div>
            <div className="Penddding_products_li-first-2" >
                <span className="Penddding_products_li-first-2-txt" > Afolani Olabisi </span>
            </div>
        </div> */}


        <div className="Penddding_products_li-information" >
            <div className="Penddding_products_li-orderInformation" >
                <div className="Penddding_products_li-orderInformation-top" >
                    Buyer Information
                </div>
                <div className="Penddding_products_li-orderInformation-div" >
                    <span className="Penddding_products_li-orderInformation-div-1" >
                        Name :
                    </span>
                    <span className="Penddding_products_li-orderInformation-div-2" >
                         {'Afolabi Olabisi' }
                    </span>
                </div>
                <div className="Penddding_products_li-orderInformation-div" >
                    <span className="Penddding_products_li-orderInformation-div-1" >
                        Email : 
                    </span>
                    <span className="Penddding_products_li-orderInformation-div-2" >
                        {'dami@gmail.com' }
                    </span>
                </div>
                <div className="Penddding_products_li-orderInformation-div" >
                    <span className="Penddding_products_li-orderInformation-div-1" >
                        Phone Number : 
                    </span>
                    <span className="Penddding_products_li-orderInformation-div-2" >
                        090567890
                    </span>
                </div>
            </div>


            <div className="Penddding_products_li-orderInformation" >
                <div className="Penddding_products_li-orderInformation-top" >
                    Order Information
                </div>
                <div className="Penddding_products_li-orderInformation-div" >
                    <span className="Penddding_products_li-orderInformation-div-1" >
                        Amount of { props.measurement_scale } Ordered : 
                    </span>
                    <span className="Penddding_products_li-orderInformation-div-2" >
                        { ' ' + props.quantityOrdered + ' ' + props.measurement_scale }
                    </span>
                </div>
                <div className="Penddding_products_li-orderInformation-div" >
                    <span className="Penddding_products_li-orderInformation-div-1" >
                        Price ( { '₦' + props.Unitprice } x { props.quantityOrdered } ) : 
                    </span>
                    <span className="Penddding_products_li-orderInformation-div-2" >
                        ₦ {props.TotalQuantitycost}
                    </span>
                </div>
                <div className="Penddding_products_li-orderInformation-div" >
                    <span className="Penddding_products_li-orderInformation-div-1" >
                        Order Status : 
                    </span>
                    <span className="Penddding_products_li-orderInformation-div-2" >
                        {' ' + props.orderstatus}
                    </span>
                </div>
            </div>


            <div className="Penddding_products_li-orderInformation" >
                <div className="Penddding_products_li-orderInformation-top" >
                    Delivery Information
                </div>
                <div className="Penddding_products_li-orderInformation-div" >
                    <span className="Penddding_products_li-orderInformation-div-1" >
                        Mode of delivery : 
                    </span>
                    <span className="Penddding_products_li-orderInformation-div-2" >
                        { ' ' + props.ModeofDelivery }
                    </span>
                </div>
                <div className="Penddding_products_li-orderInformation-div" >
                    <span className="Penddding_products_li-orderInformation-div-1" >
                        State :
                    </span>
                    <span className="Penddding_products_li-orderInformation-div-2" >
                        Oyo
                    </span>
                </div>
                <div className="Penddding_products_li-orderInformation-div" >
                    <span className="Penddding_products_li-orderInformation-div-1" >
                        Local Government : 
                    </span>
                    <span className="Penddding_products_li-orderInformation-div-2" >
                        Ibarapa
                    </span>
                </div>
                <div className="Penddding_products_li-orderInformation-div" >
                    <span className="Penddding_products_li-orderInformation-div-1" >
                        Delivery Address : 
                    </span>
                    <span className="Penddding_products_li-orderInformation-div-2" >
                        { ' ' } Plot 33, Abubakar Tafawa Balewa Way
                        Central Business District,
                        Cadastral Zone,
                        Abuja, Federal Capital Territory,
                        Nigeria
                    </span>
                </div>
            </div>

            <div className="Penddding_products_li-change" >
                <button className="Penddding_products_li-change-btn"  onClick={props.change} >
                    change order status to in transit
                </button>
            </div>

        </div>

                                         
    </div>

}