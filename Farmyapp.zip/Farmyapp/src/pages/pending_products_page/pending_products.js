import React, { useState, useContext, useEffect } from 'react';
import {PendingList} from './PendingList/pendinglist';
import Store from '../../store/managementstore/managementstore';
import { Link } from 'react-router-dom';
import Axios from 'axios';
import Deliveryman from './delivery-man.png';
import Business from './business.png';
import LoadingPage from '../../foods/components/loading/loading';
import OppsPage from '../../foods/components/oppspage/oppspage';
import ProfileHeader from '../../foods/layout_components/profile_header/profile_header';



const PendingProductPage = (props) => {

    const context = useContext(Store)

    const [ Loadingpage , setLoadingpage ] = useState(false)
    const [ Errorpage , setErrorpage ] = useState(false)

    const [ AllRawproducts , setAllRawproducts ] = useState(null)
    const [ AllFiniproducts , setAllFiniproducts ] = useState(null)
    const [ NoproductPending , setNoproductPending ] = useState(false)

    useEffect( () => {

        setLoadingpage(true)
        setErrorpage(false)

        if ( context.User_id !== null ) {
            getdataHandler()
        }

// eslint-disable-next-line
    } , [context.User_id] )



    const getdataHandler = () => {

        Axios({
            method: 'GET',
            url:'/account/users/' + context.User_id + '/' , 
        }).then( response => {
            if( response.data.products.length > 0  ){
                setLoadingpage(false)
                setErrorpage(false)
                setAllRawproducts(response.data.products)    
            }else{
                setLoadingpage(false)
                setErrorpage(false)
                setNoproductPending(true)
            }
            
        } ).catch(
            e => {
                setLoadingpage(false)
                setErrorpage(false)
            }
        );

    }



    if( AllRawproducts && AllFiniproducts === null ){

        var allHave = []

        for (let p = 0; p < AllRawproducts.length; p++) {
            
            if( AllRawproducts[p].itemOrdered.length > 0 ){
                allHave.push(AllRawproducts[p])
            }

        }

        setAllFiniproducts(allHave)

    }

    const goTofull = (id) => {

        props.history.push('/allordersfull' + id)

    }


 

    if ( !AllRawproducts && NoproductPending ) {
        var toti = <div className="Penddding_products_page_empty" >
                            <img src={Business} alt="" className="Penddding_products_page_empty_img" />
                            <div className="Penddding_products_page_empty_text" > You don't have a product currently on sale  </div>
                            <Link to="/sell" className="Penddding_products_page_empty_btn">
                                sell a product
                            </Link>
                    </div>
    }else{

        if( AllFiniproducts ){

            if( AllFiniproducts.length < 1 ){
                toti =  <div className="Penddding_products_page_empty" >
                                <img src={Deliveryman} alt="" className="Penddding_products_page_empty_img" />
                                <div className="Penddding_products_page_empty_text" > 
                                    None of your product have been Ordered for
                                </div>
                                <Link to="/myproducts" className="Penddding_products_page_empty_btn">
                                    View Products
                                </Link>
                        </div>
            }else{
                 toti = AllFiniproducts.map( prod => {
            
                    // if( prod.itemOrdered.length > 0 ){
            
                        var pendingNumber = 0
                        var intransitNumber = 0
                        var deliveredNumber = 0
            
                        for (let u = 0; u < prod.itemOrdered.length; u++) {
                            
                            if( prod.itemOrdered[u].status === 'paid' ){
                                pendingNumber = pendingNumber + 1
                            }
                            if( prod.itemOrdered[u].status === 'in_transit' ){
                                intransitNumber = intransitNumber + 1
                            }
                            if( prod.itemOrdered[u].status === 'delivered' ){
                                deliveredNumber = deliveredNumber + 1
                            }
            
                        }
            
                        return ( <PendingList
                                    key={prod.id}
                                    firstimage = { 'https://farmyapp.xyz' + prod.product_img1 }
                                    productname = { prod.product_name }
                                    product_description = { prod.description } 
                                    quantityavailable = { prod.quantity_remaining ? prod.quantity_remaining : prod.quantity_available }
                                    mesurementscale = { prod.measurement_scale }
                                    quantityordered = { pendingNumber + intransitNumber + deliveredNumber }
                                    pendingorders={ pendingNumber }
                                    deliveredOrders={ deliveredNumber }
                                    in_transitorders={ intransitNumber }
                                    OpenDetails = { () => goTofull(prod.id) } /> )
                } )
            }

        }

    }







      const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }
    
    
      if( Loadingpage && !toti && !Errorpage ){
        var what_to_return = <LoadingPage/>
      }else{
        if ( !Loadingpage && Errorpage && !toti ) {
          what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
          if ( !Loadingpage && !Errorpage && toti ) {
            what_to_return = <div className="Penddding_products_page"  >
                
    
                                    <div className="Penddding_products_page_top" >
                                        My Products Ordered
                                    </div>
                                    <div className="Penddding_products_page_mid" >
                                            { toti }
                                    </div>


                              </div>

          }
        }
      }








      return ( 

        

          <>

                <ProfileHeader
                    title="My Products Orders"
                    goback={ goBack }
                />

                {what_to_return}

          </>
      );

}

export default PendingProductPage;