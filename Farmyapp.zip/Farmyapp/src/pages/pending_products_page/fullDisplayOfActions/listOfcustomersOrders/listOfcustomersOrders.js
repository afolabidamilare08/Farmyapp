import React from 'react';

const ListOfCustomersOrders = (props) => {

      return ( 
          <div className="listOfcustomersOrders-div" >

              <div className="listOfcustomersOrders-div-top" >
                  <div className="listOfcustomersOrders-div-top-1" >
                      Order Status
                  </div>
                  <div className="listOfcustomersOrders-div-top-2" style={{backgroundColor:props.statusbackground}} >
                     { props.status }
                  </div>
              </div>

              <div style={{padding:'1rem'}} >

              <div className="listOfcustomersOrders-div_sec" >
                  <span className="listOfcustomersOrders-div_sec-1" >
                      Customer :
                  </span>
                  <span className="listOfcustomersOrders-div_sec-2" >
                      { props.first_name + ' ' + props.last_name } 
                  </span>
              </div>
              <div className="listOfcustomersOrders-div_sec" >
                  <span className="listOfcustomersOrders-div_sec-1" >
                      Product Name :
                  </span>
                  <span className="listOfcustomersOrders-div_sec-2" >
                      { props.product_name }
                  </span>
              </div>
              <div className="listOfcustomersOrders-div_sec" >
                  <span className="listOfcustomersOrders-div_sec-1" >
                      Quantity Ordered :
                  </span>
                  <span className="listOfcustomersOrders-div_sec-2" >
                      { props.quantity_ordered } { props.measurement_scale }
                  </span>
              </div>
              <div className="listOfcustomersOrders-div_sec" >
                  <span className="listOfcustomersOrders-div_sec-1" >
                      Total Price :
                  </span>
                  <span className="listOfcustomersOrders-div_sec-2" >
                        ₦ { props.total_price }
                  </span>
              </div>
              <div className="listOfcustomersOrders-div_sec" >
                  <span className="listOfcustomersOrders-div_sec-1" >
                      Order Status :
                  </span>
                  <span className="listOfcustomersOrders-div_sec-2" >
                      { props.status }
                  </span>
              </div>
              <div className="listOfcustomersOrders-div_sec" >
                  <span className="listOfcustomersOrders-div_sec-1" >
                      Phone Number :
                  </span>
                  <span className="listOfcustomersOrders-div_sec-2" >
                      { props.phone_number }
                  </span>
              </div>
              <div className="listOfcustomersOrders-div_sec" >
                  <span className="listOfcustomersOrders-div_sec-1" >
                      Email Address :
                  </span>
                  <span className="listOfcustomersOrders-div_sec-2" >
                      { props.email_address }
                  </span>
              </div>
              <div className="listOfcustomersOrders-div_sec" >
                  <span className="listOfcustomersOrders-div_sec-1" >
                      State :
                  </span>
                  <span className="listOfcustomersOrders-div_sec-2" >
                      Oyo
                  </span>
              </div>
              <div className="listOfcustomersOrders-div_sec" >
                  <span className="listOfcustomersOrders-div_sec-1" >
                      Address :
                  </span>
                  <span className="listOfcustomersOrders-div_sec-2" >
                  </span>
              </div>
              <div className="listOfcustomersOrders-div-address" >

              eliever to
                    thank and praise God daily. In Psalm 100:4 we told, 
                    Enter His gates with thanksgiving, and into His courts with praise,
                     However, basically we praise God for Who He is and thank 
                     Him for what He has done or promise
              </div>
              <div className="listOfcustomerChange" >
                  { props.pending ? <button className="listOfcustomerChange_btn" onClick={props.pending} >
                        Change order status to in transit
                  </button> : null }
              </div>
              </div>
          </div>
      );

}

export default ListOfCustomersOrders;