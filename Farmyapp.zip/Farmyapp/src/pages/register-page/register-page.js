import React,{useState} from 'react';
import Registertemp from '../../component/register/register_temp';
import Axios from 'axios';
import Footerdiv from '../../layout/footer/footer';
import TopbannerDiv from '../../component/utilities/top-banner-msg/topbannermsg';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';


const Registerpage = (props) => {

  const [scroll,setscroll] = useState(true)

  const [ errormessage , seterrormessage ] = useState({
    status:false,
    msg:'',
    bgColor:''
  })

  const [ loading , setloading ] = useState(false)

  const [ registerdata , setregisterdata ] = useState({
    first_name:'',
    last_name:'',
    user_name:'',
    email_address:'',
    password:'',
    confirm_password:''
  })

  const sendregisterdataHandler = (e) => {

    e.preventDefault()
    seterrormessage({
      ...errormessage,
      status:false
    }) 
    setloading(true)

    if( registerdata.first_name === '' || registerdata.last_name === '' || registerdata.user_name === '' || registerdata.email_address === '' || registerdata.password === '' || registerdata.confirm_password === '' ){
      setloading(false)
      seterrormessage({
        status:true,
        msg:'All fileds should be filled',
        bgColor:'red'
      })    }

    if( registerdata.password !== registerdata.confirm_password ){
      setloading(false)
      seterrormessage({
        status:true,
        msg:'Password and Confirm Password should be the same',
        bgColor:'red' 
      })
    }

    if( (registerdata.first_name !== '' && registerdata.last_name !== '' && registerdata.user_name !== '' && registerdata.email_address !== '' && registerdata.password !== '' && registerdata.confirm_password !== '') && ( registerdata.password === registerdata.confirm_password ) ){

      var postableData = {
        first_name:registerdata.first_name,
        last_name:registerdata.last_name,
        username:registerdata.user_name,
        email:registerdata.email_address,
        password:registerdata.password
      }

      Axios.post('account/user/',postableData)
      .then( response => {
        setloading(false)
        seterrormessage({
          ...errormessage,
          status:false
          })

        props.history.push('/signin')

        setregisterdata({
          first_name:'',
          last_name:'',
          user_name:'',
          email_address:'',
          password:'',
          confirm_password:''
        })

      } ).catch( (error) => {
        setloading(false)
        if(error.response){

            if(error.response.data.email){
              seterrormessage({
                status:true,
                msg:error.response.data.email[0],
                bgColor:'red'
              })
            }

            if(error.response.data.username){
              seterrormessage({
                status:true,
                msg:error.response.data.username[0],
                bgColor:'red'
              })
            }

        }else{
          seterrormessage({
            status:true,
            msg:"Something Went Wrong",
            bgColor:'red'
          })
        }
    } );

    }

  }

  if( scroll ){
    var lam = window.scrollTo(1,1)
    setscroll(false)
}

  if( loading ){
    var btnIcon = <BtnSpin bgColor="white" />
  }else{
    btnIcon = "sign up"
  }

      return (

        <>

        <TopbannerDiv 
        
        show={ errormessage.status }
        closeshow={ () => seterrormessage({...errormessage,status:false}) }
        message={ errormessage.msg }
        backgroundcolor={ errormessage.bgColor }  

        />

        <div className="register-page-div" >

            {lam}

            <Registertemp
             firstnamevalue={registerdata.first_name}
             firstnameonchange={ (event) => setregisterdata({ ...registerdata , first_name:event.target.value }) }
             lastnamevalue={registerdata.last_name}
             lastnameonchange={ (event) => setregisterdata({ ...registerdata , last_name:event.target.value }) }
             usernamevalue={registerdata.user_name}
             usernameonchange={ (event) => setregisterdata({ ...registerdata , user_name:event.target.value }) }
             emailvalue={registerdata.email_address}
             emailonchange={ (event) => setregisterdata({ ...registerdata , email_address:event.target.value }) }
             passwordvalue={registerdata.password}
             passwordonchange={ (event) => setregisterdata({ ...registerdata , password:event.target.value }) }
             confirmpasswordvalue={registerdata.confirm_password}
             confirmpasswordonchange={ (event) => setregisterdata({ ...registerdata , confirm_password:event.target.value }) }
             register={sendregisterdataHandler}
             disabled={ loading }
             action={btnIcon} />

        </div>

        <Footerdiv/>

        </>

      );

}

export default Registerpage;
