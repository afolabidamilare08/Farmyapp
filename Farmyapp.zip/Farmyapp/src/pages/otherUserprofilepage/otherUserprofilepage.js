import React, { useState, useEffect } from 'react';
import OtheruserProfile from '../../component/otherUserprofile/otherUserprofile';
import Axios from 'axios';
import Buisness from './business.png';
import Hand from './hand.png';
import FooterDiv from '../../layout/footer/footer';
import Product from '../../component/product_template/product_template';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';

const OtherUserprofilepage = (props) => {

        const [ UserDetails1 , setUserDetails1 ] = useState(null)
        const [ UserDetails12 , setUserDetails12 ] = useState(null)
        const [ whichtoshow , setwhichtoshow ] = useState('products')
        const  Userid = props.match.params.id 

        useEffect( () => {
            Axios.get( '/account/users/' + Userid + '/' ).then(
                response => {
                    // console.log(response.data)
                    setUserDetails1(response.data)
                    Axios.get('/account/userpro/' + Userid  + '/').then(
                        response => {
                            // console.log('123',response.data)
                            setUserDetails12(response.data.pro)
                        }
                    ).catch()
                }
            ).catch()
        } , [Userid] )


        // var val = true

        // if (val){
        //     var sam =  window.scrollTo(1,1)
        //    }

           const goback = () => {
               props.history.goBack()
           }


           if( UserDetails1 ){

                if( UserDetails1.products ){

                    if( UserDetails1.products.length < 1 ){
                        var Showittothem = <div className="Penddding_products_page_empty" >
                                                    <img src={Buisness} alt="" className="Penddding_products_page_empty_img" />
                                                    <div className="Penddding_products_page_empty_text" > I Have No Products For Sale  </div>
                                            </div>
                    }else{

                        var checking =  []

                        for (let h = 0; h < UserDetails1.products.length; h++) {
                            
                            var prodit = UserDetails1.products[h]

                            if( prodit.quantity_remaining !== 0  ){
                                checking.push(prodit)
                            }
                            
                        }

                        if( checking.length < 1 ){
                            Showittothem = <div className="Penddding_products_page_empty" >
                                                <img src={Buisness} alt="" className="Penddding_products_page_empty_img" />
                                                <div className="Penddding_products_page_empty_text" > I Have No Products For Sale  </div>
                                           </div>
                        }else{
                            Showittothem =   UserDetails1.products.map( ( product , index) => {
     
                                if( product.quantity_remaining !== 0 ){
                                    return <Product
                                    img={ 'http://127.0.0.1:8000' + product.product_img1}
                                    product={product.product_name}
                                    key={product.product_name}
                                    product_des={product.description}
                                    add_to_cart
                                    lga={product.address[0].lga}
                                    state={product.address[0].state}
                                    action="Add To Cart"
                                    price={product.price}
                                    kg={product.measurement_scale}
                                        to={'/product' + product.slug + ":" + product.id } />
                                }

                                return null
                            
                            }
                    
                            )
                        }

                    }

                }

                if( UserDetails1.services ){
                    if( UserDetails1.services.length < 1 ){
                        var Showittothem2 = <div className="Penddding_products_page_empty" >
                                                    <img src={Hand} alt="" className="Penddding_products_page_empty_img" />
                                                    <div className="Penddding_products_page_empty_text" > I Have No Service For Hire  </div>
                                            </div>
                    }else{

                            Showittothem2 =   UserDetails1.services.map( ( service , index) => {
     
                                return <Product
                                    img={ 'http://127.0.0.1:8000' + service.service_img1}
                                    product={service.service_name}
                                    key={service.service_name}
                                    product_des={service.description}
                                    add_to_cart
                                    lga={service.address[0].lga}
                                    state={service.address[0].state}
                                    action="Hire Me"
                                    price={service.price_per_hour}
                                    kg={ 'Hour' }
                                        to={'/fullserv' + service.slug + ":" + service.id } />
                                }
                            
                    
                            )
    

                    }
                }

             }

             if( whichtoshow === 'products' ){
                 var Letitshow = Showittothem
             }

             if( whichtoshow === 'services' ){
                 Letitshow = Showittothem2
            }

      return ( 
          <>
            {/* {sam} */}
            <div className="Otherprofilepage-page" >
                { UserDetails1 && UserDetails12 ?

                    <OtheruserProfile 
                    first_name={ UserDetails1 ? UserDetails1.first_name : '' }
                    last_name={ UserDetails1 ? UserDetails1.last_name : '' }
                    user_name={ UserDetails1 ? UserDetails1.username : '' }
                    email={ UserDetails1 ? UserDetails1.email : '' }
                    img={ UserDetails12 ? UserDetails12.profile_picture : '' }
                    phone_number={ UserDetails12 ? UserDetails12.phone_number : '' }
                    interests={ UserDetails12 ? UserDetails12.interests : '' }
                    languages_known={ UserDetails12 ? UserDetails12.languages_known : '' }
                    gender={ UserDetails12 ? UserDetails12.gender : 'Male' }
                    goBack={goback}
                    productlength={ UserDetails1 ? UserDetails1.products.length : '' }
                    servicelength={ UserDetails1 ? UserDetails1.services.length : '' }
                    bio={ UserDetails12 ? UserDetails12.bio : ''  }
                    allshow = { Letitshow }
                    showproducts={ () => setwhichtoshow('products') }
                    pcolor={ whichtoshow === 'products' ? 'gray' : '' }
                    scolor={ whichtoshow === 'services' ? 'gray' : '' }
                    showservices={ () => setwhichtoshow('services') }
                    />
            
                    : <BtnSpin bgColor="rgba(13, 194, 94, 0.986)" />

                }   
            </div>
            <FooterDiv/>
          </>
      );

}

export default OtherUserprofilepage;