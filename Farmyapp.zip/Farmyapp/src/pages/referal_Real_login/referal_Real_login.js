import React,{useState,useContext} from 'react';
import Login from '../../component/login/login';
import Axios from 'axios';
import Store from '../../store/managementstore/managementstore';
import Store2 from '../../store/managementstore/header_store';
import Footerdiv from '../../layout/footer/footer';
import Topbanner from '../../component/utilities/top-banner-msg/topbannermsg';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';

const ReferalRealLogin = (props) => {

      const context = useContext(Store)

      const context2 = useContext(Store2)

      const [scroll,setscroll] = useState(true)
      
      const [ showpassword , setshowpassword ] = useState(false)

      const [ loading , setloading ] = useState(false)

      const [ errormessage , seterrormessage ] = useState({
        status:false,
        msg:'',
        bgColor:''
      })

      const [ logindata , setlogindata ] = useState({
        user_name:'',
        password:''
      })



      if( scroll ){
        var lam = window.scrollTo(1,1)
        setscroll(false)
    }


      const usernameonchangeHandler = (event) => {
        var initialdata = {...logindata}
        setlogindata({...initialdata,user_name:event.target.value})
      }

      const passwordonchangeHandler = (event) => {
        var initialdata = {...logindata}
        setlogindata({...initialdata,password:event.target.value})
      }

      const showpasswordHandler = () => {
        var newdata = !showpassword
        setshowpassword(newdata)
      }

      const loginHandler = (e) => {

        e.preventDefault()

        seterrormessage({
          ...errormessage,
          status:false
        })        
        setloading(true)

        if( logindata.user_name === '' || logindata.password  === '' ){
          seterrormessage({
            status:true,
            msg:'All fileds should be filled',
            bgColor:'red'
          })
          setloading(false)
        }

        else{

          var postableData = {
            username:logindata.user_name,
            password:logindata.password
          }

          Axios.post('/account/login/',postableData)
          .then( response => {
            var data1 = response.data.token
            var data2 = response.data.id
            savedata(data1,data2)

            var number = Number(props.match.params.id)

            Axios.patch( '/account/profile/' + context.User_details.detail2.id + '/' , {referral:number} ).then(
              response => {
                setloading(false)
                seterrormessage(false)
    
                setlogindata({
                  user_name:'',
                  password:''
                })
    
                // props.history.goBack()
                props.history.push('/profile')
              }
            )

          } )
          .catch( (error) => {
            setloading(false)
            if(error.response){

                if(error.response.data.error){
                  seterrormessage({
                    status:true,
                    msg:'Invalid Username or password',
                    bgColor:'red'
                  })
                }
    
            }else{
              seterrormessage({
                status:true,
                msg:'Something Went Wrong',
                bgColor:'red'
              })
            }
        } );

        }

      }

      const savedata = (datas1,datas2) => {
        localStorage.setItem('farmyapp-tok',datas1)
        localStorage.setItem('farmyapp-userid',datas2)
        context2.addNotification()
        context.Loginhandler(datas1,datas2)
      }

      if( errormessage.status ){
        var icn = 'Sign In'
      }if( loading ){
        icn = <BtnSpin bgColor="white" />
      }if( !errormessage.status && !loading ){
        icn = 'Sign In'
      }

      if(showpassword){
        var show = "text"
      }else{
        show = "password"
      }

      return (

        <>

      <Topbanner 
          show={ errormessage.status }
          closeshow={ () => seterrormessage({...errormessage,status:false}) }
          message={ errormessage.msg } 
          backgroundcolor={ errormessage.bgColor }    />

        <div className="loginpage" >

            <Login
             usernamevalue={logindata.user_name}
             usernameonchange={usernameonchangeHandler}
             passwordvalue={logindata.password}
             passwordonchange={passwordonchangeHandler}
             login={loginHandler}
             action={icn}
             type={show}
             disabled={ loading }
             showpassword={showpasswordHandler} />

{lam}

        </div>

        <Footerdiv/>

        </>

      );

}

export default ReferalRealLogin;
