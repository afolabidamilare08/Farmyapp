import React from 'react';

const ServiceHiredList =  (props) => {

      return ( 
          <div className="ServiceHiredList" style={{width:props.width}} >
            <div className="ServiceHiredList-top" >
                <div className="ServiceHiredList-top-1" >
                    <div className="ServiceHiredList-top-1-img" >
                        { props.img ? <img alt="" src={props.img} className="ServiceHiredList-top-1-img-img" /> : null }
                    </div>
                    <div className="ServiceHiredList-top-1-name" > { props.serviceName } </div>
                </div>
                <div className="ServiceHiredList-top-2" style={{ 
                      backgroundColor:props.bgcolor
                 }} >
                    {props.status}
                </div>
            </div>
          
            <div style={{ padding:'1rem' , marginTop:'1rem' }} >

            <div className="FinalchkServ-div-main-main-location" >
                              { props.address }

                              <div className="FinalchkServ-div-main-main-location-inside" >
                                    { props.lga } , { props.state }
                              </div>

            </div>

            </div>

            <div className="ServiceHiredList-mid" style={{ marginBottom: props.showTodelivered ? '' : '1rem' }} >

            <div style={{ display:'flex' ,  width:'100%' , justifyContent:'space-evenly' }} > 
                              <div>
                                    <div className="FinalchkServ-div-main-main-title" >
                                    Service Contact
                                    </div>

                                    <div className="FinalchkServ-div-main-main-contact" >
                                          { props.HnAme } 
                                          <br/>
                                          { props.Hnphone }
                                          <br/>
                                          {/* adeey@gmail.com */}

                                    </div>
                              </div>

                              <div>
                                    <div className="FinalchkServ-div-main-main-title" >
                                          Opening Hours
                                    </div>

                                    <div className="FinalchkServ-div-main-main-duration"  style={{ textAlign:'center' }}  >
                                          {props.openday}
                                          <br/>
                                          {props.time}
                                    </div>
                              </div>

                              <div>
                                    <div className="FinalchkServ-div-main-main-title" >
                                    Hire Duration
                                    </div>

                                    <div className="FinalchkServ-div-main-main-duration"  style={{ textAlign:'center' }} >
                                          {props.lengthit} Hours
                                    </div>
                              </div>

                        </div>

            </div>

            { props.showTodelivered ?  
            <div className="ServiceHiredList-btm" >
                <button className="ServiceHiredList-btm-btn" onClick={ props.changeStatus } > Change service status to done </button>
            </div> : null }

            { props.showTodservicing ?  
            <div className="ServiceHiredList-btm"  >
                <button className="ServiceHiredList-btm-btn" onClick={ props.changeStatus } style={{backgroundColor:'rgb(50, 127, 241)'}} > Change service status to servicing </button>
            </div> : null }

          </div>
      );

}

export default ServiceHiredList;