import React , { useState , useEffect , useContext } from 'react';
import ServiceHiredList from './serviceHiredList/serviceHiredlist';
import Store from '../../store/managementstore/managementstore';
import Axios from 'axios';
import TopbannerDiv from '../../component/utilities/top-banner-msg/topbannermsg';
import Customer from './customer-service.png';
import {Link} from 'react-router-dom';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';
import LoadingPage from '../../foods/components/loading/loading';
import OppsPage from '../../foods/components/oppspage/oppspage';
import ProfileHeader from '../../foods/layout_components/profile_header/profile_header';

const ServiceHiredpage = (props) => {

    const context = useContext(Store)

    const [ Loadingpage , setLoadingpage ] = useState(false)
    const [ Errorpage , setErrorpage ] = useState(false)

    const [ MySorders , setMySorders ] = useState(null)
    const [ openModal , setopenModal ] = useState(false)
    const [ serviceId , setserviceId ] = useState(null)
    const [ ratingNumber , setratingNumber ] = useState(null)
    const [ Fullstar , setFullstar ] = useState([
        { fill: 'lightgray' , id:1 },
        { fill: 'lightgray' , id:2 },
        { fill: 'lightgray' , id:3 },
        { fill: 'lightgray' , id:4 },
        { fill: 'lightgray' , id:5 }
    ])
    const [ Servicetoberated , setServicetoberated ] = useState(null)
    const [ message , setmessage ] = useState({
        status:false,
        bgcolor:'',
        msg:''
    })

    
    useEffect( () => {

        setLoadingpage(true)
        setErrorpage(false)

        Axios.get( '/account/users/' + context.User_id + '/' ).then(
            response => {
                setLoadingpage(false)
                setErrorpage(false)
                setMySorders(response.data.sorders)
            }
        ).catch(
            e => {
                setLoadingpage(false)
                setErrorpage(true)
            }
        )

    } , [ context.User_id ] )







      const ChangeStatusHandler = ( id ) => {

        setmessage({
            status:true,
            bgcolor:'orange',
            msg:'Updating Hire Status'
        })

        const OrderIndex = MySorders.findIndex( i => {
            return i.id === id
          } )

          var chosenOrder = MySorders[OrderIndex]


          Axios.patch( '/sorder/' + id + '/' , {status:'serviced'}).then(
              response => {
                  
                var currentOrder = {  ...chosenOrder , status:'serviced' }

                var Intransit = [ ...MySorders ]

                Intransit.splice(OrderIndex,1,currentOrder)

                setMySorders(Intransit)

                setmessage({
                    status:true,
                    bgcolor:'rgba(13, 194, 94, 0.986)',
                    msg:'Hire Status Updated'
                })

                setopenModal(true)
                setServicetoberated(currentOrder.service.service_name)
                setserviceId(currentOrder.service.id)

              }
          )

      }










      

      if( MySorders ){
          if( MySorders.length < 1 ){
              var servit = <div className="Penddding_products_page_empty" >
                                <img src={Customer} alt="" className="Penddding_products_page_empty_img" />
                                <div className="Penddding_products_page_empty_text" > You Have Not Hired Any Service  </div>
                                <Link to="/services" className="Penddding_products_page_empty_btn">
                                    Hire Service
                                </Link>
                            </div>
          }else{
                servit =  MySorders.map( order => {

                    if( order.status === 'paid' ){
                        var status = {
                            bgcolor: 'orange',
                            txt:'pending'
                        }
                    }

                    if( order.status === 'created' ){
                         status = {
                            bgcolor: 'orange',
                            txt:'pending'
                        }
                    }

                    if( order.status === 'servicing' ){
                         status = {
                            bgcolor: 'rgb(50, 127, 241)',
                            txt:'servicing'
                        }
                    }

                    if( order.status === 'serviced' ){
                         status = {
                            bgcolor: 'rgba(13, 194, 94, 0.986)',
                            txt:'Serviced'
                        }
                    }

                    var op = order.prefered_time[0] + order.prefered_time[1]
                    var newop = Number(op)
        
                    
                    if( newop > 12 ){
                          var openingTrange = 'PM'
                          var openingTime = newop - 12
                      }else{
                          openingTrange = 'AM'
                          openingTime = newop
                      }
        

                    return <ServiceHiredList 
                                key={order.id}
                                serviceName={ order.service.service_name }
                                address={ order.address }
                                status={ status.txt }
                                bgcolor={ status.bgcolor }
                                hireduration={ order.day }
                                openday={order.day}
                                time={ openingTime + ' ' + openingTrange }
                                lengthit={ order.duration }
                                state={ order.state }
                                lga={ order.lga }
                                HnAme={ order.service.user.first_name + ' ' + order.service.user.last_name }
                                Hnphone={ order.service.user.pro.phone_number }
                                img={ 'https://farmyapp.xyz' + order.service.service_img1 }
                                changeStatus={ () => ChangeStatusHandler(order.id) }
                                showTodelivered={ order.status === 'serviced' || order.status === 'paid' || order.status === 'created' ? false : true }
                             />
                            } )
          }
      }



      const AddColortostar = ( number ) => {

        if( number === 1 ){
            setFullstar([
                { fill: 'rgba(13, 194, 94, 0.986)' , id:1 },
                { fill: 'lightgray' , id:2 },
                { fill: 'lightgray' , id:3 },
                { fill: 'lightgray' , id:4 },
                { fill: 'lightgray' , id:5 }
            ])
            setratingNumber(1)
        }

        if( number === 2 ){
            setFullstar([
                { fill: 'rgba(13, 194, 94, 0.986)' , id:1 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:2 },
                { fill: 'lightgray' , id:3 },
                { fill: 'lightgray' , id:4 },
                { fill: 'lightgray' , id:5 }
            ])
            setratingNumber(2)
        }

        if( number === 3 ){
            setFullstar([
                { fill: 'rgba(13, 194, 94, 0.986)' , id:1 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:2 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:3 },
                { fill: 'lightgray' , id:4 },
                { fill: 'lightgray' , id:5 }
            ])
            setratingNumber(3)
        }

        if( number === 4 ){
            setFullstar([
                { fill: 'rgba(13, 194, 94, 0.986)' , id:1 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:2 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:3 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:4 },
                { fill: 'lightgray' , id:5 }
            ])
            setratingNumber(4)
        }

        if( number === 5 ){
            setFullstar([
                { fill: 'rgba(13, 194, 94, 0.986)' , id:1 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:2 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:3 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:4 },
                { fill: 'rgba(13, 194, 94, 0.986)' , id:5 }
            ])
            setratingNumber(5)
        }

    }




    const Finalrating = () => {

        if( ratingNumber && serviceId && Servicetoberated ){

            Axios.post( '/service/' + serviceId + '/rate_service/' , {stars:ratingNumber} ).then(
                response => {
                    setFullstar([
                        { fill: 'lightgray' , id:1 },
                        { fill: 'lightgray' , id:2 },
                        { fill: 'lightgray' , id:3 },
                        { fill: 'lightgray' , id:4 },
                        { fill: 'lightgray' , id:5 }
                    ])

                    setopenModal(false)
                    setServicetoberated(null)
                    setserviceId(null)
                    setratingNumber(null)

                    setmessage({
                        status:true,
                        bgcolor:'rgba(13, 194, 94, 0.986)',
                        msg:' Service Was Rated Successfully ' 
                    })
                }
            )

        }

    }














      const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }
    
    
      if( Loadingpage && !MySorders && !Errorpage ){
        var what_to_return = <LoadingPage/>
      }else{
        if ( !Loadingpage && Errorpage && !MySorders ) {
          what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
          if ( !Loadingpage && !Errorpage && MySorders ) {
            what_to_return =    <div className="Service_hired-page" >
                                    <div className="Service_hired-page-top" > Services Hired </div>
                                    <div className="Service_hired-page-body" >
                                    { MySorders ? 
                                            servit
                                    : <BtnSpin bgColor="rgba(13, 194, 94, 0.986)" /> }
                                    </div>
                                </div>
          }
        }
      }








      return ( 
          <>
         
            <TopbannerDiv 
                show={ message.status }
                closeshow={ () => setmessage({...message,status:false}) }
                backgroundcolor={ message.bgcolor }
                message={ message.msg } />

            {/* <Backdrop
                show={ openModal } >
                                 
                    <div className="FullOrderDiv-div-page-Addstar" >
                        <div className="FullOrderDiv-div-page-Addstar-top" > Rate This Service : </div>
                        <div className="FullOrderDiv-div-page-Addstar-prodName" > { Servicetoberated ? Servicetoberated : '' } </div>
                        <div className="FullOrderDiv-div-page-Addstar-main" > 
                            { Fullstar.map( star => {
                                return  <Svg 
                                key={star}
                                style={star.fill}
                                onClick={ () => AddColortostar(star.id) }
                                className="FullOrderDiv-div-page-Addstar-main-ic"
                                href="opps.svg#icon-star-full" />
                            } ) }
                        </div>
                        <div className="FullOrderDiv-div-page-Addstar-sbt" >
                            <button className="FullOrderDiv-div-page-Addstar-sbt-ic" onClick={Finalrating} > rate </button>
                        </div>
                    </div> 

        </Backdrop>   */}

            <ProfileHeader
              title="Services Order"
              goback={ goBack }
            />

            {what_to_return}

          </>
      );

}

export default ServiceHiredpage;