import React from 'react';
import { useSearch } from './useSearch';
import Producttemp from '../../component/product_template/product_template';
import Backdrop from '../../component/utilities/Backdrop/backdrop';
import Footerdiv from '../../layout/footer/footer';
import { Link } from 'react-router-dom';
import SearchImg from '../../component/utilities/Search2.png';

const Searchpage = (props) => {

    const chk = props.match.params.query
    const mainOffset = props.match.params.offset
    
    if( props.match.params.address ){
        var add = props.match.params.address
    }else{
         add = ''
    }


   const [ result ] = useSearch( chk , add , mainOffset )





   if( result ){


       if( result.results.length !== 0 ){
           var allresult = result.results.map( product => {
               return <Producttemp
               img={product.product_img1}
               key={product.id}
               product={product.product_name}
               product_des={product.description}
               add_to_cart
               lga={product.address[0].lga}
               state={product.address[0].state}
               action='Add To Cart'
               price={product.price}
               kg={product.measurement_scale}
               to={'/product' + product.slug + ":" + product.id } />
           } )

           var paglink = []

           for (let f = 0; f < (result.count/24) ; f++) {   
            //    console.log( f ) 
               paglink.push( { no: 1 + f  , limit: 1 , offset: 24 * f } )
           }

        }else{
            allresult = <div className="noresult-img" >
                <img className="noresult-img-img" alt="" src={SearchImg} />
            </div>
        }
   }else{
       allresult = <Backdrop show={true} />
   }

   if( result ){

    var Hope = []

    if(result.count > 1 ){
      Hope.push( { result: result.count , query: chk} )
    }else{
        Hope.push( { result: result.count , query: chk} )
    }

   }


      return ( 

        <>

        <div className="searchpage-box" >

            <div className="searchpage-box-msg" >
                { Hope ? Hope.map( item => {
                    
                    if( item.result > 0 ){
                        var next = ''
                    }else{
                        next = 'try searching with another name'
                    }

                    return <div> Found <span style={{ fontWeight:'700' }} > { item.result } </span> Results Related With <span style={{ fontWeight:'700' }} > { item.query } </span> {next} </div>
                } ) : '' }
            </div>

            <div className="searchpage-box-result" >
                {allresult}
            </div>

            <div className="pagination_div" >
                { paglink ? 
                         
                         paglink.map( pag => {

                            if( pag.no === 1 ){
                                if( props.match.params.address ){
                                    return <Link className="pagination_div_link" to={ '/search' + chk + ':' + add + ':' + 0 } > 
                                                { pag.no }
                                            </Link>
                                }else{
                                    return <Link className="pagination_div_link" to={ '/search' + chk + ':' + 0 } > 
                                                { pag.no }
                                            </Link>
                                }
                            }else{

                                if( props.match.params.address ){
                                    return <Link className="pagination_div_link" to={ '/search' + chk + ':' + add + ':' + pag.offset } > 
                                                { pag.no }
                                            </Link>
                                }else{
                                    return <Link className="pagination_div_link" to={ '/search' + chk + ':' + pag.offset } > 
                                                { pag.no }
                                            </Link>
                                }
                            }

                         } )

                      : null   }
                </div>


        </div>

            <Footerdiv/>

        </>

      );

}

export default Searchpage;