import { useState , useEffect } from 'react';
import Axios from 'axios';


export const usePrviewlogic = ( id , slug , ) => {

    const [ loadedproduct , setloadedproduct ] = useState(null)
    const [ first_previmg , set_firstprevimg ] = useState(null)




  
    // logic for getting the data for that particular product
    //============================================================
    useEffect( () => {
          
      Axios.get( '/product/' + id + '/' ).then(
        response => {
          setloadedproduct(response.data)
          set_firstprevimg(response.data.product_img1)
        }
      );
  
    } , [id,slug] )

    //////////////////////
    //==============================================================




    
    return [ loadedproduct , first_previmg ]

} 
