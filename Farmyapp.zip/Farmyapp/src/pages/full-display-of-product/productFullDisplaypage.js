import React,{useState,useContext} from 'react';
import ProductAndDescbox from '../../component/Product-fullpage-components/product_and_info_box/product_and_info_box';
import Modal from '../../component/Product-fullpage-components/fulldetail-modal/fulldetmodal';
import {usePrviewlogic} from './uselogicforproductdetview';
import Store from '../../store/managementstore/managementstore';
import Commentdiv from '../../component/Product-fullpage-components/coment-div/comment-div';
import Backdrop from '../../component/utilities/Backdrop/backdrop';
import Footerdiv from '../../layout/footer/footer';
import GoBackDiv from '../../component/utilities/goBack/goback';
import Svg from '../../component/utilities/Svg';


const Productfullpage = (props) => {

  const val = true


  const [productImage , setproductImage] = useState(null)
  const [ Comments , setComments ] = useState(null)
  const [ openimgbigprev , setopenimgbigprev ] = useState( { status: false , image: '' } )

  const context = useContext(Store)  
  
  var id = props.match.params.id
  var slug = props.match.params.slug

  
  const [ loadedproduct , first_img  ] = usePrviewlogic( id , slug )



  const notSigninPusher = () => {
    props.history.push('/signin')
  }


  

  
  
  // logic for the image swicthing 

    const changedisplayimage1 = () => {
      setproductImage(loadedproduct.product_img1)
    }

    const changedisplayimage2 = () => {
        setproductImage(loadedproduct.product_img2)
    }

    const changedisplayimage3 = () => {
      setproductImage(loadedproduct.product_img3)
  }

  // ///////////////////////////////
  // ==================================================================






        // logic to check if user is loggedin or not
        //======================================================

        const checktokenkHandler = () => {

          const token = context.Token
          const useeid = context.User_id

          if( !token && !useeid ){
            notSigninPusher()
          }
          else{
            context.open_add_product_slideHandler(true)
          }

        }
        /////////////////////////////
        //=====================================================



    if( loadedproduct ){
    
    if( loadedproduct.comments.length !== 0 && Comments === null ){
      
      setComments( loadedproduct.comments )

    }

    if (val){
     var sam =  window.scrollTo(1,1)
    }

    if ( loadedproduct ) {
      
        var ratingNumber = loadedproduct.avg_rating

        var ArrayStars = []

        var namwir = String(ratingNumber)

        if( namwir.length > 1 ){

            var firstNumber = Number(namwir[0])
            var putIt = String(namwir[0]) + '.' + String(namwir[2])

            for (let l = 0; l < firstNumber ; l++) {
  
              ArrayStars.push( { 
                href:'opps.svg#icon-star-full' , 
                fill:'rgba(13, 194, 94, 0.986)'
               } )
              
            }

            ArrayStars.push({
              href:'opps.svg#icon-star-half' , 
              fill:'rgba(13, 194, 94, 0.986)'
            })

            for (let j = firstNumber + 1 ; j < 5 ; j++) {
    
              ArrayStars.push( { 
                href:'opps.svg#icon-star-empty' , 
                fill:'rgba(13, 194, 94, 0.986)'
              } )
              
            }

        }


        if( namwir.length === 1 ){

          putIt = ratingNumber

          for (let l = 0; l < ratingNumber ; l++) {
  
            ArrayStars.push( { 
              href:'opps.svg#icon-star-full' , 
              fill:'rgba(13, 194, 94, 0.986)'
             } )
            
          }
  
          for (let j = ratingNumber; j < 5 ; j++) {
    
            ArrayStars.push( { 
              href:'opps.svg#icon-star-empty' , 
              fill:'rgba(13, 194, 94, 0.986)'
            } )
            
          }
        }



        var Wesss =                     ArrayStars.map( ( star , index ) => {
          return  <Svg
                    key={index}
                    className="productDetailBox-div-seller-rating-ic-col"
                    href={ star.href } /> 
        } )

    }



    var show = <ProductAndDescbox
                  key={loadedproduct.product_name}
                  previewimage={ productImage === null ? first_img : productImage }
                  ctrimg1={loadedproduct.product_img1}
                  ctrimg2={loadedproduct.product_img2}
                  ctrimg3={loadedproduct.product_img3}
                  chg1={changedisplayimage1}
                  chg2={changedisplayimage2}
                  chg3={changedisplayimage3}
                  productname={loadedproduct.product_name}
                  productdescription={loadedproduct.description}
                  productprice={loadedproduct.price}
                  productscale={loadedproduct.measurement_scale}
                  productavailable={ loadedproduct.quantity_remaining !== null ? loadedproduct.quantity_remaining : loadedproduct.quantity_available }
                  firstaddtocart={checktokenkHandler}
                  harvestdate={loadedproduct.harvest_date}
                  state={ loadedproduct.address[0].state }
                  lga={ loadedproduct.address[0].lga }
                  ratings={ 
                      Wesss 
                   }
                  ratenarrate={ <span style={{ fontSize:'1.3rem' , marginLeft:'1rem' , color:'#333' , fontWeight:'700' }} > { putIt } Avg Rating  </span> }
                  address={ loadedproduct.address[0].address }
                  openbigprev={ () => setopenimgbigprev({status:true,image: !productImage ? first_img : productImage }) }
                   />

  }else{
    show = <Backdrop show={true} />
  }

      return ( 
        <>

        {/* Modal for the display of the product image fully , u get me */}

          <Backdrop show={openimgbigprev.status} >
              <button className="big_img_close" onClick={ () => setopenimgbigprev({ ...openimgbigprev , status:false }) } >
                <Svg className="big_img_close-ic" href="sprite2.svg#icon-add" />
              </button>
              <div className="big_img-div" >
                  <img alt="" className="big_img-div_img" src={openimgbigprev.image} />
                  <div className="big_img_ctr" >
                  <div className="big_img_ctr_img" >
                      <img alt="" src={ loadedproduct ? loadedproduct.product_img1 : '' } onClick={ () => setopenimgbigprev( { ...openimgbigprev , image: loadedproduct ? loadedproduct.product_img1 : '' } ) } className="big_img_ctr_img_img" />
                  </div>
                  <div className="big_img_ctr_img" >
                      <img alt="" src={ loadedproduct ? loadedproduct.product_img2 : '' } onClick={ () => setopenimgbigprev( { ...openimgbigprev , image: loadedproduct ? loadedproduct.product_img2 : '' } ) } className="big_img_ctr_img_img" />
                  </div>
                  <div className="big_img_ctr_img" >
                      <img alt="" src={ loadedproduct ? loadedproduct.product_img3 : '' } onClick={ () => setopenimgbigprev( { ...openimgbigprev , image: loadedproduct ? loadedproduct.product_img3 : '' } ) } className="big_img_ctr_img_img" />
                  </div>
              </div>
              </div>

          </Backdrop>

        {/* /////////// */}

        <div className="Product-full-page-box" >

          {sam}

            {/*  Modal For the reply comment section and also the logic is there also  */}
            <Modal loaddetail={ loadedproduct } />
            {/* ///////////// */}

            {/* variable displaying th product itself */}
            {show}
            {/* /////////// */}

            {/* used to display the comment section when the product it self is really loaded
                notice that the logic for displaying it is not actually here  */}
            { loadedproduct ? 
              <Commentdiv 
                  comment_list={Comments}
                  product_slug={loadedproduct.slug}
                  product_id={loadedproduct.id}
                  notsignin={notSigninPusher}
              /> : null }
              {/* ///////////////////////// */}

    
              <GoBackDiv to={ () => props.history.goBack() } />

        </div>
        <Footerdiv/>
        </>
      );

}

export default Productfullpage;