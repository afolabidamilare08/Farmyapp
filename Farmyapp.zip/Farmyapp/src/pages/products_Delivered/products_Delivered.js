import React from 'react';

const ProductsDelivered = (props) => {

      return ( 
          <div>f;lne;vbEPRIVBE0Otbvqer 
              brqym6.4yi9l;.
              96-'99-]
              0=
              79[/t[yn08querv67 wfx5q   6ec9012kh-5ui'o.8]098]
              i7uo.,perhg7u wdx q5xs    4qwcdwh[t]ui;uop'yi,mpodsi6cA53Z
          </div>
      );

}

export default ProductsDelivered;