import React,{useState,useContext} from 'react';
import Svg from '../../component/utilities/Svg';
import Errormsg from '../../component/error/error';
import Axios from 'axios';
import Store from '../../store/managementstore/managementstore';
import Footerdiv from '../../layout/footer/footer';
import ResetPasswordDiv from '../../component/resetpassword/resetpassword';

const ResetPasswordPage = (props) => {

      const context = useContext(Store)

      const [ showpassword , setshowpassword ] = useState(false)

      const [ loading , setloading ] = useState(false)

      const [ errormessage , seterrormessage ] = useState(false)

      const [ logindata , setlogindata ] = useState({
        user_name:'',
        password:''
      })


      const usernameonchangeHandler = (event) => {
        var initialdata = {...logindata}
        setlogindata({...initialdata,user_name:event.target.value})
      }

      const passwordonchangeHandler = (event) => {
        var initialdata = {...logindata}
        setlogindata({...initialdata,password:event.target.value})
      }

      const showpasswordHandler = () => {
        var newdata = !showpassword
        setshowpassword(newdata)
      }

      const loginHandler = (e) => {

        e.preventDefault()

        seterrormessage(false)
        setloading(true)

        if( logindata.user_name === '' || logindata.password  === '' ){
          seterrormessage('All fileds should be filled')
          setloading(false)
        }

        else{

          var postableData = {
            username:logindata.user_name,
            password:logindata.password
          }

          Axios.post('/account/login/',postableData)
          .then( response => {
            var data1 = response.data.token
            var data2 = response.data.id
            savedata(data1,data2)

            setloading(false)
            seterrormessage(false)

            setlogindata({
              user_name:'',
              password:''
            })

            props.history.goBack()

          } )
          .catch( error => {
            setloading(false)
            setlogindata({...logindata,password:''})
            seterrormessage('Invalid Username or password')
          } );

        }

      }

      const savedata = (datas1,datas2) => {
        localStorage.setItem('farmyapp-tok',datas1)
        localStorage.setItem('farmyapp-userid',datas2)

        context.Loginhandler(datas1,datas2)
      }

      if( errormessage ){
        var icn = <Svg className="login-btn-div-btn-ic-error" href="sprite3.svg#icon-error_outline" />
        var msg = <Errormsg error={errormessage} />
      }if( loading ){
        icn = '...'
      }if( !errormessage && !loading ){
         icn = <Svg className="login-btn-div-btn-ic" href="contact.svg#icon-person" />
      }

      if(showpassword){
        var show = "text"
      }else{
        show = "password"
      }

      return (

        <>

        <div className="loginpage" >

            <ResetPasswordDiv
             usernamevalue={logindata.user_name}
             usernameonchange={usernameonchangeHandler}
             passwordvalue={logindata.password}
             passwordonchange={passwordonchangeHandler}
             login={loginHandler}
             btnIcn={icn}
             message={msg}
             type={show}
             showpassword={showpasswordHandler} />

        </div>

        <Footerdiv/>

        </>

      );

}

export default ResetPasswordPage;
