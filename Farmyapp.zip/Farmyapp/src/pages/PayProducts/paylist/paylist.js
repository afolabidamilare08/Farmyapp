import React from 'react';

export const PayProductList = (props) => {

      return ( 
          <div className="PayProductList-div" >

              <div className="PayProductList-div-top" >
                <div className="PayProductList-div-top-1" >
                    Unpaid
                </div>
              </div>

              <div className="PayProductList-div-mid" >

                    <div className="PayProductList-div-mid-form" >
                        <div className="PayProductList-div-mid-form-1" > Trader's Name : </div>
                        <div className="PayProductList-div-mid-form-2" > {props.first_name} {props.last_name} </div>
                    </div>

                    <div className="PayProductList-div-mid-form" >
                        <div className="PayProductList-div-mid-form-1" > Bank Name : </div>
                        <div className="PayProductList-div-mid-form-2" > {props.Bname} </div>
                    </div>

                    <div className="PayProductList-div-mid-form" >
                        <div className="PayProductList-div-mid-form-1" > Account Name : </div>
                        <div className="PayProductList-div-mid-form-2" > {props.Aname} </div>
                    </div>

                    <div className="PayProductList-div-mid-form" >
                        <div className="PayProductList-div-mid-form-1" > Account Number : </div>
                        <div className="PayProductList-div-mid-form-2" > {props.Anumber} </div>
                    </div>

                    <div className="PayProductList-div-mid-form" >
                        <div className="PayProductList-div-mid-form-1" > Product Name : </div>
                        <div className="PayProductList-div-mid-form-2" > {props.Pname} </div>
                    </div>

                    <div className="PayProductList-div-mid-form" >
                        <div className="PayProductList-div-mid-form-1" > Amount : </div>
                        <div className="PayProductList-div-mid-form-2" > ₦ {props.Pprice} </div>
                    </div>


              </div>

               <div className="PayProductList-div-btm" >
                   <button className="PayProductList-div-btm-btn" onClick={props.payTrader} > Pay Trader </button>
               </div>

          </div>
      );

}


export const PayServiceList = (props) => {

    return ( 
        <div className="PayProductList-div" >

            <div className="PayProductList-div-top" >
                <div className="PayProductList-div-top-1" >
                    Unpaid
                </div>
            </div>
            <div className="PayProductList-div-mid" >

                    <div className="PayProductList-div-mid-form" >
                        <div className="PayProductList-div-mid-form-1" > Trader's Name : </div>
                        <div className="PayProductList-div-mid-form-2" > {props.first_name} {props.last_name} </div>
                    </div>

                    <div className="PayProductList-div-mid-form" >
                        <div className="PayProductList-div-mid-form-1" > Bank Name : </div>
                        <div className="PayProductList-div-mid-form-2" > {props.Bname} </div>
                    </div>

                    <div className="PayProductList-div-mid-form" >
                        <div className="PayProductList-div-mid-form-1" > Account Name : </div>
                        <div className="PayProductList-div-mid-form-2" > {props.Aname} </div>
                    </div>

                    <div className="PayProductList-div-mid-form" >
                        <div className="PayProductList-div-mid-form-1" > Account Number : </div>
                        <div className="PayProductList-div-mid-form-2" > {props.Anumber} </div>
                    </div>

                    <div className="PayProductList-div-mid-form" >
                        <div className="PayProductList-div-mid-form-1" > Service Name : </div>
                        <div className="PayProductList-div-mid-form-2" > {props.Pname} </div>
                    </div>

                    <div className="PayProductList-div-mid-form" >
                        <div className="PayProductList-div-mid-form-1" > Amount : </div>
                        <div className="PayProductList-div-mid-form-2" > ₦ {props.Pprice} </div>
                    </div>


            </div>

            <div className="PayProductList-div-btm" >
                <button className="PayProductList-div-btm-btn" onClick={props.payTrader} > Pay Trader </button>
            </div>

        </div>
    );

}