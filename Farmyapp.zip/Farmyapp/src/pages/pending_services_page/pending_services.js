import React, { useState, useContext, useEffect } from 'react';
import PendingList from './PendingList/servicependinglist';
import Store from '../../store/managementstore/managementstore';
import Axios from 'axios';
import { Link } from 'react-router-dom';
import Customer from './customer-service.png';
import LoadingPage from '../../foods/components/loading/loading';
import OppsPage from '../../foods/components/oppspage/oppspage';
import ProfileHeader from '../../foods/layout_components/profile_header/profile_header';

const PendingServicesPage = (props) => {

    const context = useContext(Store)
    const [ Loadingpage , setLoadingpage ] = useState(false)
    const [ Errorpage , setErrorpage ] = useState(false)
    const [ MyServices , setMyServices ] = useState(null)

    useEffect( () => {

        setLoadingpage(true)
        setErrorpage(false)

        Axios.get( '/account/users/' + context.User_id + '/' ).then(
            response => {

                var Services = response.data.services

                var ArrayServ = [] 

                for (let h = 0; h < Services.length; h++) {
                    if( Services[h].sorderes.length > 0 ){
                        ArrayServ.push( Services[h] )
                    }
                }

                setMyServices(ArrayServ)
                setLoadingpage(false)
                setErrorpage(false)

            }
        ).then(
            e => {
                setLoadingpage(false)
                setErrorpage(true)
            }
        )

    } ,[context.User_id] )

    const goTofull = (id) => {

        props.history.push('/servfull' + id)

    }

    if( MyServices ){

        if( MyServices.length > 0 ){
            var softi = MyServices.map( prod => {
            
                if( prod.sorderes.length > 0 ){
    
                    var pendingNumber = 0
                    var delivered = 0
    
                    for (let u = 0; u < prod.sorderes.length; u++) {
                        
                        if( prod.sorderes[u].status === 'paid' ){
                            pendingNumber = pendingNumber + 1
                        }

                        if( prod.sorderes[u].status === 'serviced' ){
                            delivered = delivered + 1
                        }
    
                    }
    
                    return  <PendingList
                                key={prod.id}
                                firstimage = { 'https://farmyapp.xyz' + prod.service_img1 }
                                productname = { prod.service_name }
                                product_description = { prod.description } 
                                totalHires = { prod.sorderes.length }
                                pendinghires={ pendingNumber }
                                delivered={ delivered }
                                OpenDetails = { () => goTofull(prod.id) }
                                 />
                }
                
                return null
    
            } )
        }else{
            softi = <div className="Penddding_services_page_empty" >
                        <img src={Customer} alt="" className="Penddding_services_page_empty_img" />
                        <div className="Penddding_services_page_empty_text" > None of your service have been hired  </div>
                        <Link to="/profile/my_services" className="Penddding_services_page_empty_btn">
                            View my services
                        </Link>
                        </div>
    
        }

    }




















    const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }
    
    
      if( Loadingpage && !MyServices && !Errorpage ){
        var Where_To = <LoadingPage/>
      }else{
        if ( !Loadingpage && Errorpage && !MyServices ) {
          Where_To = <OppsPage tryagain={gogo} goback={goBack} />
        }
      }

      if ( MyServices ) {
        Where_To =  <div className="Penddding_services_page" >
                        <div className="Penddding_services_page_top" >
                        Pending Services Waiting to be Done
                        </div>
                        <div className="Penddding_services_page_mid" >
                            {softi}
                        </div>
                    </div>
      }










      return ( 

        

          <>
{/*  
          <Backdrop 
                show={ openModal } >
                  
                  <FullDisplayOfAction
                   bringData={ modalProduct }
                   closeModal={ () => setopenModal( false ) } />
                    
          </Backdrop> */}

            <ProfileHeader
              title="My Services Orders"
              goback={ goBack }
            />

            {Where_To}

          </>
      );

}

export default PendingServicesPage;