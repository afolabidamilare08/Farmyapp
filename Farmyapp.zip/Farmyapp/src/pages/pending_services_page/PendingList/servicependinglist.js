import React from 'react';

const ServicePendingList = (props) => {

    // if( props.product_description ){
        
    //     var desc = props.product_description

    //     if( desc.length < 300 ){
    //         var applydesc = desc
    //     }
        
    //     if( desc.length > 300 ){
    //         var Alright = []

    //         for (let h = 0; h < 300; h++) {
    //             Alright.push(desc[h])
    //         }

    //         applydesc = Alright

    //     }

    // }

    // 
      return ( 
          <div className="ServicependingList-div" >
              <div className="ServicependingList-div_first" >
                  <div className="ServicependingList-div_first_left" >
                        <div className="ServicependingList-div_first_left_img" >
                            <img alt="" src={props.firstimage} className="ServicependingList-div_first_left_img_img" />
                        </div>
                  </div>
                  <div className="ServicependingList-div_first_right" >    
                        <div className="ServicependingList-div_first_right_name" >
                            {props.productname}
                        </div>
                        {/* <div className="ServicependingList-div_first_right_desc" >
                            {applydesc}
                        </div> */}
                  </div>
              </div>
              <div className="ServicependingList-div_mid" >
                        {/* <div className="ServicependingList-div_first_right_nar" >
                            <span className="ServicependingList-div_first_right_nar_1" >
                                Quantity Available :
                            </span>
                            <span className="ServicependingList-div_first_right_nar_2" >
                                { props.quantityavailable + ' ' + props.mesurementscale }
                            </span>
                        </div> */}
                        <div className="ServicependingList-div_first_right_nar" >
                            <span className="ServicependingList-div_first_right_nar_1" >
                                Pending Hires :
                            </span>
                            <span className="ServicependingList-div_first_right_nar_2" >
                               { props.pendinghires + ' Hire(s)' }
                            </span>
                        </div>
                        <div className="ServicependingList-div_first_right_nar" >
                            <span className="ServicependingList-div_first_right_nar_1" >
                                Delivered Hires :
                            </span>
                            <span className="ServicependingList-div_first_right_nar_2" >
                               {props.delivered} Hire(s)
                            </span>
                        </div>
                        <div className="ServicependingList-div_first_right_nar" >
                            <span className="ServicependingList-div_first_right_nar_1" >
                                Total Number Of Hires :
                            </span>
                            <span className="ServicependingList-div_first_right_nar_2" >
                                { props.totalHires } Hire(s)
                            </span>
                        </div>
              </div>
              <div className="ServicependingList-div_second" >  
                    <button className="ServicependingList-div_second_btn" onClick={ props.OpenDetails } >
                        View All Hire(s)
                    </button>
              </div>
          </div>
      );

}

export default ServicePendingList;