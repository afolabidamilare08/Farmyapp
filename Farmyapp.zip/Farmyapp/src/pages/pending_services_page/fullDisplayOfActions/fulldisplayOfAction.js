import React, { useState } from 'react';
import ListOfCustomersOrders from './listOfcustomersOrders/listOfcustomersOrders';
import Axios from 'axios';
import Loading from '../../../component/utilities/loading/loading';

const FullDisplayOfAction = (props) => {

    const [ BigData , setBigData ] = useState(null)
    const [ orders , setorders ] = useState(null)
    const [ orderGotten , setorderGotten ] = useState(false)
    const [ pendingOrders , setpendingOrders ] = useState(null)
    const [ gotpending , setgotpending ] = useState(false)
    // const [ DeliveredOrders , setDeliveredOrders ] = useState(null)
    const [ switchOrder , setswitchOrder ] = useState(false)
    // const [ newOrders , setnewOrders ] = useState()

    const SaveData = (data) => {
        setBigData(data)

        var  Allorders = [...data.sorderes]

        var AmOrders = []

        for (let o = 0; o < Allorders.length; o++) {
            
            Axios.get( '/sorder/' + Allorders[o].id + '/'  ).then( 
                response => {
                    AmOrders.push(response.data)               
                    if( AmOrders.length === Allorders.length ){
                        setorders(AmOrders)
                        setorderGotten(true)
                    }
                }
             )

        }

    } 

    if( props.bringData && BigData === null && BigData !== props.bringData ){
        SaveData(props.bringData)
    }


    if( orders && orderGotten ){

        setpendingOrders(orders)
        setgotpending(true)
        setorderGotten(false)

    }














    const UpdatingToinTransit = (index) => {

        // console.log(pendingOrders[index])

        var old = { ...pendingOrders[index] }

            var items = old.items

            var shakeitem = []

            for (let h = 0; h < items.length; h++) {
                
                var item = items[h]
                var id = item.id

                var update = {
                    // id:id,
                    status:'in_transit',
                    // product:item.product,
                    // quantity:item.quantity,
                    // order:item.order,
                    // get_cost:item.get_cost
                }

                Axios.patch( '/orders/order_items/' + id + '/' , update , {
                     auth: {
                         username:'dami',
                         password:'dami'
                     }
                    } ).then( 
                    response => {
                        // console.log(response)
                        shakeitem.push(response.data)

                        if( shakeitem.length === items.length ){
    
                            Axios.get( '/orders/order/' + old.id + '/' ).then( 
                                response => {
                              
                                        var item = response.data
    
                                        var newlist = [...pendingOrders]
                                  
                                        newlist[index] = item
                                  
                                        setpendingOrders(null)
            
                                            setpendingOrders(newlist)
                                    
                                    
                                }
                             )
    
                }

                    }
                 )
            }



    }








    if( pendingOrders  ){
        
        if( !switchOrder ){
            var mappedPending = pendingOrders.map( ( order , index ) => {

                // var qty = [0]
                // var minArray = []
    
            //     for (let l = 0; l < order.items.length; l++) {
            //         var old = qty[0]
            //         var saynew = old + order.items[l].quantity
            //         qty[0] = saynew 
            //    }
    
                
                if( order.status === 'created' ){
                    return <ListOfCustomersOrders
                        //  first_name={ order.user.first_name }
                        //  last_name={ order.user.last_name }
                        //  quantity_ordered={ qty[0] }
                        //  total_price = { qty[0] * BigData.price }
                        //  measurement_scale = { BigData.measurement_scale }
                         status = { 'pending' }
                        //  product_name = { BigData.product_name }
                         statusbackground={ 'orange' }
                        //  phone_number = { order.user.phone_number }
                        //  email_address = { order.user.email }
                         pending = { () => UpdatingToinTransit(index) }
                          />
                }

                return null
    
            } )
        }

       if( switchOrder ){
             mappedPending = pendingOrders.map(  order => {

                var qty = [0]
                // var minArray = []

                for (let l = 0; l < order.items.length; l++) {
                    var old = qty[0]
                    var saynew = old + order.items[l].quantity
                    qty[0] = saynew 
                }

                console.log('order me',order) 

                if( order.items[0].status === 'in_transit' ){
                    return <ListOfCustomersOrders
                        first_name={ order.user.first_name }
                        last_name={ order.user.last_name }
                        quantity_ordered={ qty[0] }
                        statusbackground={ 'rgb(37, 88, 165)' }
                        total_price = { qty[0] * BigData.price }
                        measurement_scale = { BigData.measurement_scale }
                        product_name = { BigData.product_name }
                        status = { 'in transit' }
                        phone_number = { order.user.phone_number }
                        email_address = { order.user.email }
                        //  pending = { () =    > UpdatingToinTransit(index) }
                        />
                }

            } )
       }

    }

      return ( 
          <div className="servicesfulldisplayofaction_div" >
              
              {/* <TopInformationDiv
                FirstImg = { BigData ? BigData.product_img1 : '' } 
                productName = { BigData ? BigData.product_name : '' }
                price = { BigData ? BigData.price : '' }
                measurement_scale = { BigData ? BigData.measurement_scale : '' }
                quantitiyAvailable = { qremain }
                Total_Number_of_Orders = { pendingOrders ? pendingOrders.length : '' }
                pending_orders = { pendingOrders ? pendingOrders.length : ''  }
                 /> */}

              <div className="servicesfulldisplayofaction_div_switch" >
                 <button className="servicesfulldisplayofaction_div_switch_1" onClick={ () => setswitchOrder(false) } >
                     Pending Hire(s)
                 </button>
                 <button className="servicesfulldisplayofaction_div_switch_2" onClick={ () => setswitchOrder(true) } >
                     Delivered Hire(s)
                 </button>
              </div>

             <div className="servicesfulldisplayofaction_div_details" >

                { gotpending ? mappedPending : <Loading/> }

             </div>

             <div className="servicesfulldisplayofaction_div_close" >
                <button className="servicesfulldisplayofaction_div_close-btn" onClick={ props.closeModal } >
                    close
                </button>
             </div>

          </div>
      );

}

export default FullDisplayOfAction;