import React from 'react';

const TopInformationDiv = (props) => {

      return ( 
        <div className="topinformation-div_first" >
        <div className="topinformation-div_first_left" >
              <div className="topinformation-div_first_left_img" >
                  <img alt="" src={props.FirstImg} className="topinformation-div_first_left_img_img" />
              </div>
        </div>
        <div className="topinformation-div_first_right" >    
              <div className="topinformation-div_first_right_name" >
                    { props.productName }
              </div>
              <div className="topinformation-div_first_right_nar" >
                  <span className="topinformation-div_first_right_nar_1" >
                      Unit Price :
                  </span>
                  <span className="topinformation-div_first_right_nar_2" >
                       ₦ { props.price } per { props.measurement_scale }
                  </span>
              </div>
              <div className="topinformation-div_first_right_nar" >
                  <span className="topinformation-div_first_right_nar_1" >
                      Quantity Available :
                  </span>
                  <span className="topinformation-div_first_right_nar_2" >
                      { props.quantitiyAvailable } { props.measurement_scale }
                  </span>
              </div>
              <div className="topinformation-div_first_right_nar" >
                  <span className="topinformation-div_first_right_nar_1" >
                      Total Number Of Orders :
                  </span>
                  <span className="topinformation-div_first_right_nar_2" >
                      { props.Total_Number_of_Orders } Orders
                  </span>
              </div>
              <div className="topinformation-div_first_right_nar" >
                  <span className="topinformation-div_first_right_nar_1" >
                      Pending Orders :
                  </span>
                  <span className="topinformation-div_first_right_nar_2" >
                      {props.pending_orders}
                  </span>
              </div>
              <div className="topinformation-div_first_right_nar" >
                  <span className="topinformation-div_first_right_nar_1" >
                      Delivered Orders :
                  </span>
                  <span className="topinformation-div_first_right_nar_2" >
                      2
                  </span>
              </div>
        </div>
    </div>
      );

}

export default TopInformationDiv;