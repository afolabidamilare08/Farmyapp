import React from 'react';

const ListOfCustomersOrders = (props) => {

      return ( 
          <div className="servicelistOfcustomersOrders-div" >

              <div className="servicelistOfcustomersOrders-div-top" >
                  <div className="servicelistOfcustomersOrders-div-top-1" >
                      Order Status
                  </div>
                  <div className="servicelistOfcustomersOrders-div-top-2" style={{backgroundColor:props.statusbackground}} >
                     { props.status }
                  </div>
              </div>

              <div style={{padding:'1rem'}} >

              <div className="servicelistOfcustomersOrders-div_sec" >
                  <span className="servicelistOfcustomersOrders-div_sec-1" >
                      Customer :
                  </span>
                  <span className="servicelistOfcustomersOrders-div_sec-2" >
                      { props.first_name + ' ' + props.last_name } 
                  </span>
              </div>
              <div className="servicelistOfcustomersOrders-div_sec" >
                  <span className="servicelistOfcustomersOrders-div_sec-1" >
                      Service Name :
                  </span>
                  <span className="servicelistOfcustomersOrders-div_sec-2" >
                      { props.service_name }
                  </span>
              </div>
              <div className="servicelistOfcustomersOrders-div_sec" >
                  <span className="servicelistOfcustomersOrders-div_sec-1" >
                      Opening Time :
                  </span>
                  <span className="servicelistOfcustomersOrders-div_sec-2" >
                      { props.OpeningHours }
                  </span>
              </div>
              <div className="servicelistOfcustomersOrders-div_sec" >
                  <span className="servicelistOfcustomersOrders-div_sec-1" >
                      Closing Time :
                  </span>
                  <span className="servicelistOfcustomersOrders-div_sec-2" >
                      { props.ClosingHours }
                  </span>
              </div>
              <div className="servicelistOfcustomersOrders-div_sec" >
                  <span className="servicelistOfcustomersOrders-div_sec-1" >
                      No Of Working Hours :
                  </span>
                  <span className="servicelistOfcustomersOrders-div_sec-2" >
                      { props.no_of_working_hours }
                  </span>
              </div>
              <div className="servicelistOfcustomersOrders-div_sec" >
                  <span className="servicelistOfcustomersOrders-div_sec-1" >
                      Total Price :
                  </span>
                  <span className="servicelistOfcustomersOrders-div_sec-2" >
                        ₦ { props.total_price }
                  </span>
              </div>
              <div className="servicelistOfcustomersOrders-div_sec" >
                  <span className="servicelistOfcustomersOrders-div_sec-1" >
                      Order Status :
                  </span>
                  <span className="servicelistOfcustomersOrders-div_sec-2" >
                      { props.status }
                  </span>
              </div>
              <div className="servicelistOfcustomersOrders-div_sec" >
                  <span className="servicelistOfcustomersOrders-div_sec-1" >
                      Phone Number :
                  </span>
                  <span className="servicelistOfcustomersOrders-div_sec-2" >
                      { props.phone_number }
                  </span>
              </div>
              <div className="servicelistOfcustomersOrders-div_sec" >
                  <span className="servicelistOfcustomersOrders-div_sec-1" >
                      Email Address :
                  </span>
                  <span className="servicelistOfcustomersOrders-div_sec-2" >
                      { props.email_address }
                  </span>
              </div>
              <div className="servicelistOfcustomersOrders-div_sec" >
                  <span className="servicelistOfcustomersOrders-div_sec-1" >
                      State :
                  </span>
                  <span className="servicelistOfcustomersOrders-div_sec-2" >
                      Oyo
                  </span>
              </div>
              <div className="servicelistOfcustomersOrders-div_sec" >
                  <span className="servicelistOfcustomersOrders-div_sec-1" >
                      Address :
                  </span>
                  <span className="servicelistOfcustomersOrders-div_sec-2" >
                  </span>
              </div>
              <div className="servicelistOfcustomersOrders-div-address" >

              eliever to
                    thank and praise God daily. In Psalm 100:4 we told, 
                    Enter His gates with thanksgiving, and into His courts with praise,
                     However, basically we praise God for Who He is and thank 
                     Him for what He has done or promise
              </div>
              {/* <div className="servicelistOfcustomerChange" >
                  { props.pending ? <button className="listOfcustomerChange_btn" onClick={props.pending} >
                        Change order status to in transit
                  </button> : null }
              </div> */}
              </div>
          </div>
      );

}

export default ListOfCustomersOrders;