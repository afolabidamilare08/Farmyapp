import { useEffect , useState } from 'react';
import Axios from 'axios'; 


export  const useLogic = ( limitandoffset ) => {

    // Logic on how to get the products from the back end 
    //////////////////////////

    const [ maindata , setmaindata] = useState()


    useEffect( () => {
        Axios({
            method:'GET',
            url:'/product/',
            params:{ limit: limitandoffset.limit , offset:limitandoffset.offset }
        }).then(
            response => {
                setmaindata(response.data)
            }
        );
        // eslint-disable-next-line
    } , [limitandoffset] )

    /////////////////
    //====================================================
    
    return [maindata]

} 