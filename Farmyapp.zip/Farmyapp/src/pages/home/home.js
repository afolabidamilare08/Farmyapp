import React , { useState } from 'react';
import HomeSlider from '../../component/home-slider/home-slider';
import Product from '../../component/product_template/product_template';
import {Link} from 'react-router-dom';
import Footer from '../../layout/footer/footer';
import {useLogic} from './gettingproductlogic';
import Buisness from './business.png';  
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';


const Home = (props) => {
 // eslint-disable-next-line
    const [ limit , setlimit ] = useState({ limit: 0 , offset:0 })

    const [ maindata ] = useLogic(limit)


    //checking if Homeproduct do exit in other to aviod infinite loop and also to display the content with mapping
    //////////////////////////////////////////

    if( maindata ){

        if( maindata.results.length > 0 ){
            var display =   maindata.results.map( ( product , index) => {
     
                return <Product
                img={product.product_img1}
                product={product.product_name}
                key={product.product_name}
                product_des={product.description}
                add_to_cart
                lga={product.address[0].lga}
                state={product.address[0].state}
                action="Add To Cart"
                price={product.price}
                kg={product.measurement_scale}
                to={'/product' + product.slug + ":" + product.id } />
            
            }
    
            )
        }else{
           display = <div className="empty-cart-div" style={{
               marginTop:'5rem'
           }} > 
          
            <img src={Buisness} alt="" className="empty-cart-div-img" />
            <div className="empty-cart-div-txt" style={{textAlign:'center'}} > All Available Products Are Sold Out Check Back In A Moment </div>

        </div>
        }

        var paglink = []

        for (let f = 0; f < (maindata.count/24) ; f++) {    
            paglink.push( { no: 1 + f  , limit: 24 , offset: 24 * f } )
        }

    }

    ///////////////////////////////////////////
    //====


      return (

        <div className="home-page">

           {/* <div className="sticky-sell-btn" >
                <Link to="/sell" className="sticky-sell-btn-link" >
                    <Svg
                     className="sticky-sell-btn-link-ic"
                     href="sprite3.svg#icon-store_mall_directorystore" />
                    Sell
                </Link>
            </div> */}

            <HomeSlider/>
            
                <div className="home-products-div" >
                        {display ? display : <BtnSpin bgColor="rgba(13, 194, 94, 0.986)" /> }
                </div>

                <div className="pagination_div" >
                { maindata ? 
                         
                         paglink.map( pag => {

                             if( pag.no === 1 ){
                                 return <Link key={'/'} className="pagination_div_link" to={ '/'} > 
                                     { pag.no }
                                 </Link>
                             }else{
                                 return <Link key={ '/' + pag.limit + ':' + pag.offset }  className="pagination_div_link" to={ '/more' + pag.limit + ':' + pag.offset } > 
                                 { pag.no }
                             </Link>
                             }

                         } )

                      : null   }
                </div>

             <Footer/>

          </div>

      );

}

export default Home;
