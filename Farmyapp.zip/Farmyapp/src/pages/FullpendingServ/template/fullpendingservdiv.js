import React from 'react';
import Footerdiv from '../../../layout/footer/footer';

const FullpendingDiv = (props) => {

      return ( 
            <>
          <div className="FullpendingDiv-div" >

                {/* <div className="FullpendingDiv-div-1" >

                      <div className="FullpendingDiv-div-1-part" >
                              <div className="FullpendingDiv-div-1-part-img" >
                                    <img className="FullpendingDiv-div-1-part-img-img" alt="" src={props.srcImg} />
                              </div>
                              <div className="FullpendingDiv-div-1-part-name" >
                                    { props.mainName }
                              </div>
                              <div className="FullpendingDiv-div-1-part-div" >
                                    <div className="FullpendingDiv-div-1-part-div-form" >
                                          <span className="FullpendingDiv-div-1-part-div-form-1" > {props.level1} : </span>
                                          <span className="FullpendingDiv-div-1-part-div-form-2" > {props.pendingLength} {props.mode} </span>
                                    </div>
                                    <div className="FullpendingDiv-div-1-part-div-form" >
                                          <span className="FullpendingDiv-div-1-part-div-form-1" > {props.level2} : </span>
                                          <span className="FullpendingDiv-div-1-part-div-form-2" > {props.intransitLength} {props.mode} </span>
                                    </div>
                                    <div className="FullpendingDiv-div-1-part-div-form" >
                                          <span className="FullpendingDiv-div-1-part-div-form-1" > {props.level3} : </span>
                                          <span className="FullpendingDiv-div-1-part-div-form-2" > {props.deliveredLength} {props.mode} </span>
                                    </div>
                              </div>
                      </div>
                    
                </div> */}
                  <div className="FullpendingDiv-div-2-top" >
                        {/* All {props.mode} */}
                        <div className="FullpendingDiv-div-2-top-main" >
                              <button className="FullpendingDiv-div-2-top-main-btn" onClick={props.showPending} style={{ backgroundColor:props.showpendingbgcolor , color: props.showpendingcolor , boxShadow: props.showpendingbshadow }} > {props.level1} </button>
                              <button className="FullpendingDiv-div-2-top-main-btn" onClick={props.showintransit} style={{ backgroundColor:props.showintransitbgcolor , color: props.showintransitcolor , boxShadow: props.showintransitbshadow }} > {props.level2} </button>
                              <button className="FullpendingDiv-div-2-top-main-btn" onClick={props.showdelivered} style={{ backgroundColor:props.showdeliveredbgcolor , color: props.showdeliveredcolor , boxShadow: props.showdeliveredbshadow }} > {props.level3} </button>
                        </div>
                  </div>
                <div className="FullpendingDiv-div-2" >
                  <div className="FullpendingDiv-div-2-main" >
                        { props.whictoshow }
                  </div>
                </div>

          </div>
          <Footerdiv/>
          </>
      );

}

export default FullpendingDiv;