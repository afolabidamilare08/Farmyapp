import React, { useState, useEffect } from 'react';
import Axios from 'axios';
// import { PendingList } from '../pending_products_page/PendingList/pendinglist';
import ServiceHiredList from '../serviceHiredpage/serviceHiredList/serviceHiredlist';
import TopbannerDiv from '../../component/utilities/top-banner-msg/topbannermsg';
import PendingEmpty from '../Fullpendingproduct/Fullpendingproductempty';
import LoadingPage from '../../foods/components/loading/loading';
import OppsPage from '../../foods/components/oppspage/oppspage';
import ProfileHeader from '../../foods/layout_components/profile_header/profile_header';

const FullpendindServPage = (props) => {

    var ServiceMinId = props.match.params.id

    const [ Loadingpage , setLoadingpage ] = useState(false)
    const [ Errorpage , setErrorpage ] = useState(false)
    const [ ServiceTobereviewed , setServiceTobereviewed ] = useState(null)
    const [ penddingList , setpenddingList ] = useState(null)
    const [ servicedList , setservicedList ] = useState(null)
    const [ servicingList , setservicingList ] = useState(null)
    const [ whichtoshow , setwhichtoshow ] = useState('pending')
    const [ message , setmessage ] = useState({
        status:false,
        msg:'',
        bgColor:''
    })

    useEffect( () => {
        setLoadingpage(true)
        setErrorpage(false)
        Axios.get('/service/' + ServiceMinId ).then( 
            response => {
                setServiceTobereviewed(response.data)
                setLoadingpage(false)
                setErrorpage(false)
            }
         ).catch(
             e => {
                setLoadingpage(false)
                setErrorpage(true)
             }
         )
    } , [ServiceMinId] )





    const ChangetoservicingHandler = (id) => {
        setmessage({
            status:true,
            bgColor:'orange',
            msg:'Updating Hire Status ....'
        })

        const OrderIndex = penddingList.findIndex( i => {
            return i.id === id
          } )

          var chosenOrder = penddingList[OrderIndex]


        Axios.patch('/sorder/' + id + '/' , {status:'servicing'} ).then( 
            response => {
                var NewArray = [...penddingList]

                NewArray.splice(OrderIndex,1,)

                var currentOrder = {  ...chosenOrder , status:'servicing' }

                var Intransit = [ ...servicingList ]

                Intransit.push(currentOrder)

                setservicingList(Intransit)

                setpenddingList( NewArray  )

                setmessage({
                    status:true,
                    bgColor:'rgba(13, 194, 94, 0.986)',
                    msg:'Hire Status Sucessfully Updated ....'
                })
            }
         )

    }

    if( ServiceTobereviewed && !penddingList && !servicedList && !servicingList ){

        var minipending = []
        var minidelivered = []
        var miniservicing = []

        for (let g = 0; g < ServiceTobereviewed.sorderes.length; g++) {
            
            var safe = ServiceTobereviewed.sorderes[g]

            if( safe.status === 'serviced' ){
                minidelivered.push(safe)
            }

            if( safe.status === 'paid' ){
                minipending.push(safe)
            }

            if( safe.status === 'servicing' ){
                miniservicing.push(safe)
            }

        }

        setpenddingList(minipending)
        setservicedList(minidelivered)
        setservicingList(miniservicing)


    }








    
    if( penddingList ){
        if( penddingList.length > 0 ){

            var mappingpending = penddingList.map( list => {

                var op = list.prefered_time[0] + list.prefered_time[1]
                var newop = Number(op)
    
                
                if( newop > 12 ){
                      var openingTrange = 'PM'
                      var openingTime = newop - 12
                  }else{
                      openingTrange = 'AM'
                      openingTime = newop
                  }
    

                return <ServiceHiredList
                          key={list.id}
                          width='95%'
                          img={ list.customer.pro.profile_picture }
                          serviceName={ list.customer.first_name + ' ' + list.customer.last_name }
                          bgcolor="orange"
                          status='pending'
                          address={ list.address }
                          lga={ list.lga }
                          state={ list.state }
                          hireduration={ list.day }
                          openday={list.day}
                          time={ openingTime + ' ' + openingTrange }
                          lengthit={ list.duration }
                          HnAme={ list.customer.first_name + ' ' + list.customer.last_name }
                          Hnphone={ list.customer.pro.phone_number }
                          showTodservicing
                          changeStatus={ () => ChangetoservicingHandler(list.id) }
                           />

            } )

        }else{
            mappingpending = <PendingEmpty narate=" You Don't Have Any Pending Hires " />
        }
    }










    if( servicingList ){
        if( servicingList.length > 0 ){

            var mappingservicing = servicingList.map( list => {

                var op = list.prefered_time[0] + list.prefered_time[1]
                var newop = Number(op)
                    
                if( newop > 12 ){
                      var openingTrange = 'PM'
                      var openingTime = newop - 12
                  }else{
                      openingTrange = 'AM'
                      openingTime = newop
                  }
    

                return <ServiceHiredList
                          width='95%'
                          key={list.id}
                          img={ list.customer.pro.profile_picture }
                          serviceName={ list.customer.first_name + ' ' + list.customer.last_name }
                          bgcolor="rgb(50, 127, 241)"
                          status='servicing'
                          address={ list.address }
                          lga={ list.lga }
                          state={ list.state }
                          hireduration={ list.day }
                          openday={list.day}
                          time={ openingTime + ' ' + openingTrange }
                          lengthit={ list.duration }   
                          HnAme={ list.customer.first_name + ' ' + list.customer.last_name }
                          Hnphone={ list.customer.pro.phone_number }
                           />

            } )

        }else{
            mappingservicing = <PendingEmpty narate=" You Don't Have Any Servicing Hires " />
        }
    }








    if( servicedList ){
        if( servicedList.length > 0 ){

            var mappingserviced = servicedList.map( list => {

                var op = list.prefered_time[0] + list.prefered_time[1]
                var newop = Number(op)
    
                
                if( newop > 12 ){
                      var openingTrange = 'PM'
                      var openingTime = newop - 12
                  }else{
                      openingTrange = 'AM'
                      openingTime = newop
                  }
    

                return <ServiceHiredList
                          key={list.id}
                          width='95%'
                          img={ list.customer.pro.profile_picture }
                          serviceName={ list.customer.first_name + ' ' + list.customer.last_name }
                          bgcolor="rgba(13, 194, 94, 0.986)"
                          status='Serviced'
                          address={ list.address }
                          lga={ list.lga }
                          state={ list.state }
                          hireduration={ list.day }
                          openday={list.day}
                          time={ openingTime + ' ' + openingTrange }
                          lengthit={ list.duration }   
                          HnAme={ list.customer.first_name + ' ' + list.customer.last_name }
                          Hnphone={ list.customer.pro.phone_number }
                           />

            } )

        }else{
            mappingserviced = <PendingEmpty narate=" You Don't Have Any Serviced Hires " />
        }
    }






    const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }



    
    
    if( Loadingpage && !ServiceTobereviewed && !Errorpage ){
        var what_to_return = <LoadingPage/>
      }else{
        if ( !Loadingpage && Errorpage && !ServiceTobereviewed ) {
          what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
          if ( !Loadingpage && !Errorpage && ServiceTobereviewed ) {
            what_to_return = 

                  <div className="retailcartpage" style={{
                      margin: '0rem auto',
                      padding:'5rem 0rem',
                  }} >
  
  
                      <div className="retailproductpage-specs-top" >
  
                          <div className="retailproductpage-specs-top-li" onClick={ () => setwhichtoshow('pending') } style={{
                              borderBottom: whichtoshow === 'pending' ? '2px solid #49A010' : '2px solid transparent'
                          }} > Pending Orders ({penddingList.length}) </div>
                          <div className="retailproductpage-specs-top-li" onClick={ () => setwhichtoshow('servicing') } style={{
                              borderBottom: whichtoshow === 'servicing' ? '2px solid #49A010' : '2px solid transparent'
                          }} > Servicing Orders ({servicingList.length}) </div>
                          <div className="retailproductpage-specs-top-li" onClick={ () => setwhichtoshow('serviced') } style={{
                              borderBottom: whichtoshow === 'serviced' ? '2px solid #49A010' : '2px solid transparent'
                          }} > Serviced Orders ({servicedList.length}) </div>
  
                      </div>
  
                      <>
  
                      { whichtoshow === 'pending' && penddingList ? mappingpending : null }
                      { whichtoshow === 'servicing' && servicingList ? mappingservicing : null }
                      { whichtoshow === 'serviced' && servicedList ? mappingserviced : null }
  
                      </>
  
  
                  </div>
          }
        }
      }









      return ( 
        
        <>

        <TopbannerDiv 
            show={ message.status }
            closeshow={ () => setmessage({...message,status:false}) }
            message={ message.msg }
            backgroundcolor={ message.bgColor }
        />

        <ProfileHeader
            title="My Services Orders"
            goback={ goBack }
        />

        {what_to_return}

        </>

      );

}

export default FullpendindServPage;