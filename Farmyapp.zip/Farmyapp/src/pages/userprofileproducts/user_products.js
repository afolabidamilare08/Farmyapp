import React, { useEffect, useContext, useState } from 'react';
import Store from '../../store/managementstore/managementstore';
import Axios from 'axios';
import { Link } from 'react-router-dom';
import { ProductMiniTemp } from '../../component/mini_product-template/mini_product_template';
import ConfirmationMsg from '../../component/utilities/confirmation_Msg/confirmation_msg';
import Business from './business.png';
import LoadingPage from '../../foods/components/loading/loading';
import OppsPage from '../../foods/components/oppspage/oppspage';
import ProfileHeader from '../../foods/layout_components/profile_header/profile_header';

const UserproductPage = (props) => {

    const context = useContext( Store )

    const [ deleteprod , setdeleteprod ] = useState({
        status:false,
        msg:'',
        product_id:null,
        loading:false
    })

    const [ myproducts , setmyproducts ] = useState(null)
    const [ Loadingpage , setLoadingpage ] = useState(false)
    const [ Errorpage , setErrorpage ] = useState(false)

    useEffect( () => {

        setLoadingpage(true)
        setErrorpage(false)

        if ( context.User_id !== null ) {
            getdataHandler()
        }
// eslint-disable-next-line
    } , [context.User_id] )

    const getdataHandler = () => {

        Axios.get( '/account/users/' + context.User_id + '/' ).then( 
            response => {
                setmyproducts( response.data )
                setLoadingpage(false)
                setErrorpage(false)
            }
         ).catch(
             e => {
                setLoadingpage(false)
                setErrorpage(true)
             }
         );

    }

    const DeleteProduct = () => {
        
        if(deleteprod.product_id){
            setdeleteprod({...deleteprod,loading:true})
            var productId = deleteprod.product_id

            Axios.delete( '/product/' + productId + '/' ).then(
                response => {
                    Axios.get( '/account/users/' + context.User_id + '/' ).then( 
                        response => {
                            setmyproducts( response.data )
                            setdeleteprod({...deleteprod,loading:false,status:false,product_id:null})
                        }
                     )
                }
            )
        }

    }



      const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }
    
    
      if( Loadingpage && !myproducts && !Errorpage ){
        var what_to_return = <LoadingPage/>
      }else{
        if ( !Loadingpage && Errorpage && !myproducts ) {
          what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
          if ( !Loadingpage && !Errorpage && myproducts ) {
            what_to_return = 
                <>

                <div className="UserproductPage-div_page" >
                    
                    <div className="UserproductPage-div_page_top" >
                            My Products
                    </div>

                    <div className="UserproductPage-div_page_mid" >


                    { myproducts.products.length > 0 ? 
                        myproducts.products.map( product => {

                            var Date_Created = []
            
                            for (let k = 0; k < product.created.length ; k++) {
                                if( product.created[k] === 'T' ){
                                    break
                                }else{
                                    Date_Created.push(product.created[k])
                                }
                            }
            
                            var Date_updated = []
            
                            for (let p = 0; p < product.updated.length ; p++) {
                                if( product.updated[p] === 'T' ){
                                    break
                                }else{
                                    Date_updated.push(product.updated[p])
                                }
                            }
                            return  <ProductMiniTemp
                                        key={product.id}
                                        product_description={ product.description }
                                        firstimage={ "https://farmyapp.xyz" + product.product_img1 }
                                        productname={ product.product_name }
                                        quantityavailable={ product.quantity_remaining ? product.quantity_remaining : product.quantity_available }
                                        mesurementscale={ product.measurement_scale }
                                        totalquantityofproducts={ product.quantity_available + ' ' + product.measurement_scale }
                                        price={ product.price }
                                        ShouldDisplay={ product.quantity_ordered === product.quantity_available ? false : true }
                                        quantityordered={ product.quantity_ordered }
                                        edit={'/editproduct' + product.slug + ':' + product.id}
                                        showDelete={ product.itemOrdered.length > 0 ? true : false }
                                        delete={() => setdeleteprod({ 
                                            msg:'Are you sure you want to delete this product ? ',
                                            status:true,
                                            product_id:product.id
                                         }) }
                                    />
                                
                                    
                                } )
                    : 
                    <div className="UserproductPage-div_page_empty" >
                            <img src={Business} alt="" className="UserproductPage-div_page_empty_img" />
                            <div className="UserproductPage-div_page_empty_text" > You don't have a product currently on sale  </div>
                            <Link to="/sell" className="UserproductPage-div_page_empty_btn">
                                sell a product
                            </Link>
                    </div> }



                    </div>
                </div>

                </>
          }
        }
      }
    


      return ( 
          <>

           <ConfirmationMsg 
                show={deleteprod.status}
                msg={deleteprod.msg}
                decline={ () => setdeleteprod({...deleteprod,status:false,service_id:null}) }
                confirm={ DeleteProduct }
                isloading={deleteprod.loading} />

            <ProfileHeader
                title="My Products"
                goback={ goBack }
            />

            {what_to_return}

          </>
      );

}

export default UserproductPage;