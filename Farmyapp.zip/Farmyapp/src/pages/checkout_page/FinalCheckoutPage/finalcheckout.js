import React, { useState, useEffect , useContext } from 'react';
import Footer from '../../../layout/footer/footer';
// import OrderList from '../../FullMyorderlist/fullOrderlist';
import Svg from '../../../component/utilities/Svg';
import Backdrop from '../../../component/utilities/Backdrop/backdrop';
import PaystackDiv from '../../../component/payment_component/payment_component';
import Axios from 'axios';
import Store from '../../../store/managementstore/managementstore';
import { OrderProductWithDelivery } from '../../../component/orderListTemplate/orderListTemplate';

const Finalcheckout = (props) => {

    const context = useContext(Store)

    const [ OpenPaymentSystem , setOpenPaymentSystem ] = useState(false)
    const [ Userdata , setUserdata ] = useState(null)

    const [ Order , setOrder ] = useState(null)

    var orderId = props.match.params.id

    useEffect( () => {

        Axios.get( '/orders/order/' + orderId + '/' ).then(
            response => {
                setOrder(response.data)
                setUserdata(response.data.user)
            }
        )

    } , [ orderId ] )

    const cancelOrder = () => {

        Axios.delete( '/orders/order/' + orderId + '/' ).then(
            response => {
                props.history.push('/checkout')
            }
        )

    }

    const paymentCallback = () => {
        
        var AllLong = []

        for (let k = 0; k < Order.items.length; k++) {
            Axios.patch( '/orders/order_items/' + Order.items[k].id + '/' , { status: 'paid' } 
            ).then( response => {
                AllLong.push(response.data)
                if( k === Order.items.length - 1  ){
                    context.updatecartHandler()
                     props.history.push('/profile/wholesale_order/' + orderId )
                }
            } )
        }

        // if( AllLong.length === Order.items.length ){
                
        // }

    }


      return ( 

        <>

        <Backdrop show={ OpenPaymentSystem } >
            <PaystackDiv 
                cancelpayment={ () => setOpenPaymentSystem(false) }
                callback={ paymentCallback }
                email={ Userdata ? Userdata.email : '' }
                amount={ Order ? Order.get_total_cost + '00' : '' } /> 
        </Backdrop>

            { Order && Userdata ? 
                
            <div className="finalcheckout-page" >

                <div className="finalcheckout-page-div" >
                    <div className=" finalcheckout-page-div-top " >
                        My Order Summary
                    </div>
                    <div>
                        
                        { Order ? 
                        
                            Order.items.map( item => {
                                return <OrderProductWithDelivery 
                                           key={item.id}
                                           Orderimg={ 'https://farmyapp.xyz' + item.product.product_img1}
                                        //    className='Finallistdiv'
                                           productName={ item.product.product_name }
                                           quantity={ item.quantity }
                                           putaddress={ Order.address[0] ? false : true }
                                           measurement_scale={ item.product.measurement_scale }
                                           product_cost={ item.get_cost }
                                           width='100%'
                                           showAddress={ item.product.address[0] }
                                           address={ item.product.address[0] ? item.product.address[0].address : false }
                                           lga={ item.product.address[0] ? item.product.address[0].lga : false }
                                           state={ item.product.address[0] ? item.product.address[0].state : false }
                                           tfare={ item.get_tfare }
                                           theFirst_name={ item.product.user.first_name }
                                           theLast_name={ item.product.user.last_name }
                                           theNumber={ item.product.user.pro.phone_number }
                                           totalcost={ item.get_bsolute }    />

                            } )    

                        : null }

                    </div>

                    <div className="finalcheckout-btm" >

                    <div className="finalcheckout-btm-right" >
                        <div className="finalcheckout-btm-right-det" >
                            <div className="finalcheckout-btm-right-det-1" >
                                <span className="finalcheckout-btm-right-det-1-total" >Total: </span> 
                                <span className="finalcheckout-btm-right-det-1-value" > ₦{new Intl.NumberFormat({ style: 'currency', currency: 'EUR' }).format(Order ? Order.get_total_cost : '')}</span>
                            </div>
                            <div className="finalcheckout-btm-right-det-2" >
                                Transport fee already included
                            </div>
                        </div>
                        <button className="finalcheckout-btm-right-procced" onClick={ () => setOpenPaymentSystem(true) } > Proceed To Pay </button>
                    </div>

                    </div>
                    
                </div>
            
                <div className="finalcheckout-page-split" >

                <div className="finalcheckout-page-split-part" >
                    <div className="finalcheckout-page-split-part-top" > My Contact Details </div>
                        <div className="finalcheckout-page-split-part-fex" style={{
                            display:'flex',
                            alignItems:'center'
                        }} >
                            <div className="finalcheckout-page-split-part-fex-1" >
                                <Svg className="finalcheckout-page-split-part-fex-1-ic" href="contact.svg#icon-person" />
                            </div>
                            <div className="finalcheckout-page-split-part-fex-2-det" >
                                { Userdata ? Userdata.first_name : null } { Userdata ? Userdata.last_name : null } 
                            </div>
                        </div>
                        <div className="finalcheckout-page-split-part-fex" style={{
                            display:'flex',
                            alignItems:'center'
                        }} >
                            <div className="finalcheckout-page-split-part-fex-1" >
                                <Svg className="finalcheckout-page-split-part-fex-1-ic" href="sprite4.svg#icon-mail" />
                            </div>
                            <div className="finalcheckout-page-split-part-fex-2-det" >
                            { Userdata ? Userdata.email : null }
                            </div>
                        </div>
                        <div className="finalcheckout-page-split-part-fex" style={{
                            display:'flex',
                            alignItems:'center'
                        }} >
                            <div className="finalcheckout-page-split-part-fex-1" >
                                <Svg className="finalcheckout-page-split-part-fex-1-ic" href="contact.svg#icon-phone" />
                            </div>
                            <div className="finalcheckout-page-split-part-fex-2-det" >
                            { Userdata ? Userdata.pro.phone_number : null }
                            </div>
                        </div>
                </div>

                <div className="finalcheckout-page-split-part" >
                    <div className="finalcheckout-page-split-part-top" > Delivery Details </div>

                    <div className="finalcheckout-page-split-part-fex" >
                        <div className="finalcheckout-page-split-part-fex-1" >
                            <Svg 
                                className="finalcheckout-page-split-part-fex-1-ic"
                                href="sprite4.svg#icon-location_onplaceroom"
                            /> 
                        </div>
                        <div className="finalcheckout-page-split-part-fex-2" >
                            <div className="finalcheckout-page-split-part-fex-2-top" >
                                { Order.address[0] ? Order.address[0].address : ' The mode of delivery you chose was self pickup thats why there are no delivery details ' } 
                            </div>
                            <div className="finalcheckout-page-split-part-fex-2-next" >
                                { Order.address[0] ? Order.address[0].lga + ' ,' : '' }  { Order.address[0] ? Order.address[0].state : '' }
                            </div>                                                  
                        </div>
                    </div>

                </div>

                <div className="finalcheckout-page-split-part" >
                    <button className="finalcheckout-page-split-part-cancelOrder" onClick={ cancelOrder } > Cancel order </button>
                </div>

                </div>
                
            </div>        
            
            : <Backdrop show={true} /> }    



            <Footer />

        </>

      );

}

export default Finalcheckout;