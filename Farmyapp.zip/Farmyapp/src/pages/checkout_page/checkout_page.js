import React , { useState , useContext , useEffect } from 'react';
import Store from '../../store/managementstore/managementstore';
import Paymentfirststep from '../../component/check-out-components/payments-steps/payments_firststep/payment_firststep';
import Paymentssecondstep from '../../component/check-out-components/payments-steps/payments_secondstep/payment_secondstep';
import Backdrop from '../../component/utilities/Backdrop/backdrop';
import Editprofile from '../../component/user-profile-box/middle-div/profile-details/profile_details';
import Footer from '../../layout/footer/footer';
import Mapform from '../../component/check-out-components/map-form/map-form';
import LeafletMapDiv from '../../component/LeafletMap/LeafletMap';
import { Popup } from 'react-leaflet';
import TopbannerDiv from '../../component/utilities/top-banner-msg/topbannermsg';
import { Toggletitle } from '../../component/sellpage_template/sell_temp/sell_.temp';
import Axios from 'axios'


const CheckoutPage = (props) => {

    const context = useContext(Store)

    const [user_detail,setuser_detail] = useState(null)
    const [user_detail2,setuser_detail2] = useState(null)
    const [ openeditprofilemodal , setopeneditprofilemodal ] = useState(false)
    const [ openmapform , setopenmapform ] = useState({ status1: false , status2:false });
    const [ openMap , setopenMap ] = useState(false)
    const [ Openprofileblock , setOpenprofileblock ] = useState(true)
    const [ Openmapblock , setOpenmapblock ] = useState(false)
    const [ message , setmessage ] = useState({
        status:false,
        msg:'',
        Bgcolor:''
    })

    useEffect( () => {
                setuser_detail({...context.User_details.detail})
                setuser_detail2({...context.User_details.detail2})
    } , [context.User_details.detail , context.User_details.detail2 , context.User_cart_id] )




    const [ UserAddress , setUserAddress ] = useState({
        country:'Nigeria',
        state:'',
        lga:'',
        address:"",
        longitude:'',
        latitude:'',
        mapstory:'Search and select the closest place to your farm on the map',
        area:''
    })


    const proccedtopaymentHandler = () => {

        if( 
            user_detail.first_name === '' || 
            user_detail.last_name === '' || 
            user_detail.email === '' || 
            (user_detail2.phone_number === null || user_detail2.phone_number === '' )
        ){
            setmessage({
                status:true,
                Bgcolor:'red',
                msg:'Your Profile details must be complete , click on edit profile to complete your profile'
            })
        }else{

            if( !openmapform.status1 ){
                setmessage({
                    status:true,
                    Bgcolor:'red',
                    msg:'Please select a delivery option'
                })
            }
    
            if( openmapform.status1 ){
    
                if ( openmapform.status2 ) {
                    
                    if( 
                        UserAddress.country === '' ||
                        UserAddress.state === '' ||
                        UserAddress.lga === '' ||
                        UserAddress.address === '' ||
                        UserAddress.longitude === '' ||
                        UserAddress.latitude === '' ||
                        UserAddress.area === ''
                     ){
                        setmessage({
                            status:true,
                            Bgcolor:'red',
                            msg:'Please fill all delivery information'
                        })
                     }else{
                        setmessage({
                            status:true,
                            Bgcolor:'orange',
                            msg:'Please wait while we process your information'
                        })

                        Axios.post( 'orders/order/' , ''  ).then( 
                                response => {
                                    // console.log(response)
                                    var id = response.data.id 

                                        Axios.post('/orders/order/' + id + '/order_address/' , UserAddress
                                        ).then(
                                            response => {
                                                props.history.push( '/finalcheckout' + id  )
                                                // console.log(response)
                                            }
                                        ).catch()

                                }
                            ).catch( (error) => {
                                if(error.response){

                                    setmessage({
                                        status:true,
                                        Bgcolor:'red',
                                        msg:error.response.data[0]
                                    })

                                }
                            } )

 
                        
                     }
    
                }
    
                if( !openmapform.status2 ){
                    setmessage({
                        status:true,
                        Bgcolor:'orange',
                        msg:'please wait while we process your information'
                    })
                    Axios.post( 'orders/order/' , ''  ).then( 
                        response => {
                            // console.log(response)
                            var id = response.data.id 
                            props.history.push( '/finalcheckout' + id  )
                        }
                    )

                }
    
            }


        }


    }



    const myPopup = (SearchInfo) => {


        return(
                    <Popup>
                        {/* <div> */}
                        <p 

                        style={{
                            fontWeight:'800'
                        }}

                        >{SearchInfo.info}</p>
                        {/* {/* <div>Latitude:{SearchInfo.latLng.lat}</div> */} 
                        {/* {/* <div>Longitude:{SearchInfo.latLng.lng}</div> */} 

                        <button className="Mappupop_btn" onClick={ 
                            () => setAllUserlocationdetails(SearchInfo)
                         } > Select Location </button>
                    </Popup>
        );
      }


    // Map Address issues

      const setAllUserlocationdetails = (SearchInfo) => {

        setUserAddress({
            ...UserAddress,
            mapstory:'Please wait , this might take some time...  '
        })

        setUserAddress({
            ...UserAddress,
            latitude:SearchInfo.latLng.lat,
            longitude:SearchInfo.latLng.lng,
            area:SearchInfo.info,
            mapstory:'Location was successfully saved...'
        })

        // setUserAddress({
        //     ...UserAddress,
        //     mapstory:'Search and select the closest place to your farm on the map'
        // })

        setopenMap(false)

      }

    ////




      return ( 
          <>

        <Backdrop show={openMap}
             />

             { openMap ? 
                
               <LeafletMapDiv 
               myPopup={ myPopup }
               story={ UserAddress.mapstory }   
                 closeMap={ () => setopenMap(false) } /> 
            :
            null
            }


            <TopbannerDiv 
               show={ message.status }
               backgroundcolor={ message.Bgcolor }
               closeshow={ () => setmessage({...message,status:false}) }
               message={ message.msg }
                />
            
            <Backdrop show={openeditprofilemodal} >
                <div className="checkout-page-box-editprofile_top" >
                    <button className="checkout-page-box-editprofile_top_btn" onClick={ () => setopeneditprofilemodal(false) } >
                        Close Edit profile
                    </button>
                </div>
                <div style={{width:'100%',height:'80vh',overflowY:'auto'}} >
                <Editprofile/>
                </div>
            </Backdrop>

          <div className="checkout-page-box" >

            <div className="checkout-page-box-div" >
                <div className="checkout-page-box-div-top" >
                    Checking Out My Order
                </div>
                
                <Toggletitle 
                  title='Personal Information'
                  position={ Openprofileblock }
                  toggleposition={ () => setOpenprofileblock(!Openprofileblock) }  />

                  <div className="checkout-page-box-div-pack" style={{
                      display: Openprofileblock ? 'block' : 'none' 
                  }} >
                        <Paymentfirststep
                            first_name={user_detail ? user_detail.first_name : null}
                            last_name={user_detail ? user_detail.last_name : null}
                            email={user_detail ? user_detail.email : null}
                            phone_number={user_detail2 ? user_detail2.phone_number : null}
                            openeditprofile={ () => setopeneditprofilemodal(true) }  />
                  </div>


                  <Toggletitle
                    title='Delivery Information'
                    position={ Openmapblock }
                    toggleposition={ () => setOpenmapblock(!Openmapblock) }
                  />

                  <div className="checkout-page-box-div-pack" style={{
                      display: Openmapblock ? 'block' : 'none' 
                  }} >
                        <Paymentssecondstep
                            step_det="Select a delivery option "
                            pick_it_yourself={ () => setopenmapform( { status1:true , status2:false } ) }
                            farmy_express_delivery={ () => setopenmapform( { status1:true , status2:true } ) }
                            mapinfo={ openmapform.status2 ?
                                
                                <Mapform
                                countryvalue={ UserAddress.country }
                                countryonChange={ (event) => setUserAddress({...UserAddress,country:event.target.value}) }

                                lgavalue={ UserAddress.lga }
                                lgaonChange={ (event) => setUserAddress({...UserAddress,lga:event.target.value}) }

                                statevalue={ UserAddress.state }
                                stateonChange={ (event) => setUserAddress({...UserAddress,state:event.target.value}) }

                                addressvalue={ UserAddress.address }
                                addressonChange={ (event) => setUserAddress({...UserAddress,address:event.target.value}) }

                                //  longitudevalue={ UserAddress.longitude }
                                //  longitudeonChange={ (event) => setUserAddress({...UserAddress,longitude:event.target.value}) }

                                
                                //  latitudevalue={ UserAddress.latitude }
                                //  latitudeonChange={ (event) => setUserAddress({...UserAddress,latitude:event.target.value}) }

                                mapAddress={ UserAddress.area }

                                Openmap={ () => setopenMap(true) }

                                /> 
                                
                                : null } />
                  </div>
                            
                  <div className="checkout-page-box-div-pack" >
                      <button onClick={ proccedtopaymentHandler } className="checkout-page-box-div-pack-next" >
                          Procced To Payment
                      </button>
                  </div>

            </div>

          </div>
          <Footer/>
          </>
      );

}

export default CheckoutPage;