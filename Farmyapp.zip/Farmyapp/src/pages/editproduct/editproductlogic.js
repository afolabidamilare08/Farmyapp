import { useEffect , useState } from 'react';
import Axios from 'axios';


export const useEditlogic = (id,slug) => {

    const [ productinfo , setproductinfo ] = useState(null)

    useEffect( () => {

        Axios.get('/product/'+id+'/').then(
            response => {
                setproductinfo(response.data)
            }
        );

    } , [id,slug] )

    return[ productinfo ]

}