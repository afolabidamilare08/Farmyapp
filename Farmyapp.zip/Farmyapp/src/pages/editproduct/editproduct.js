import React,{useState} from 'react';
import Selltemplate from '../../component/sellpage_template/sellpage_template';
import Axios from 'axios';
import { useEditlogic } from './editproductlogic';
import Footerdiv from '../../layout/footer/footer';
import TopbannerDiv from '../../component/utilities/top-banner-msg/topbannermsg';
import Backdrop from '../../component/utilities/Backdrop/backdrop';
import LeafletMapDiv from '../../component/LeafletMap/LeafletMap';
import { Popup } from 'react-leaflet';


const Sellpage = (props) => {

  var slug = props.match.params.slug
  var i_d = props.match.params.id

  const [ editableproduct  ] = useEditlogic(i_d,slug)

    const [ openMap , setopenMap ] = useState(false)

    const [ errormessage , seterrormessage ] = useState( { msg: '' , status: false , bgcolor: ''} )

    const [scroll,setscroll] = useState(true)

    const [ initialpictures , setinitialpictures ] = useState({
      product_img1:null,
      product_img2:null,
      product_img3:null,
    })

    const [ selldata , setselldata ] = useState({
      product_name:null,
      product_description: '',
      product_price:'',
      product_scale:'',
      product_available:'',
      product_harvestdate:'',
      product_img1:null,
      product_img2:null,
      product_img3:null,
      transport_means: null,
      amount_can_carry:'',
      country:'',
      state:'',
      mapstory:'Search and select the closest place to your farm on the map',
      Lga:'',
      address:'',
      longitude:'',
      latitude:'',
      addressId:'',
      area:'',
      account_name:'',
      account_number:'',
      bank_name:''
    }) 


    // logic for changing the state that has to do with text only e.g product name , product desc e.t.c
    //======================

    const productnameonchangeHandler = (event) => {
      var initialdata = {...selldata}
      setselldata({...initialdata,product_name:event.target.value})
    }

    const productdescriptiononchangeHandler = (event) => {
      var initialdata = {...selldata}
      setselldata({...initialdata,product_description:event.target.value})
    }

    const productpriceonchangeHandler = (event) => {
      var initialdata = {...selldata}
      setselldata({...initialdata,product_price:event.target.value})
    }

    const productscaleonchangeHandler = (event) => {
      var initialdata = {...selldata}
      setselldata({...initialdata,product_scale:event.target.value})
    }

    const productavailableonchangeHandler = (event) => {
      var initialdata = {...selldata}
      setselldata({...initialdata,product_available:event.target.value})
    }

    const productharvestdateonchangeHandler = (event) => {
      var initialdata = {...selldata}
      setselldata({...initialdata,product_harvestdate:event.target.value})
    }

    ///////////////////////////////////////
    //=====================================







    //All logic partaining to image upload and image validation
    //========================


    const [file1 , setfile1] = useState({image:null,preview:null})
    const [file2 , setfile2] = useState({image:null,preview:null})
    const [file3 , setfile3] = useState({image:null,preview:null})

    const [ story1 , setstory1  ] = useState({story:'This picture should be the picture of the product in single',storyerror:false})
    const [ story2 , setstory2  ] = useState({story:'This picture should be the picture of the product in bulk',storyerror:false})
    const [ story3 , setstory3  ] = useState({story:'This picture should be the picture of the product in use',storyerror:false})


    //logic to check if the image uploaded is actually a picture and not another file
    //===========================


    const acceptedFileType = 'image/x-png , image/png, image/jpg, image/jpeg, image/gif '
    const acceptedFileTypeArray = acceptedFileType.split(',').map((item) => {return item.trim()} )

    const veriyfyFile = (file) => {
      const currentfile = file
      const currentfileType = currentfile.type

      if( !acceptedFileTypeArray.includes(currentfileType) ){
        return false
      }else{
        return true
      }

    }

    //////////////
    //=================================

    //logic for chexking the validation of the three image input with the verfiyfile function above 
    //and also to show the preview with the showpreview function below

    const choosefirstimageHandler = (event) => {
        if(veriyfyFile(event.target.files[0])){
          showpreview(event.target.files[0],1)
          setstory1({...story1,storyerror:false})
        }else{
          setfile1({image:null,preview:initialpictures.product_img1})
          setselldata({ ...selldata , product_img1:false })
          setstory1({...story1,storyerror:'This file is not allowed'})
          seterrormessage( { msg: 'Only png , jpg , jpeg , gif files are allowed' , status:true , bgcolor: 'red' } )
        }
    } 

    const choosesecondimageHandler = (event) => {
        if(veriyfyFile(event.target.files[0])){
          showpreview(event.target.files[0],2)
          setstory2({...story2,storyerror:false})
        }else{
          setfile2({image:null,preview:initialpictures.product_img2})
          setselldata({ ...selldata , product_img1:false })
          setstory2({...story2,storyerror:'This file is not allowed'})
          seterrormessage( { msg: 'Only png , jpg , jpeg , gif files are allowed' , status:true , bgcolor: 'red' } )
        }
    }  

    const choosethirdimageHandler = (event) => {
      if(veriyfyFile(event.target.files[0])){
        showpreview(event.target.files[0],3)
        setstory3({...story3,storyerror:false})
      }else{
        setfile3({image:null,preview:initialpictures.product_img3})
        setselldata({ ...selldata , product_img1:false })
        setstory3({...story3,storyerror:'This file is not allowed'})
        seterrormessage( { msg: 'Only png , jpg , jpeg , gif files are allowed' , status:true , bgcolor: 'red' } )
      }
    }  

    /////////////////
    //==================================



    // this function is used to show the preview of an image about to be uploaded 
    // or it can be called a function that converts a file to base 64


    const showpreview = (file,where) => {

        const currentfile = file 
        const reader = new FileReader()
        reader.addEventListener("load",()=>{
            if(where === 1){
                setfile1({image:file,preview:reader.result})
                setselldata({ ...selldata , product_img1:true })
            }
            if(where === 2){
                setfile2({image:file,preview:reader.result})
                setselldata({ ...selldata , product_img2:true })
            }
            if(where === 3){
              setselldata({ ...selldata , product_img3:true })
                setfile3({image:file,preview:reader.result})
            }
        },false)

        reader.readAsDataURL(currentfile)

    }

    ////////////////
    //===================================


    
    
    //////////////////////////
    //===================================





    // a logic to make sure that the user dose not input letters but only digit
    ////////////////////

    const accepteddigit = '1 , 2 , 3 , 4 , 5 , 6 , 7 , 8 , 9 , 0'
    const accepteddigitarray = accepteddigit.split(',').map((item) => {return item.trim()} )

    
    const verifynum = (file,message) => {

      const currentfile = file
      for (let k = 0; k < currentfile.length; k++) {
        if( !accepteddigitarray.includes(currentfile[k]) ){
          seterrormessage( { msg: message , status:true , bgcolor: 'red' } )
          return false
        }else{
          return true
        }
      }
    }


    /////////////////
    ////=============================



    // a function that consist of final validation and posting of the validated form to the back end
    ////////////////////////

    const sellproductHandler = ( ) => {

      seterrormessage( { msg: 'Updating product .....' , status:true , bgcolor: 'orange' } )

      if( selldata.product_name === '' ||
          selldata.product_description === '' ||
          selldata.product_price === '' ||
          selldata.product_scale === '' ||
          selldata.product_harvestdate === '' || 
          selldata.product_available === '' ||
          selldata.Lga === '' ||
          selldata.address === '' ||
          selldata.amount_can_carry === '' ||
          selldata.country === '' ||
          selldata.latitude === '' ||
          selldata.longitude === '' ||
          selldata.state === '' ||
          selldata.area === '' ||
          selldata.account_name ===  '' ||
          selldata.account_number ===  '' ||
          selldata.bank_name ===  '' ||
          selldata.transport_means === null
          ){
        seterrormessage( { msg: 'All fileds must be filled' , status:true , bgcolor: 'red' } )
      }

      // if (verifynum(selldata.product_available)) {
      //   console.log('ok')
      // }

      const error_availabeharvest = 'Quantity available for sale should just be digit e.g(94) and measurement scale (kgs,bags,baskets e.t.c ) should not be added to it'
      const error_price = 'Price should just be digit only , letters or symbols should not be added to it'
      const error_cancarry = 'Amount of '+ selldata.product_scale +' the selected vehicle can carry should just be digit only , letters or symbols should not be added to it'
      const error_number = ' Your Account Number Should Only Be Numeric '

      if( 
          selldata.product_name !== '' || 
          selldata.product_description !== '' || 
          selldata.product_price !== '' || 
          selldata.product_scale !== '' || 
          selldata.product_harvestdate !== '' ||   
          selldata.product_available !== '' || 
          file1.image !== null || 
          file2.image !== null || 
          file3.image !== null  || 
          verifynum(selldata.product_price,error_price)  || 
          verifynum(selldata.product_available,error_availabeharvest) ||
          verifynum(selldata.amount_can_carry,error_cancarry) ||
          verifynum(selldata.accountnumber,error_number) ||
          selldata.Lga !== '' ||
          selldata.address !== '' ||
          selldata.amount_can_carry !== '' ||
          selldata.country !== '' ||
          selldata.latitude !== '' ||
          selldata.longitude !== '' ||
          selldata.state !== '' ||
          selldata.maparea !== '' ||
          selldata.account_name !== '' ||
          selldata.account_number !== '' ||
          selldata.bank_name !== ''
          ){

        
            if( selldata.product_available < editableproduct.quantity_ordered ){
              seterrormessage( { msg: "You can't stock less than you have sold " , status:true , bgcolor: 'red' } )
            }else{

              const Datatosubmit = new FormData();

        Datatosubmit.append('product_name',selldata.product_name)
        Datatosubmit.append('description',selldata.product_description)
        Datatosubmit.append('price',selldata.product_price)
        Datatosubmit.append('measurement_scale',selldata.product_scale)
        Datatosubmit.append('harvest_date',selldata.product_harvestdate)
        Datatosubmit.append('quantity_available',selldata.product_available)
        Datatosubmit.append('bank_name',selldata.bank_name)
        Datatosubmit.append('account_name',selldata.account_name)
        Datatosubmit.append('account_number',selldata.account_number)  
        

          if( selldata.product_img1 ){
              Datatosubmit.append('product_img1',file1.image,file1.image.name)
          }

          if( selldata.product_img2 ){
            Datatosubmit.append('product_img2',file2.image,file2.image.name)
          }

          if( selldata.product_img3  ){
            Datatosubmit.append('product_img3',file3.image,file3.image.name)
          }


          Axios.patch('/product/' + i_d + '/' ,Datatosubmit )
          .then( Response => {
            setinitialpictures({
              product_img1:Response.data.product_img1,
              product_img2:Response.data.product_img2,
              product_img3:Response.data.product_img3,
            })
            
            var Addressdet = {
              suitable_van: selldata.transport_means,
              can_carry: selldata.amount_can_carry,
              country: selldata.country,
              state: selldata.state,
              lga: selldata.Lga,
              address: selldata.address,
              longitude: selldata.longitude,
              latitude: selldata.latitude,
              area:selldata.area
            }

                Axios.patch( '/plocation/' + selldata.addressId + '/' ,  Addressdet ).then(
                  seterrormessage( { msg: 'Product was successfully updated' , status:true , bgcolor: 'rgb(39, 180, 39)' } )
                ).catch(
                  error => {
                    seterrormessage({
                      status:true,
                      msg:' Something Went Wrong ',
                      bgcolor:'red'
                    })
                  }
                )
          } ).catch( (error) => {
            if(error.response){
  
    
                if(error.response.data.quantity_available){
                  seterrormessage({
                    status:true,
                    msg:'Make sure that the quantity available is less than or equals to 2500 ',
                    bgcolor:'red'
                  })
                }else{
                  seterrormessage({
                    status:true,
                    msg:' Something Went Wrong ',
                    bgcolor:'red'
                  })
                }
    
            }
        } );


            }

      }else{
      }

    }


    ////////////////////
    //=====================================


    if( scroll ){
      var lam = window.scrollTo(1,1)
      setscroll(false)
     }




     if(editableproduct && selldata.product_name === null  ){

      var addnum = 0

       setselldata({
        product_name: editableproduct.product_name,
        product_description:editableproduct.description,
        product_price:editableproduct.price,
        product_scale:editableproduct.measurement_scale,
        product_available:editableproduct.quantity_available,
        product_harvestdate:editableproduct.harvest_date,
        transport_means: editableproduct.address[addnum].suitable_van,
        amount_can_carry:editableproduct.address[addnum].can_carry,
        country:editableproduct.address[addnum].country,
        state:editableproduct.address[addnum].state,
        Lga:editableproduct.address[addnum].lga,
        address:editableproduct.address[addnum].address,
        longitude:editableproduct.address[addnum].longitude,
        latitude:editableproduct.address[addnum].latitude ,
        addressId:editableproduct.address[addnum].id,
        area:editableproduct.address[addnum].area,
        account_name:editableproduct.account_name,
        account_number:editableproduct.account_number,
        bank_name:editableproduct.bank_name
      })
      setinitialpictures({
        product_img1:editableproduct.product_img1,
        product_img2:editableproduct.product_img2,
        product_img3:editableproduct.product_img3,
      })
      setfile1({image:null,preview:editableproduct.product_img1})
      setfile2({image:null,preview:editableproduct.product_img2})
      setfile3({image:null,preview:editableproduct.product_img3})
     }


     const myPopup = (SearchInfo) => {

      // console.log(SearchInfo)
  
      return(
                  <Popup>
                      <p style={{ fontWeight:'800'}}>
                        {SearchInfo.info}
                      </p>
                      <button className="Mappupop_btn" onClick={ 
                          () => setAllUserlocationdetails(SearchInfo)
                       } > Select Location </button>
                  </Popup>
      );
    }
  
  
  // Map Address issues
  
    const setAllUserlocationdetails = (SearchInfo) => {
  
      setselldata({
        ...selldata,
        mapstory:'Please wait , this might take some time...  '
      })
  
      setselldata({
        ...selldata,
        latitude:SearchInfo.latLng.lat,
        longitude:SearchInfo.latLng.lng,
        mapstory:'Location was successfully saved..',
          area:SearchInfo.info
      })
  
      // setselldata({
      //   ...selldata,
      //   mapstory:'Search and select the closest place to your farm on the map',
      // })
  
      setopenMap(false)
    }



      return ( 

        <> 

        <Backdrop show={openMap} />

        { openMap ?
         <LeafletMapDiv 
         myPopup={ myPopup }
         story={ selldata.mapstory }  
           closeMap={ () => setopenMap(false) }  /> 
          :null  }

        <TopbannerDiv
         message={errormessage.msg}
         backgroundcolor={errormessage.bgcolor}
         show={errormessage.status}
         closeshow={ () => seterrormessage({...errormessage,status:false}) }
          />

        <div className="editproduct-page-div" >

            {lam}

            <Selltemplate
             whataction='Edit product'
             productnamevalue={selldata.product_name}
             productnameonChange={productnameonchangeHandler}
             productdescriptionvalue={selldata.product_description}
             productdescriptiononChange={productdescriptiononchangeHandler}
             productpricevalue={selldata.product_price}
             productpriceonChange={productpriceonchangeHandler}
             productscalevalue={selldata.product_scale}
             productscaleonChange={productscaleonchangeHandler}
             productavailablevalue={selldata.product_available}
             productavailableonChange={productavailableonchangeHandler}
             productharvestdatevalue={selldata.product_harvestdate}
             productharvestdateonChange={productharvestdateonchangeHandler}
             choosefirstimage={choosefirstimageHandler}
             previewfirstimage={file1.preview}
             story1={story1.story}
             error1={story1.storyerror}
             choosesecondimage={choosesecondimageHandler}
             previewsecondimage={file2.preview}
             story2={story2.story}
             error2={story2.storyerror}
             choosethirdimage={choosethirdimageHandler}
             previewthirdimage={file3.preview}
             story3={story3.story}
             error3={story3.storyerror}
             sellproduct={sellproductHandler}
             buttonoption='Save Changes'
             select_trans_1={ () => setselldata( {...selldata,transport_means:'tricycle'} ) }
             selected_mean_1={ selldata.transport_means === 'tricycle' ? true : false }
             select_trans_2={ () => setselldata( {...selldata,transport_means:'cabstar'} ) }
             selected_mean_2={ selldata.transport_means === 'cabstar' ? true : false } 
             select_trans_3={ () => setselldata( {...selldata,transport_means:'trailer'} ) }
             selected_mean_3={ selldata.transport_means === 'trailer' ? true : false }

             amoutcancarry={ selldata.amount_can_carry }
             onChangeamoutcancarry={ (event) => setselldata({...selldata,amount_can_carry:event.target.value}) }

                          //Address part

                          countryvalue={ selldata.country }
                          countryonChange={ (event) => setselldata({...selldata,country:event.target.value}) }
             
                          statevalue={ selldata.state }
                          stateonChange={ (event) => setselldata({...selldata,state:event.target.value}) }
             
                          lgavalue={ selldata.Lga }
                          lgaonChange={ (event) => setselldata({...selldata,Lga:event.target.value}) }
             
                          farmaddressvalue={ selldata.address }
                          farmaddressonChange={ (event) => setselldata({...selldata,address:event.target.value}) }
             
                          //
             
                          //Map Longitude and latitude
             
                          latitudevalue={ selldata.latitude }
                          // latitudeonChange={ (event) => setselldata({...selldata,latitude:event.target.value}) }
             
                          
                          longitudevalue={ selldata.longitude }
                          // longitudeonChange={ (event) => setselldata({...selldata,longitude:event.target.value}) }

                          mapareaValue={ selldata.area }

                          Openmap={ () => setopenMap(true) }
             
                          //

                          accountname={ selldata.account_name }
                          accountnameonChange={ (event) => setselldata({ ...selldata , account_name:event.target.value }) }
            
                          accountnumber={ selldata.account_number }
                          accountnumberonChange={ (event) => setselldata({ ...selldata , account_number: event.target.value  }) }
                          
                          bankname={ selldata.bank_name }
                          banknameonChange={ (event) => setselldata({ ...selldata , bank_name: event.target.value })  }
            
             

              /> 

        </div>

        <Footerdiv/>

        </>

      );

}

export default Sellpage;