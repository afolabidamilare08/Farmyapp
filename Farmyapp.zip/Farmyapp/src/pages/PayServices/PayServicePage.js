import React , { useState, useEffect } from 'react';
import { PayServiceList } from '../PayProducts/paylist/paylist';
import Axios from 'axios';
import Loading2 from '../../component/utilities/loading2/loading2';
import TopbannerDiv from '../../component/utilities/top-banner-msg/topbannermsg';
import Business from './hand.png';

const ServicePayPage = (props) => {

  const [ AllTransaction , setAllTransaction ] = useState(null)
  const [ message , setmessage ] = useState({
    msg:'',
    status:false,
    bgColor:''
  })

  useEffect( () => { 
      Axios.get('/sorder/dodo/?limit=10000000').then( 
        response => {
          setAllTransaction(response.data.results)
        }
       )
  } , [] )

  const PayTraderHandler = (id) => {

      setmessage( {
        msg:'Paying Trader .....',
        status:true,
        bgColor:'orange'
      } )

      const OrderIndex = AllTransaction.findIndex( i => {
        return i.id === id
      } )

      Axios.patch('/sorder/' + id + '/' , { cleared:true } ).then(
        response => {
          var oldTransaction = [...AllTransaction]
            oldTransaction.splice(OrderIndex,1)
            setAllTransaction(oldTransaction)
            setmessage( {
              msg:'Trader Paid',
              status:true,
              bgColor:'rgba(13, 194, 94, 0.986)'
            } )
        }
      )

  }

  if (AllTransaction) {

    var AllUnpaid = []

    for (let g = 0; g < AllTransaction.length; g++) {
        if( AllTransaction[g].cleared === false && AllTransaction[g].status === 'serviced' ){
          AllUnpaid.push(AllTransaction[g] )
        }
    }

    if( AllUnpaid.length > 0 ){
      var okletit = AllUnpaid.map( ract => {

        if( ract.cleared === false ){
          return <PayServiceList
          first_name={ract.service.user.first_name}
          last_name={ract.service.user.last_name}
          Bname={ract.service.bank_name}
          Aname={ract.service.account_name}
          Anumber={ract.service.account_number}
          Pname={ract.service.service_name}
          key={ ract.id }
          Pprice={ract.paying}
          payTrader={ () => PayTraderHandler(ract.id) }
        />
        }
  
        return null
  
      } )
    } 
    
    else{
      if( AllUnpaid.length < 1 ) {
        okletit = <div className="UserproductPage-div_page_empty" style={{
          backgroundColor:'white',borderRadius:'5px',
          boxShadow:' 0 .5rem 1rem rgba(0,0,0,.25)'
        }} >
                    <img src={Business} alt="" className="UserproductPage-div_page_empty_img" />
                    <div className="UserproductPage-div_page_empty_text" style={{
                      textAlign:'center'
                    }} > Good Job Uncle Ola You Have Successfully Paid All FarmyApp Traders , You Deserve A Medal </div>
                  </div>
      }
    }

  }else{
    okletit = <Loading2/>
  }
  
      return ( 
        <>

        <TopbannerDiv
          show={message.status}
          closeshow={ () => setmessage({...message,status:false}) }
          message={ message.msg }
          backgroundcolor={message.bgColor}
          />

        <div className="PayProductPage-div" >

            <div className="PayProductPage-div-top" >
                Pay Service Order
            </div>

            <div className="PayProductPage-div-mid" >
                {okletit}
            </div>
          
        </div>
        </>
      );

}

export default ServicePayPage;