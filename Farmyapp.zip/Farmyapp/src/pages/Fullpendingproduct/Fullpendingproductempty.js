import React from 'react';

const PendingEmpty = (props) => {

      return (
          <div className="pendingEmpty-div" >
            {/* <img src={props.img} className="pendingEmpty-div-img" alt="" /> */}
            {props.narate}
          </div> 
      );

}

export default PendingEmpty;
