import React, { useState, useEffect } from 'react';
import TopbannerDiv from '../../component/utilities/top-banner-msg/topbannermsg';
import Backdrop from '../../component/utilities/Backdrop/backdrop';
import Axios from 'axios';
import { OrderWithDelivery } from '../../component/orderListTemplate/orderListTemplate';
import BtnSpin from '../../component/utilities/btnSpin/btnSpin';
import PendingEmpty from './Fullpendingproductempty';
import LoadingPage from '../../foods/components/loading/loading';
import OppsPage from '../../foods/components/oppspage/oppspage';
import ProfileHeader from '../../foods/layout_components/profile_header/profile_header';

const FullpendingProduct = (props) => {

    var mainId = props.match.params.id

    const [ Loadingpage , setLoadingpage ] = useState(false)
    const [ Errorpage , setErrorpage ] = useState(false)
    const [ productTobereviewed , setproductTobereviewed ] = useState(null)
    const [ penddingList , setpenddingList ] = useState(null)
    const [ intransitList , setintransitList ] = useState(null)
    const [ TheSpin , setTheSpin ] = useState(false)
    const [ deliveredList , setdeliveredList ] = useState(null)
    const [ whichtoshow , setwhichtoshow ] = useState('pending')
    const [ message , setmessage ] = useState({
        status:false,
        msg:'',
        bgColor:''
    })

    useEffect( () => {
        
        setLoadingpage(true)
        setErrorpage(false)
        
        Axios.get( '/product/' + mainId + '/' ).then(
            response => {
                setproductTobereviewed(response.data)
                setLoadingpage(false)
                setErrorpage(false) 
            }
        ).catch(
            e => {
                setLoadingpage(false)
                setErrorpage(false)
            }
        );


    } , [mainId] )







    const changeItToTransitHandler = (sentId) => {

        setmessage({
            status:false,
            msg:'Changing Order status',
            bgColor:'orange'
        })

        setTheSpin(true)

        const OrderIndex = penddingList.findIndex( i => {
            return i.id === sentId
          } )

        var chosenOrder = penddingList[OrderIndex]
        
        
        Axios.patch('/orders/order_items/' + chosenOrder.id + '/' , {status:'in_transit'} ).then(
            response => {
                

                var NewArray = [...penddingList]

                NewArray.splice(OrderIndex,1)

                var currentOrder = {  ...chosenOrder , status:'in_transit' }

                var Intransit = [ ...intransitList ]

                Intransit.push(currentOrder)

                setintransitList(Intransit)

                setpenddingList( NewArray  )
                // rgba(13, 194, 94, 0.986)
                setTheSpin(false)
                setmessage({
                    status:true,
                    msg:'Order status changed',
                    bgColor:'rgba(13, 194, 94, 0.986)'
                })

            }
        ).catch( error => {
            setmessage({
                status:true,
                msg:'Something Went Wrong , Try Agian',
                bgColor:'red'
            })
            setTheSpin(false)
        } )
        

    } 

    if( productTobereviewed && !penddingList && !intransitList && !deliveredList ){

        var minipending = []
        var minidelivered = []
        var miniintransit = []

        for (let g = 0; g < productTobereviewed.itemOrdered.length; g++) {
            
            var safe = productTobereviewed.itemOrdered[g]

            if( safe.status === 'delivered' ){
                minidelivered.push(safe)
            }

            if( safe.status === 'paid' ){
                minipending.push(safe)
            }

            if( safe.status === 'in_transit' ){
                miniintransit.push(safe)
            }

        }

        setpenddingList(minipending)
        setdeliveredList(minidelivered)
        setintransitList(miniintransit)

    }

    if( penddingList ){
        if( penddingList.length > 0 ){
            var mappingpending = penddingList.map( list => {
                return <OrderWithDelivery
                        key={list.id}
                        status='pending'
                        bgColor='orange'
                        productName={list.product.product_name}
                        Orderimg={'https://farmyapp.xyz' + list.product.product_img1}
                        quantity={ list.quantity } 
                        measurement_scale={ list.product.measurement_scale }
                        product_cost={ list.get_cost }
                        tfare={ list.get_tfare }
                        theFirst_name={list.order.user.first_name}
                        theLast_name={list.order.user.last_name}
                        theNumber={ list.order.user.pro.phone_number }
                        totalcost={ list.get_bsolute }
                        showAddress={ list.order.address[0] }
                        address={ list.order.address[0] ? list.order.address[0].address : '' }
                        lga={ list.order.address[0] ? list.order.address[0].lga : '' }
                        state={ list.order.address[0] ? list.order.address[0].state : '' }
                        switchtointransit={ list.order.address[0] ? true : false }
                        ChangeTointransit={()=>changeItToTransitHandler(list.id)}
                    />
            } )

        }else{
             mappingpending = <PendingEmpty narate=" You Don't Have Any Pending Order Left " />
        }
    }


    if( intransitList ){
        if( intransitList.length > 0 ){

            var mappingintransit = intransitList.map( list => {
                return <OrderWithDelivery
                        // width='95%' 
                            key={list.id}
                            status='in transit'
                            bgColor='rgb(50, 127, 241)'
                            productName={list.product.product_name}
                            Orderimg={'https://farmyapp.xyz' + list.product.product_img1}
                            quantity={ list.quantity } 
                            measurement_scale={ list.product.measurement_scale }
                            product_cost={ list.get_cost }
                            tfare={ list.get_tfare }
                            theFirst_name={list.order.user.first_name}
                            theLast_name={list.order.user.last_name}
                            theNumber={ list.order.user.pro.phone_number }
                            totalcost={ list.get_bsolute }
                            showAddress={ list.order.address[0] }
                            address={ list.order.address[0] ? list.order.address[0].address : '' }
                            lga={ list.order.address[0] ? list.order.address[0].lga : '' }
                            state={ list.order.address[0] ? list.order.address[0].state : '' }
                            />
            } )

        }else{
            mappingintransit = <PendingEmpty narate=" You Don't Have Any Order Currently In Transit " />
        }
    }

    if( deliveredList ){
        if( deliveredList.length > 0 ){

            var mappingdelivered = deliveredList.map( list => {
                return <OrderWithDelivery
                        // width='95%' 
                        key={list.id}
                        status='delivered'
                        bgColor='rgba(13, 194, 94, 0.986)'
                        productName={list.product.product_name}
                        Orderimg={'https://farmyapp.xyz' + list.product.product_img1}
                        quantity={ list.quantity } 
                        measurement_scale={ list.product.measurement_scale }
                        product_cost={ list.get_cost }
                        tfare={ list.get_tfare }
                        theFirst_name={list.order.user.first_name}
                        theLast_name={list.order.user.last_name}
                        theNumber={ list.order.user.pro.phone_number }
                        totalcost={ list.get_bsolute }
                        showAddress={ list.order.address[0] }
                        address={ list.order.address[0] ? list.order.address[0].address : '' }
                        lga={ list.order.address[0] ? list.order.address[0].lga : '' }
                        state={ list.order.address[0] ? list.order.address[0].state : '' }
                        />
            } )

        }else{
            mappingdelivered = <PendingEmpty img narate=" You Have Not Delivered Any Of Your Product " />
        }
    }








      const gogo = () => {
        props.history.go()
      } 
    
      const goBack = () => {
        props.history.goBack()
      }
    
    
      if( Loadingpage && !productTobereviewed && !Errorpage && !penddingList && !intransitList && !deliveredList ){
        var what_to_return = <LoadingPage/>
      }else{
        if ( !Loadingpage && Errorpage && !productTobereviewed && !penddingList && !intransitList && !deliveredList ) {
          what_to_return = <OppsPage tryagain={gogo} goback={goBack} />
        }else{
          if ( !Loadingpage && !Errorpage && productTobereviewed && penddingList && intransitList && deliveredList ) {
            what_to_return = 
            <>
              
                  <div className="retailcartpage" style={{
                      margin: '0rem auto',
                      padding:'5rem 0rem',
                  }} >
  
  
                      <div className="retailproductpage-specs-top" >
  
                          <div className="retailproductpage-specs-top-li" onClick={ () => setwhichtoshow('pending') } style={{
                              borderBottom: whichtoshow === 'pending' ? '2px solid #49A010' : '2px solid transparent'
                          }} > Pending Orders ({penddingList.length}) </div>
                          <div className="retailproductpage-specs-top-li" onClick={ () => setwhichtoshow('In-Transit') } style={{
                              borderBottom: whichtoshow === 'In-Transit' ? '2px solid #49A010' : '2px solid transparent'
                          }} > In Transit Orders ({intransitList.length}) </div>
                          <div className="retailproductpage-specs-top-li" onClick={ () => setwhichtoshow('Delivered') } style={{
                              borderBottom: whichtoshow === 'Delivered' ? '2px solid #49A010' : '2px solid transparent'
                          }} > Delivered Orders ({deliveredList.length}) </div>
  
                      </div>
  
                      <>
  
                      { whichtoshow === 'pending' && penddingList ? mappingpending : null }
                      { whichtoshow === 'In-Transit' && intransitList ? mappingintransit : null }
                      { whichtoshow === 'Delivered' && deliveredList ? mappingdelivered : null }
  
                      </>
  
  
                  </div>
  
  
            </>
       
          }
        }
      }







      return ( 

        <>

                <ProfileHeader
                    title="My Product Orders"
                    goback={ goBack }
                />

                <TopbannerDiv
                  show={ message.status }
                  backgroundcolor={ message.bgColor }
                  closeshow={ () => setmessage({...message,status:false}) }
                  message={ message.msg }
                  />
  
                  <Backdrop show={TheSpin} >
                      <BtnSpin bgColor="white" />
                  </Backdrop>  


                  {what_to_return}

        </>

     );

}

export default FullpendingProduct;