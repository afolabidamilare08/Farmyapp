import React, { useEffect } from 'react';
import { store } from 'react-notifications-component';
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';
// import Img1 from '../component/utilities/12.jpg';
// import Img2 from '../component/utilities/13.jpg';
// import Img3 from '../component/utilities/14.jpg';
// import Img4 from '../component/utilities/15.jpg';

const Notify = (props) => {

    useEffect( () => {
        store.addNotification({
            title: "Wonderful!",
            message: "teodosii@react-notifications-component",
            type: "success",
            insert: "top",
            container: "top-right",
            animationIn: ["animate__animated", "animate__fadeIn"],
            animationOut: ["animate__animated", "animate__fadeOut"],
            dismiss: {
              duration: 5000,
              onScreen: true
            }
          });
    } , [] ) 

    return (
            <>
            
                <div style={{
                    fontFamily:'AssistantRegular'
                }} >
                    dwwdwd
                </div>

                <Carousel
                    autoPlay={true}
                    interval="2000"
                    infiniteLoop={true}
                    useKeyboardArrows={true}
                    emulateTouch={true}
                    showStatus={false}
                    showThumbs={false}
                    
                   >
                {/* <div>
                    <img src={Img1} />
                    <p className="legend">Legend 1</p>
                </div>
                <div>
                    <img src={Img2} />
                    <p className="legend">Legend 2</p>
                </div>
                <div>
                    <img src={Img3} />
                    <p className="legend">Legend 3</p>
                </div> */}
            </Carousel>

            </>
    );
}

export default Notify;