import React from 'react';
import {Route,Switch} from 'react-router-dom';
import Home from '../../pages/home/home';
import Loginpage from '../../pages/login-page/loginpage';
import Registerpage from '../../pages/register-page/register-page';
import ProductFullPage from '../../pages/full-display-of-product/productFullDisplaypage';
import Sellpage from '../../pages/sell-page/sellpage';
import Cartpage from '../../pages/cart-page/cart-page';
import CheckoutPage from '../../pages/checkout_page/checkout_page';
import Searchpage from '../../pages/search-page/searchpage';
import Editproduct from '../../pages/editproduct/editproduct';
import Homepag from '../../pages/moreproduct/moreproduct';
import Axios from 'axios';
import ResetPasswordPage from '../../pages/reset_password/reset_Password';
import OtherUserprofilepage from '../../pages/otherUserprofilepage/otherUserprofilepage';
import FullOrderDiv from '../../pages/FullMyorder/fullmyorder';
import Finalcheckout from '../../pages/checkout_page/FinalCheckoutPage/finalcheckout';
import FullpendindServPage from '../../pages/FullpendingServ/fullpendingserv';
import FullpendingProduct from '../../pages/Fullpendingproduct/Fullpendingproduct';
import ProductPayPage from '../../pages/PayProducts/payProducts';
import ServicePayPage from '../../pages/PayServices/PayServicePage';
import Referal_Loginpage from '../../pages/referal_login_page/referal_login_page';
import ReferalRealLogin from '../../pages/referal_Real_login/referal_Real_login';




const Body  = props => {

if( Axios.defaults.headers.common['Authorization'] ){

    var Availableroute =
        <div className="body-div" >
            <Switch>
            <Route path="/wholesale"  exact component={Home} />
            <Route path="/signin"   component={Home} />
            <Route path="/signup"   component={Home} />
            <Route path="/product:slug::id" exact component={ProductFullPage} />
            <Route path="/sell"  component={Sellpage} />
            <Route path="/cart" component={Cartpage} />
            <Route path="/checkout" component={CheckoutPage} />
            <Route path="/search:query::address::offset" component={Searchpage} />
            <Route path="/search:query::offset" component={Searchpage} />
            <Route path="/servfull:id" exact component={FullpendindServPage} />
            <Route path="/editproduct:slug::id" component={Editproduct} />
            <Route path="/more:limit::offset" exact component={Homepag} />
            <Route path="/resetPassword" exact component={Home}  />
            <Route path="/passwordreset/:uid/:tok" exact component={Home} />
            <Route path="/user:id" exact component={OtherUserprofilepage} />
            <Route path="/allordersfull:id" exact component={FullpendingProduct} />
            <Route path="/fullorder:id" exact component={FullOrderDiv} />
            <Route path="/finalcheckout:id" exact component={Finalcheckout} />
            <Route path="/payproducts" exact component={ ProductPayPage } />
            <Route path="/payservice" exact component={ServicePayPage} />
            <Route path="/refer_user:id" exact  component={Home} />
            <Route path="/signin_ref:id" exact  component={Home} />
            </Switch>
        </div>
}
else {
    Availableroute =

        <div className="body-div">
            <Route path="/"  exact component={Home} />
            <Route path="/signin"   component={Loginpage} />
            <Route path="/signup"   component={Registerpage} />
            <Route path="/full" component={ProductFullPage} />
            <Route path="/signin_ref:id" exact  component={ReferalRealLogin} />
            <Route path="/sell" component={Loginpage} />
            <Route path="/product:slug::id" exact component={ProductFullPage} />
            <Route path="/cart" component={Loginpage} />
            <Route path="/editproduct:slug::id" component={Loginpage} />
            <Route path="/search:query::address::offset" component={Searchpage} />
            <Route path="/search:query::offset" component={Searchpage} />
            <Route path="/checkout" component={Loginpage} />
            <Route path="/more:limit::offset" exact component={Homepag} />
            <Route path="/resetPassword" exact component={ResetPasswordPage}  />
            <Route path="/passwordreset/:uid/:tok" exact component={Home} />
            <Route path="/user:id" exact component={OtherUserprofilepage} />
            <Route path="/fullorder:id" exact component={FullOrderDiv} />
            <Route path="/finalcheckout:id" exact component={Home} />
            <Route path="/allordersfull:id" exact component={Home} />
            <Route path="/payproducts" exact component={ Loginpage } />
            <Route path="/payservice" exact component={Loginpage} />
            <Route path="/refer_user:id" exact  component={Referal_Loginpage} />
        </div>
}

    return (

        Availableroute

    );
}
export default Body ;
