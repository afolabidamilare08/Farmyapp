import React , { useState } from 'react';
import Header from './header/header';
import Body from './body/body';
import Store from '../store/managementstore/gobackstore';

const Layout = (props) => {

    const [ searchquery , setsearchquery ] = useState('');
    const [ addressquery , setaddressquery ] = useState('');

    const changequery = (event) => {
        setsearchquery(event.target.value)
    }   

    const senddata = (e) => {
        e.preventDefault()

        if( searchquery !== '' ){
            if( addressquery === '' ){
                props.history.push('/search' + searchquery + ':' + 0 )
            }else{
                props.history.push('/search' + searchquery + ':' + addressquery + ':' + 0 )
            }

        }else{
            props.history.push('#')
        }
    }

    // var history = props.history
    // console.log(history)


    const Goback = () => {
        props.history.goBack()
    }

    
    return (
            <Store.Provider value={{
                gobackFunc:Goback
            }} >

            <Header
            
             searchquery={searchquery}
             changequery={changequery}
             whereonChange={ (event) => setaddressquery(event.target.value) }
             wherevalue={ addressquery }
             search={senddata}
             placeholder={"What are you looking for .... ?"}
             towhere='/wholesale' />
            <Body/>

            </Store.Provider>
    )
}

export default Layout;