import React , { useState } from 'react';
import Logoimg from './headerleftslide/olaiya1.png';
import Svg from '../../../component/utilities/Svg';
import {Link} from 'react-router-dom';
import Leftslide from './headerleftslide/headerleftslide';

const Logo = props => {

    const [ openslide , setopenslide ] = useState(false)

    const closeslide = () => {
        setopenslide(false)
    }

    const openslideup = () => {
        setopenslide(true)
    }
    
    return  (
        

        <Link to={props.towhere} className="header-logo" >

            <Leftslide 
                show={openslide}
                closebackdrop={closeslide}
                 />
            
            <div to="#" className="header-logo-menu"  onClick={openslideup} >
                <Svg
                  className="header-logo-menu-ic"
                  href="contact.svg#icon-dehaze"   />
            </div>

            <div className="header-logo-1" >
                <img src={Logoimg} className="header-logo-1-img" alt="" />
            </div>
{/* 
            <Link to={props.towhere} className="header-logo-2" >
                <span className="header-logo-2-f" >Farmy<span className="header-logo-2-a" >App</span></span>
            </Link> */}

        </Link>

    );

}

export default Logo;