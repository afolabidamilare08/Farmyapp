import React from 'react';
import {NavLink} from 'react-router-dom';
import Svg from '../../../../../component/utilities/Svg';

const Leftslidelink = (props) => {

      return ( 

        <NavLink className="leftslidelink" onClick={props.onClick} to={props.to} activeStyle={ props.active ? { color: 'white' , backgroundColor: 'green' } : {color:'',backgroundColor:''} } >
            <Svg
             href={props.icon}
             className="leftslidelink-ic" />
            <span className="leftslidelink-span" > {props.name} </span>
        </NavLink>

      );

}

export default Leftslidelink;