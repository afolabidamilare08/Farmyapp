import React from 'react';
import Logo from './olaiya1.png';

const Leftlogoslide = (props) => {

      return ( 

        <div className="headerleftslide-div-logo" style={ { justifyContent: props.dahze ? '' : 'center' } } >

            { props.dahze }

            <div className="headerleftslide-div-logo-img" >
            <img src={Logo} className="headerleftslide-div-logo-img-img" alt="" />
            </div>
            {/* <div className="headerleftslide-div-logo-name" >
                <span className="headerleftslide-div-logo-name-farmy" style={ { color : props.setcolor } } >Farmy</span>
                <span className="headerleftslide-div-logo-name-app" style={ { color : props.setcolor2 } } >App</span>
            </div> */}
        </div> 

      );

}

export default Leftlogoslide;