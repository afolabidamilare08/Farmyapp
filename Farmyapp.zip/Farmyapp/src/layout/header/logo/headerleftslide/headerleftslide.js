import React  from 'react';
import Backdrop from '../../../../component/utilities/Backdrop/backdrop';
// import Leftslidelogo from './leftlogoslide';
// import {Link} from 'react-router-dom';
// import Svg from '../../../../component/utilities/Svg';
// import Navlist from './leftslidelinks/leftslidelink';
// import Store from '../../../../store/managementstore/managementstore';

const Headerleftslide = (props) => {

    // const context = useContext(Store)


    // var dahze =  <Link to="#" className="headerleftslide-div-logo-link" onClick={props.closebackdrop} >
    //                 <Svg
    //                 className="headerleftslide-div-logo-link-ic"
    //                 href="contact.svg#icon-dehaze" />
    //             </Link>

      return ( 
        <>
            <Backdrop backgroundColor='transparent' show={props.show} closebackdrop={props.closebackdrop} />
            <div className="headerleftslide-div" style={ 
                {transform: props.show ? 'translateY(0)' : 'translateX(-100vh)',
                opacity: props.show ? '1' : '0'}
             } >

                     {/* <Leftslidelogo
                      dahze={dahze} /> */}

                 <div className="headerleftslide-div-nav" >
                        {/* <Navlist
                         to="/"
                         icon="contact.svg#icon-home"
                         name="Home"
                         onClick={props.closebackdrop}  />

                         <Navlist
                          to="/sell"
                          icon="sprite3.svg#icon-store_mall_directorystore"
                          name="Sell"
                          // active
                          onClick={props.closebackdrop}  />

                        <Navlist
                          to='/services'
                          icon="sprite3.svg#icon-build"
                          name="Services"
                          // active
                          onClick={props.closebackdrop}  />

                        <Navlist
                          to='/cart'
                          icon="sprite3.svg#icon-cart"
                          name="Cart"
                          // active
                          
                          onClick={props.closebackdrop}/>

                        <Navlist
                          to='/profile'
                          icon="contact.svg#icon-person"
                          name={context.User_id && context.Token ? 'Profile' : 'Sign-In' }
                          // active
                          onClick={props.closebackdrop}  />
     */}
                 </div>

            </div>
        </>

      );

}

export default Headerleftslide;