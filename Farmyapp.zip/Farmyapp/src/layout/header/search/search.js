import React  from 'react';
import Svg from '../../../component/utilities/Svg';

const Headersearch = (props) => {
  

    return (
        <form className="header-search" onSubmit={props.search} style={{
            backgroundColor: 'rgba(255, 255, 255, 0.897)'
        }} >

            <input type="search" className="header-search-input-1" onChange={props.changequery} value={props.searchquery}  placeholder={props.placeholder} />

            <input type="text" className="header-search-input-2" onChange={props.whereonChange} value={props.wherevalue} placeholder="City e.g Ibadan" />

            <button className="header-search-button" onClick={props.search} > 
                <span className="search-txt" >SEARCH</span>
                <Svg
                 className="search-ic"
                 href="contact.svg#icon-search" />
            </button>

        </form>
    );

}

export default Headersearch;