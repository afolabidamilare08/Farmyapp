import React from 'react';
import { Link } from 'react-router-dom';
import Svg from '../../../../component/utilities/Svg';

export const Noti1 = (props) => {

    return ( 

        <Link to={props.to} className="notificationList_1" onClick={props.close_notificationbox} >
            <div className="notificationList_1_img" >
                <img alt="" src={props.image} className="notificationList_1_img_img" />
            </div>
            <div className="notificationList_1_txt" >
                { props.recp_firstname + ' ' + props.recp_lastname  } {props.narration}
            </div>
        </Link>

     );

}

export const Noti2 = (props) => {

    return ( 

        <Link to={props.to} className="notificationList_1" onClick={props.close_notificationbox} >
            <div className="notificationList_1_img" >
                <Svg
                 className="notificationList_1_img_ic"
                 href="contact.svg#icon-person" />
            </div>
            <div className="notificationList_1_txt" >
                { props.recp_firstname + ' ' + props.recp_lastname  } {props.narration}
            </div>
        </Link>

     );
    
}


export const Noti3 = (props) => {

    return ( 

        <Link to={props.to} className="notificationList_1" onClick={props.close_notificationbox} >
            <div className="notificationList_1_img" >
                <Svg
                 className="notificationList_1_img_ic"
                 href="sprite4.svg#icon-handshake-o" />
            </div>
            <div className="notificationList_1_txt" >
                { props.recp_firstname + ' ' + props.recp_lastname  } {props.narration}
            </div>
        </Link>

     );
    
}