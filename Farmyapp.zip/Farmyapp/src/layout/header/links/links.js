import React,{useContext,useState, useEffect} from 'react';
import {Link1, Link2, NotificationLink , NotNotificationLink } from './link/link1';
import NotificationEmpty from './notificationEmpty.png';
import Store from '../../../store/managementstore/managementstore';
import HeaderStore from '../../../store/managementstore/header_store'
import { Noti1 , Noti2 , Noti3 } from './notificationList/notificationList'
import Backdrop from '../../../component/utilities/Backdrop/backdrop';
import Axios from 'axios';

const Links = (props) => {
 

    const context = useContext(Store)
    const context2 = useContext(HeaderStore)

    const [ openNotification , setopenNotification ] = useState(false)

    const [ Allnotifiactions , setAllnotifiactions ] = useState(null)

    const [ Unreadnotifications , setUnreadnotifications ] = useState('')

    if( context.Token && context.User_id ){
        var show =  <Link1 to="/profile" href="contact.svg#icon-person" name="PROFILE" />  
    }if( !context.Token || !context.User_id ){
        // context2.clearNotification()
        show = <Link1 to="/signin" href="contact.svg#icon-person" name="SIGN-IN" />
    }

    if( context.Token && context.User_id && !Allnotifiactions ){
        context2.addNotification()
        setAllnotifiactions(true)
    }

    useEffect( () => {
        context2.addNotification()
        // eslint-disable-next-line 
    } , [ context.User_id ] )

    // logic to show all types of notifications 

        if( context2.notificationsLists && context2.notificationsLists.length > 0  ){

            
            const not = context2.notificationsLists

            var unread = [] 
            var read=[]

            for (let h = 0; h < not.length; h++) {

                if( not[h].read === false ){
                    unread.push(not[h])
                }

                if( not[h].read === true ){
                    read.push(not[h])
                }

            }

           if( Unreadnotifications === '' ){
                setUnreadnotifications(unread)
           }


            var MappednotificationList = context2.notificationsLists.map( notification => {

                if( notification.verb === ' ordered for ' ){

                    if(notification.target){
                        var prodImg = 'http://127.0.0.1:8000' + notification.target.product_img1
                    }

                    return ( <Noti1
                            key={ notification.id }
                            recp_firstname={ notification.recipient.first_name }
                            recp_lastname={ notification.recipient.last_name }
                            image={ prodImg }
                            to={ '/mypendingproducts' }
                            narration={'Ordered for your product'}
                            close_notificationbox={ () => setopenNotification(false) }
                             /> )
                }

                if( notification.verb === ' replied your comment ' && notification.target.product ){

                    return ( <Noti2
                            key={notification.id}
                            recp_firstname={ '' }
                            recp_lastname={ '' }
                            to={ '/productreplies:' + notification.target.product }
                            narration={'Someone replied to your comment on a product'}
                            close_notificationbox={ () => setopenNotification(false) }
                             /> )
                }

                if( notification.verb === ' replied your comment ' && notification.target.service ){

                    return ( <Noti2
                            key={notification.id}
                            recp_firstname={ '' }
                            recp_lastname={ '' }
                            to={ '/fullserv'  + notification.target.slug + ':' + notification.target.id }
                            narration={'Someone replied to your comment on a service'}
                            close_notificationbox={ () => setopenNotification(false) }
                             /> )
                }

                
                if( notification.verb === ' commented on your product ' ){
                    return ( <Noti1
                            key={ notification.id }
                            recp_firstname={ '' }
                            recp_lastname={ '' }
                            image={ notification.target ? 'https://farmyapp.xyz' + notification.target.product_img1 : null }
                            to={ '/product'+ notification.target.slug + ':' + notification.target.id }
                            narration={'Someone commented on your product'}
                            close_notificationbox={ () => setopenNotification(false) }
                             /> )
                }

                if( notification.verb ===  " commented on your service "  ){
                    return ( <Noti1
                            key={ notification.id }
                            recp_firstname={ '' }
                            recp_lastname={ '' }
                            image={ notification.target ? 'https://farmyapp.xyz' + notification.target.service_img1 : null }
                            to={ '/fullserv'  + notification.target.slug + ':' + notification.target.id }
                            narration={'someone commented on your service'}
                            close_notificationbox={ () => setopenNotification(false) }
                             /> )
                }

                
                if( notification.verb ===  " Someone ordered for your product "  ){
                    return ( <Noti1
                            key={ notification.id }
                            recp_firstname={ '' }
                            recp_lastname={ '' }
                            image={ notification.target ? 'https://farmyapp.xyz' + notification.target.product_img1 : null }
                            to={ '/allordersfull' + notification.target.id }
                            narration={'Someone ordered for your product'}
                            close_notificationbox={ () => setopenNotification(false) }
                             /> )
                }

                if( notification.verb ===  "someone hired you"  ){
                    return ( <Noti3
                            key={ notification.id }
                            recp_firstname={ '' }
                            recp_lastname={ '' }
                            image={ notification.target ? 'https://farmyapp.xyz' + notification.target.product_img1 : null }
                            to={ '/mypendingservices' }
                            narration={'someone just hired you'}
                            close_notificationbox={ () => setopenNotification(false) }
                             /> )
                }

                return null

            })

        }else{
            MappednotificationList = <div className="header-right_notification_mid_empty" >

                    <img alt="" src={NotificationEmpty} className="header-right_notification_mid_empty_img" />

                    <div className="header-right_notification_mid_empty_txt" >
                        No Notifications
                    </div>

            </div>
        }

    //================


    const OpeningNotificationTab = (unreadnot) => {

        // setUnreadnotifications(unread.length)

        setopenNotification(!openNotification)

        if( unreadnot ){
            for (let j = 0; j < unreadnot.length; j++) {
            
                var Notific = unreadnot[j]
                
                Axios.patch('/notification/action/' + Notific.id + '/' , { read : true }  ).then(
                    response => {
                    }
                ).catch()
    
                // if ( Notific  ) {
                    
                // }
                
            }
        }

        setUnreadnotifications(null)

    } 


       var alllinks = (

            <>

            
               <Link2
                 to="/retail/cart"
                 notify={ context.User_details ? context.User_details.detail.carts[0].items.length : false  }
                 href="sprite3.svg#icon-cart"
                 name="CART" /> 

                { context.Token ?
                                <NotificationLink 
                                notify={ context2.notificationsLists && Unreadnotifications ? Unreadnotifications.length : false  }
                                href="sprite3.svg#icon-notifications" 
                                openNotification = { context2.notificationsLists ? () => OpeningNotificationTab( Unreadnotifications ) : null }
                                name="NOTIFICATIONS" />
                  : 
                  
                  <NotNotificationLink 
                  href="sprite3.svg#icon-notifications" 
                  name="NOTIFICATIONS"
                  />

                  }

                {show}

                <Link2
                 to="/sell"
                 name="SELL"    
                 href="sprite3.svg#icon-store_mall_directorystore" />

               <Link1
                 to="/services"
                //  notify={ context.User_details.detail ? context.User_details.detail.carts[0].items.length : false  }
                 href="sprite4.svg#icon-work"
                 name="SERVICES" /> 
               


            </>

        );

    return (  

        <div className="header-right" >

                <div className="header-right_notification" style={{
                    // display: openNotification ? 'block' : 'none',
                    transform: openNotification ? 'translateY(0)' : 'translateY(-70rem)' 
                }} >
                    
                    <div className="header-right_notification_top" >
                        Notifications
                    </div>

                    <div className="header-right_notification_mid" >

                        {MappednotificationList}

                    </div>

                </div>

                <Backdrop show={openNotification} backgroundColor="transparent" closebackdrop={ () => setopenNotification(false) }  />

                {/* <Link1
                 to="/"
                 name="Home"
                 href="sprite.svg#icon-home" />

                <Link1
                 to="#"
                 name="FarmyAsk"
                 href="sprite2.svg#icon-help" /> */}
                 {alllinks}
        </div> 

    );   

}

export default Links;