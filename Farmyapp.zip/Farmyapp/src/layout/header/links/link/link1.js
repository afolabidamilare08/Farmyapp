import React from 'react';
import {NavLink, Link} from 'react-router-dom';
import Svg from '../../../../component/utilities/Svg';

export const Link1 = (props) => {


    return (

    <NavLink className="header-right-link " to={props.to} activeStyle={{color:'rgba(0, 128, 0, 0.788)'}} >

            {props.notify ? <div className="header-right-link-len" > { props.notify } </div> : '' }

            <Svg
             className="header-right-link-ic" 
             href={props.href} />

            <div className="header-right-link-txt" >
                {props.name}
            </div>
        </NavLink>

    );

}

export const Link2 = (props) => {


    return (

    <NavLink className="headcartlink" to={props.to} activeStyle={{color:'rgba(0, 128, 0, 0.788)'}} >

            {props.notify ? <div className="header-right-link-len" > { props.notify } </div> : '' }

            <Svg
             className="header-right-link-ic"
             href={props.href} />

            <div className="header-right-link-txt" >
                {props.name}
            </div>
        </NavLink>

    );

}


export const NotificationLink = (props) => {


    return (

    <div className="headcartlink" onClick={props.openNotification} activestyle={{color:'rgba(0, 128, 0, 0.788)'}} >

            {props.notify ? <div className="notification-len" > { props.notify } </div> : '' }

            <Svg
             className="header-right-link-ic"
             href={props.href} />

            <div className="header-right-link-txt" >
                {props.name}
            </div>
        </div>

    );

}

export const NotNotificationLink = (props) => {


    return (

    <Link to="/signin" className="header-right-link"  >

            <Svg
             className="header-right-link-ic"
             href={props.href} />

            <div className="header-right-link-txt" >
                {props.name}
            </div>
    </Link>

    );

}


// sprite3.svg#icon-handshake-o