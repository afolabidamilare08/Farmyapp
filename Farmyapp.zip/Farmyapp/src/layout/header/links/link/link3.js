import React from 'react';
import {NavLink} from 'react-router-dom';
import Svg from '../../../../component/utilities/Svg';

const Link3 = (props) => {


    return (

    <div className="header_right_link3 headerlink-show" onClick={ props.openNotification } to={props.to} activeStyle={{color:'rgba(0, 128, 0, 0.788)'}} >

            {props.notify ? <div className="header_right_link3-len" > { props.notify } </div> : '' }

            <Svg
             className="header_right_link3-ic"
             href={props.href} />

            <div className="header_right_link3-txt" >
                {props.name}
            </div>
        </div>

    );

}

export default Link3;