import React from 'react';
import Svg from '../../../../component/utilities/Svg';
import {NavLink} from 'react-router-dom';

const Link2 = (props) => {

    return    (             
        <NavLink className="showmenu" to={props.to} 
            activeStyle={{color:'rgba(0, 128, 0, 0.788)'}} 
            >

            { props.notify ? <div className="showmenu-notify" > { props.notify } </div> : '' }

            <Svg
             className=" showmenu-ic"
             href={ props.icon } />

            <div className=" showmenu-txt" >
                { props.name }
            </div>
        </NavLink>
    );
}

export default Link2;