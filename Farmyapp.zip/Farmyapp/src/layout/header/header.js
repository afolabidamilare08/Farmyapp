import React , { useState , useContext } from 'react';
import Logo from './logo/logo';
import Search from './search/search';
import Links from './links/links';
import HeaderStore from '../../store/managementstore/header_store';
import Axios from 'axios';
import Store from '../../store/managementstore/managementstore';
import BackBtns from '../../component/user-profile-box/bottom_div/bottom_div'

const Header = props => {

    // console.log(props)

    const context = useContext(Store)

    const [ notificationsList , setnotificationsList ] = useState(null)


    const Addtonotification = () => {
        Axios({
            method:'GET',
            url:'/notification/notifications/' + context.User_id + '/'
        }).then( 
            response => {
                setnotificationsList(response.data.notification)
            }
         )
    }

    const FormatnotificationHandler = () => {
        setnotificationsList(null)
    }

    const GoBackFunction = () => {
        props.history.goBack()
    }

    return (

        < HeaderStore.Provider 
         value={{
            notificationsLists:notificationsList,
            clearNotification:FormatnotificationHandler,
            addNotification:Addtonotification,
            gobackFunc:GoBackFunction
         }}  >
 
        <header className="header" >
            
            <Logo
              towhere={props.towhere} />


            <Search
             changequery={props.changequery}
             searchquery={props.searchquery}
             search={props.search}
             placeholder={props.placeholder}
             whereonChange={props.whereonChange}
             wherevalue={props.wherevalue}
                />
            <Links
             services={props.services} />

        </header>
        
        <BackBtns showprofile />

        </ HeaderStore.Provider>
    );

}

export default Header;