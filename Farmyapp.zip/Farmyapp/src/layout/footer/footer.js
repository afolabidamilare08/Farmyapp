import React from 'react';
import {Link} from 'react-router-dom';
import Logo from '../header/logo/headerleftslide/olaiya1.png';
import {BsGift, BsHouse} from 'react-icons/bs'; 
import {FiUser} from 'react-icons/fi';
import { FaFacebookSquare,FaTwitterSquare,FaInstagramSquare,FaLinkedinIn, FaHome, FaBriefcase, FaUser, FaShoppingBag, FaShoppingBasket } from 'react-icons/fa';
// import { AiFillShop } from 'react-icons/ai';

const Footerdiv = (props) => {


      return ( 

        <>

        <div className="footer-div-sticky" >

            <div className="footer-div-sticky-link" >
                <Link to="/" className="footer-div-sticky-link-a" >
                    <FaHome className="footer-div-sticky-link-a-ic" />
                    <div className="footer-div-sticky-link-a-txt" > Home </div>
                </Link>
            </div>

            <div className="footer-div-sticky-link" >
                <Link to="/" className="footer-div-sticky-link-a" >
                    <FaShoppingBasket className="footer-div-sticky-link-a-ic" />
                    <div className="footer-div-sticky-link-a-txt" > Foods </div>
                </Link>
            </div>

            <div className="footer-div-sticky-link" >
                <Link to="/services" className="footer-div-sticky-link-a" >
                    <FaBriefcase className="footer-div-sticky-link-a-ic" />
                    <div className="footer-div-sticky-link-a-txt" > Services </div>
                </Link>
            </div>

            <div className="footer-div-sticky-link" >
                <Link to="/profile" className="footer-div-sticky-link-a" >
                    <FaUser className="footer-div-sticky-link-a-ic" />
                    <div className="footer-div-sticky-link-a-txt" > Profile </div>
                </Link>
            </div> 

        </div>

        <div className="footer-div" >

            <div className="footer-div-top" >
                <Link to="/" className="footer-div-top-img" >
                        <img alt="" src={Logo} className="footer-div-top-img-img" />
                </Link>
                {/* <Link to="/" className="footer-div-top-link" >
                    <span className="footer-div-top-link-farmy" >Farmy</span>App
                </Link> */}
            </div>

            <div className="footer-div-others" >

                <div className="footer-div-others-contact" >

                    <div className="footer-div-others-contact-top" >
                        Follow Us On
                    </div>

                    <div className="footer-div-others-contact-mid" >
                        
                        <a href="https://web.facebook.com/FarmyApp-102367451372172" className="footer-div-others-contact-mid-link" >

                            <FaFacebookSquare className="footer-div-others-contact-mid-link-ic" />

                            <span className="footer-div-others-contact-mid-link-txt" > Facebook </span>
                        </a>

                        <a href="https://twitter.com/farmyapp" className="footer-div-others-contact-mid-link" >

                            <FaTwitterSquare className="footer-div-others-contact-mid-link-ic" />

                            <span className="footer-div-others-contact-mid-link-txt" > Twitter </span>
                        </a>

                        <a href="https://www.instagram.com/farmyapp/" className="footer-div-others-contact-mid-link" >

                            <FaInstagramSquare className="footer-div-others-contact-mid-link-ic" />

                            <span className="footer-div-others-contact-mid-link-txt" > Instagram </span>
                        </a>

                        <a href="https://www.linkedin.com/company/farmyapp/" className="footer-div-others-contact-mid-link" >

                            <FaLinkedinIn className="footer-div-others-contact-mid-link-ic" />

                            <span className="footer-div-others-contact-mid-link-txt" > Linkedin </span>
                        </a>

                    </div>

                </div>

                <div className="footer-div-others-qlinks" >
                    <div className="footer-div-others-contact-top footer-div-others-qlinks-top" >
                        Quick Links 
                    </div>
                    <div className="footer-div-others-qlinks-mid" >

                        <Link to="/" className="footer-div-others-qlinks-mid-link" >
                            <BsHouse className="footer-div-others-qlinks-mid-link-ic" />
                            Home
                        </Link>

                        <Link to="/profile" className="footer-div-others-qlinks-mid-link" >
                            <FiUser className="footer-div-others-qlinks-mid-link-ic" />
                            Profile
                        </Link>

                        <Link to="/about_referral" className="footer-div-others-qlinks-mid-link" >
                            <BsGift className="footer-div-others-qlinks-mid-link-ic" />
                            Referral
                        </Link>

                        <Link to="/" className="footer-div-others-qlinks-mid-link" >
                            <FaShoppingBag className="footer-div-others-qlinks-mid-link-ic" />
                            Foods
                        </Link>

                    </div>
                </div>

                <div className="footer-div-others-deli" >
                    <div className="footer-div-others-deli-top footer-div-others-contact-top" >
                        our Delivery services  
                    </div>
                    <div className="footer-div-others-deli-num" >
                        The farmers are responsible for the transporting of the products to buyers who choose the
                        "FarmyApp Express Delivery" mode of delivery , Products will get to buyers within 24 hours of 
                        harvest except otherwise stated
                    </div>
                </div>

                <div className="footer-div-others-deli" >
                    <div className="footer-div-others-deli-top footer-div-others-contact-top" >
                        Contact us  
                    </div>
                    <div className="footer-div-others-deli-num" >
                        07042995949
                        <br/>
                        info@farmyapp.com
                    </div>
                </div>

            </div>

        </div>

        </>

      );

}

export default Footerdiv;