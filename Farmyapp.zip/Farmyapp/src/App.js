import React from 'react';
import './css/main.css';
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import Layout from './layout/layout';
import { Route , Switch } from 'react-router-dom';
import LogicStore from './store/logicforstore';
import ServLayout from './services/layout/sevlayout';
import CssGrid from './component/utilities/cssGrid/cssGrid';
import Home from './pages/home/home';
import AboutReferal from './pages/about_referal/about_referal';
import BlogLayout from './component/blog-components/blog-layout/blogLayout';
import AboutUsPage from './component/about_us/about_us';
import ReactNotification from 'react-notifications-component';
import 'react-notifications-component/dist/theme.css';
import FoodIndexLayout from './foods/layout/Foodindexlayout';
import OurFoodProducts from './foods/layout/OurFoodProducts';
import UserProfileIndexLayout from './foods/layout/UserprofileLayout';
import ReceiptComponent from './foods/pages/reciepts';
import SpecialPage from './foods/pages/specialpage';


const App = (props) => {

  // const context = useContext(Store)

//   if( !context.Token && !context.User_id ){
//     Axios.defaults.headers.common['Authorization'] = 'Token '+ context.Token;
// }


  return (

    <LogicStore>
                <ReactNotification />

                   <Switch>
                      <Route path="/about_referral" exact  component={AboutReferal} />
                      <Route path="/wholesale"  exact component={Layout} />
                      <Route path="/signin" exact  component={Layout} />
                      <Route path="/signin_ref:id" exact  component={Layout} />
                      <Route path="/about_us" exact  component={AboutUsPage} />
                      <Route path="/signup" exact  component={Layout} />
                      <Route path="/refer_user:id" exact  component={Layout} />
                      <Route path="/product:slug::id" exact component={Layout} />
                      <Route path="/blogs" exact component={BlogLayout} />
                      <Route path="/user:id" exact component={Layout} />
                      <Route path="/sell" exact component={Layout} />
                      <Route path="/payproducts" exact component={Layout} />
                      <Route path="/payservice" exact component={Layout} />
                      <Route path="/passwordreset/:uid/:tok" exact component={Layout} />
                      <Route path="/cart" exact component={Layout} />
                      <Route path="/checkout" exact component={Layout} />
                      <Route path="/search:query::address::offset" exact component={Layout} />
                      <Route path="/search:query::offset" exact component={Layout} />
                      <Route path="/editproduct:slug::id" exact component={Layout} />
                      <Route path="/mydeliveredproducts" exact component={Layout} />
                      <Route path="/finalcheckout:id" exact component={Layout} />
                      <Route path="/myorders" exact component={Layout} />
                      <Route path="/more:limit::offset" exact component={Layout} />
                      <Route path="/services" exact component={ServLayout} />
                      <Route path="/services_add_service" exact component={ServLayout} />
                      <Route path="/fullserv:slug::id" exact component={ServLayout} />
                      <Route path="/servsearch:query::address::offset" exact component={ServLayout} />
                      <Route path="/bookservice:slug::id" exact component={ServLayout} />
                      <Route path="/editservice:slug::id" exact component={ServLayout} />
                      <Route path="/servget:query::offset" exact component={ServLayout} />
                      <Route path="/moreserv:offset" exact component={ServLayout} />
                      <Route path="/servsearch:query::offset" exact component={ServLayout}  />
                      <Route path="/finalServchk:id" exact component={ServLayout}  />
                      <Route path="/resetPassword" exact component={Layout}  />
                      <Route path="/cssgrid" exact component={CssGrid}  />
                      {/* <Route path="/notify" exact component={Notify}  /> */}
                      <Route path="/" exact component={FoodIndexLayout}  />
                      <Route path="/retail/product/:slug/:id" exact component={FoodIndexLayout}  />
                      <Route path="/retail/signin" exact component={FoodIndexLayout}  />
                      <Route path="/retail/cart" exact component={FoodIndexLayout}  />
                      <Route path="/retail/checkout/:user/:id" exact component={FoodIndexLayout}  />
                      <Route path="/retail/selling_is_product" exact component={OurFoodProducts}  />
                      <Route path="/retail/productedit" exact component={OurFoodProducts}  />
                      <Route path="/retail/productedit/product/:slug/:id" exact component={OurFoodProducts}  />
                      <Route path="/retail/productedit/:offset" exact component={OurFoodProducts}  />
                      <Route path="/retail/category/:id/:category/" exact component={FoodIndexLayout} /> 
                      <Route path="/retail/category/:id/:category/:offset" exact component={FoodIndexLayout} /> 
                      <Route path="/retail/search/query=:query" exact component={FoodIndexLayout} />
                      <Route path="/retail/search/query/:query/:offset" exact component={FoodIndexLayout} /> 
                      <Route path="/retail/oursearch/query=:query" exact component={OurFoodProducts} />
                      <Route path="/retail/oursearch/query/:query/:offset" exact component={OurFoodProducts} /> 
                      <Route path="/retail/ourcategory/:id/:category/" exact component={OurFoodProducts} /> 
                      <Route path="/retail/ourcategory/:id/:category/:offset" exact component={OurFoodProducts} /> 
                      <Route path="/profile" exact component={UserProfileIndexLayout} /> 
                      <Route path="/retail/products/allorders/" exact component={OurFoodProducts} /> 
                      <Route path="/retail/products/allorders/:id/" exact component={OurFoodProducts} /> 
                      <Route path="/profile/retail_order/:id" exact component={UserProfileIndexLayout} /> 
                      <Route path="/profile/editprofile" exact component={UserProfileIndexLayout} /> 
                      <Route path="/profile/myorders" exact component={UserProfileIndexLayout} /> 
                      <Route path="/profile/my_products" exact component={UserProfileIndexLayout} />
                      <Route path="/profile/my_services" exact component={UserProfileIndexLayout} />
                      <Route path="/mypendingproducts" exact component={UserProfileIndexLayout} />
                      <Route path="/mypendingservices" exact component={UserProfileIndexLayout} />
                      <Route path="/allordersfull:id" exact component={UserProfileIndexLayout} />
                      <Route path="/my_referrals" exact component={UserProfileIndexLayout} />
                      <Route path="/services_hired" exact component={UserProfileIndexLayout} />
                      <Route path="/servfull:id" exact component={UserProfileIndexLayout} />
                      <Route path="/profile/wholesale_order/:id" exact component={UserProfileIndexLayout} />
                      <Route path="/retail/receipts" exact component={ReceiptComponent} />
                      <Route component={SpecialPage} />
                   </Switch>
    </LogicStore>

  );


 }


export default App;
